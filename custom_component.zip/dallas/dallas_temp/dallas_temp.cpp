





<!DOCTYPE html>
<html
  lang="en"
  
  data-color-mode="auto" data-light-theme="light" data-dark-theme="dark"
  data-a11y-animated-images="system" data-a11y-link-underlines="true"
  >


  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com" crossorigin>
  <link rel="preconnect" href="https://avatars.githubusercontent.com">

  


  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/light-f552bab6ce72.css" /><link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/dark-4589f64a2275.css" /><link data-color-theme="dark_dimmed" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed-a7246d2d6733.css" /><link data-color-theme="dark_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_high_contrast-f2ef05cef2f1.css" /><link data-color-theme="dark_colorblind" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind-daa1fe317131.css" /><link data-color-theme="light_colorblind" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind-1ab6fcc64845.css" /><link data-color-theme="light_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_high_contrast-46de871e876c.css" /><link data-color-theme="light_tritanopia" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_tritanopia-c9754fef2a31.css" /><link data-color-theme="dark_tritanopia" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_tritanopia-dba748981a29.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-primitives-4cbeaa0795ef.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-87f353b17355.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/global-b169e665f6fa.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/github-f1af66156f94.css" />
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/repository-2e900f0ac288.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/code-ac15a98582bf.css" />

  


  <script type="application/json" id="client-env">{"locale":"en","featureFlags":["code_vulnerability_scanning","copilot_chat_static_thread_suggestions","copilot_conversational_ux_history_refs","copilot_followup_to_agent","copilot_smell_icebreaker_ux","copilot_implicit_context","copilot_stop_response","failbot_handle_non_errors","geojson_azure_maps","image_metric_tracking","marketing_forms_api_integration_contact_request","marketing_pages_search_explore_provider","memex_issues_grouped_by_type_milestone","repository_suggester_elastic_search","turbo_experiment_risky","sample_network_conn_type","no_character_key_shortcuts_in_inputs","react_start_transition_for_navigations","custom_inp","remove_child_patch","kb_source_repos","filter_prefetch_suggestions"]}</script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/wp-runtime-328651b8d7b5.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_dompurify_dist_purify_js-810e4b1b9abd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_oddbird_popover-polyfill_dist_popover_js-4ac41d0a76fd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_smoothscroll-polyfill_dist_smoothscroll_js-node_modules_stacktrace-parse-a448e4-bdc28e06dc01.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/environment-65dcc25bed15.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_behaviors_dist_esm_focus-zone_js-f669b9466f06.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_selector-observer_dist_index_esm_js-9f960d9b217c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_combobox-nav_dist_index_js-node_modules_github_markdown-toolbar-e-820fc0-1176135e4d90.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_auto-complete-element_dist_index_js-node_modules_github_catalyst_-392fe4-5df1d85d02da.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_text-expander-element_dist_index_js-b2135edb5ced.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_filter-input-element_dist_index_js-node_modules_github_remote-inp-b7d8f4-6e6f83bcc978.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_index_js-node_modules_delegated-events_dist_in-b63d41-1e3984e4dd2f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_file-attachment-element_dist_index_js-node_modules_primer_view-co-3959a9-1ccb1cef5682.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_onfocus_ts-ui_packages_trusted-types-policies_policy_ts-ui_packages-6fe316-4083e7233d28.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/github-elements-c9cd2492b1b3.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/element-registry-9d0463539b74.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_braintree_browser-detection_dist_browser-detection_js-node_modules_githu-fd5530-79ffdad54bcd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_lit-html_lit-html_js-cc7cb714ead5.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_morphdom_dist_morphdom-esm_js-node_modules_github_memoize_dist_esm_index_js-8d7117d67c36.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_turbo_dist_turbo_es2017-esm_js-1cea0f5eff45.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_remote-form_dist_index_js-node_modules_delegated-events_dist_inde-893f9f-880ac2bbb719.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_scroll-anchoring_dist_scroll-anchoring_esm_js-node_modules_github_hotkey-1a1d91-1bb71f3f93c2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_color-convert_index_js-cdd1e82b3795.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_behaviors_dist_esm_dimensions_js-node_modules_github_jtml_lib_index_js-b1947a1d4855.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_session-resume_dist_index_js-node_modules_primer_behaviors_dist_e-da6ec6-77ce2f267f4e.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_quote-selection_dist_index_js-node_modules_github_textarea-autosi-9e0349-7c78ee755ad3.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_updatable-content_ts-7fcc5f2841d8.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_task-list_ts-app_assets_modules_github_onfocus_ts-app_ass-421cec-d3af2356fb47.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_sticky-scroll-into-view_ts-3dc342dedcb0.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_ajax-error_ts-app_assets_modules_github_behaviors_include-467754-0b06f9573e1c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_commenting_edit_ts-app_assets_modules_github_behaviors_ht-83c235-5276a3faf037.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/behaviors-968375ea793c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_delegated-events_dist_index_js-node_modules_github_catalyst_lib_index_js-06ff531-2ea61fcc9a71.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/notifications-global-0409f6303340.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_repositories_get-repo-element_ts-e21ae6671295.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/code-menu-67595c3a6d0c.js"></script>
  
  <script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/react-lib-dc88c1a68b28.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_octicons-react_dist_index_esm_js-node_modules_primer_react_lib-es-541a38-2ad77ede4dad.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Box_Box_js-5a335cbe71ad.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_FeatureFlags_FeatureFlags_js-node_modules_github_ca-9009bd-47065f21e9ac.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Button_Button_js-618154c88198.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_TooltipV2_Tooltip_js-98aea6945770.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_node_modules_primer_octicons-react_dist_index_esm_mjs-dc98a76c65d6.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_ActionList_index_js-a2fe8fc7236e.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_TextInput_TextInput_js-57e9c5f82efe.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_FormControl_FormControl_js-0c2e219e6035.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_ActionMenu_ActionMenu_js-node_modules_primer_react_-5b2420-3d111386e1c1.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_react-router-dom_dist_index_js-2b1dbeadb6d4.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Link_Link_js-node_modules_primer_react_lib-esm_Rela-a903d7-17c01d44f123.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_ConfirmationDialog_ConfirmationDialog_js-1811321a7c22.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Heading_Heading_js-node_modules_primer_react_lib-es-8280c5-4772b28bff07.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_PageLayout_PageLayout_js-node_modules_github_hydro--f8521d-a461a484b308.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_TreeView_TreeView_js-9456d871c361.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_AvatarStack_AvatarStack_js-node_modules_primer_reac-21d8ca-f2ca17197cdd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_react-core_create-browser-history_ts-ui_packages_safe-storage_safe-storage_ts-ui_-682c2c-44ed51a2083d.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_react-core_register-app_ts-a7b9de7616e6.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_paths_index_ts-d30e09039de9.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_ref-selector_RefSelector_tsx-84a0dce6bcb2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_code-view-shared_hooks_shortcuts_ts-ui_packages_commit-attribution_index_ts-ui_pa-e33d1b-9311565c937c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_react-shared_hooks_use-canonical-object_ts-ui_packages_code-view-shared_ho-7d1336-ffa29d1b0cd7.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_blob-anchor_ts-app_assets_modules_github_filter-sort_ts-app_assets_-e50ab6-06193ffb3fd6.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_code-view-shared_components_files-search_FileResultsList_tsx-11b1a83d8b93.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/react-code-view-ffd23841034e.js"></script>
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/react-code-view.98a0f4bdacd6223a0b70.module.css" />


  <title>esphome/esphome/components/dallas_temp/dallas_temp.cpp at dev · esphome/esphome</title>



  <meta name="route-pattern" content="/:user_id/:repository/blob/*name(/*path)" data-turbo-transient>
  <meta name="route-controller" content="blob" data-turbo-transient>
  <meta name="route-action" content="show" data-turbo-transient>

    
  <meta name="current-catalog-service-hash" content="82c569b93da5c18ed649ebd4c2c79437db4611a6a1373e805a3cb001c64130b7">


  <meta name="request-id" content="D0DC:78B14:D43F1C9:D9133B0:666F2CF5" data-turbo-transient="true" /><meta name="html-safe-nonce" content="66a3582cf1c6801fd6aa450110209a6fd04408c09b1d26e47f2692dc534a3973" data-turbo-transient="true" /><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHBzOi8vZ2l0aHViLmNvbS9lc3Bob21lL2VzcGhvbWUvdHJlZS9kZXYvZXNwaG9tZS9jb21wb25lbnRzL2RhbGxhc190ZW1wIiwicmVxdWVzdF9pZCI6IkQwREM6NzhCMTQ6RDQzRjFDOTpEOTEzM0IwOjY2NkYyQ0Y1IiwidmlzaXRvcl9pZCI6IjQwNzIxNzI3NzU1MzgzNTMwMDgiLCJyZWdpb25fZWRnZSI6ImZyYSIsInJlZ2lvbl9yZW5kZXIiOiJpYWQifQ==" data-turbo-transient="true" /><meta name="visitor-hmac" content="2f6f1c0f6709a0c27e9a4a326e72f4e210535587e45208a31435b15299cdc18c" data-turbo-transient="true" />


    <meta name="hovercard-subject-tag" content="repository:128479644" data-turbo-transient>


  <meta name="github-keyboard-shortcuts" content="repository,source-code,file-tree,copilot" data-turbo-transient="true" />
  

  <meta name="selected-link" value="repo_source" data-turbo-transient>
  <link rel="assets" href="https://github.githubassets.com/">

    <meta name="google-site-verification" content="Apib7-x98H0j5cPqHWwSMm6dNU4GmODRoqxLiDzdx9I">

<meta name="octolytics-url" content="https://collector.github.com/github/collect" /><meta name="octolytics-actor-id" content="52893640" /><meta name="octolytics-actor-login" content="tiimsvk" /><meta name="octolytics-actor-hash" content="842d76d044226e0580a92e953f6f2a6bde7f079556bf3484eb7c732ab4e9b274" />

  <meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/show" data-turbo-transient="true" />

  




    <meta name="user-login" content="tiimsvk">

  <link rel="sudo-modal" href="/sessions/sudo_modal">

    <meta name="viewport" content="width=device-width">

    

      <meta name="description" content="ESPHome is a system to control your ESP8266/ESP32 by simple yet powerful configuration files and control them remotely through Home Automation systems. - esphome/esphome/components/dallas_temp/dallas_temp.cpp at dev · esphome/esphome">

      <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">

    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <meta property="fb:app_id" content="1401488693436528">
    <meta name="apple-itunes-app" content="app-id=1477376905, app-argument=https://github.com/esphome/esphome/blob/dev/esphome/components/dallas_temp/dallas_temp.cpp" />

      <meta name="twitter:image:src" content="https://repository-images.githubusercontent.com/128479644/62275f80-81fc-11e9-9ab6-486f5901da35" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="esphome/esphome/components/dallas_temp/dallas_temp.cpp at dev · esphome/esphome" /><meta name="twitter:description" content="ESPHome is a system to control your ESP8266/ESP32 by simple yet powerful configuration files and control them remotely through Home Automation systems. - esphome/esphome" />
  <meta property="og:image" content="https://repository-images.githubusercontent.com/128479644/62275f80-81fc-11e9-9ab6-486f5901da35" /><meta property="og:image:alt" content="ESPHome is a system to control your ESP8266/ESP32 by simple yet powerful configuration files and control them remotely through Home Automation systems. - esphome/esphome" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="esphome/esphome/components/dallas_temp/dallas_temp.cpp at dev · esphome/esphome" /><meta property="og:url" content="https://github.com/esphome/esphome/blob/dev/esphome/components/dallas_temp/dallas_temp.cpp" /><meta property="og:description" content="ESPHome is a system to control your ESP8266/ESP32 by simple yet powerful configuration files and control them remotely through Home Automation systems. - esphome/esphome" />
  


      <link rel="shared-web-socket" href="wss://alive.github.com/_sockets/u/52893640/ws?session=eyJ2IjoiVjMiLCJ1Ijo1Mjg5MzY0MCwicyI6MTM0MzMxMzgzNCwiYyI6MjEzMTA3MjA4OCwidCI6MTcxODU2MjA2MX0=--9892e2101630f9b167f471695e437256675870e9b4f0eca7984b32d978fb4f84" data-refresh-url="/_alive" data-session-id="8bcc5ff45cf2a6664589cd45ddda1d3994ee3db7c970c5c56eef71f883c63e71">
      <link rel="shared-web-socket-src" href="/assets-cdn/worker/socket-worker-1a9b1a7a6108.js">


      <meta name="hostname" content="github.com">


      <meta name="keyboard-shortcuts-preference" content="all">

        <meta name="expected-hostname" content="github.com">


  <meta http-equiv="x-pjax-version" content="99b866739f9b6d04c6e30f86f61e3698d359a0f69d70fd2ef4becf6335732ce0" data-turbo-track="reload">
  <meta http-equiv="x-pjax-csp-version" content="cd708ee2def842997e00c6ea48122249b3249615ca3c50f1e66cc10581f34f3c" data-turbo-track="reload">
  <meta http-equiv="x-pjax-css-version" content="b6badfac5b2843ce61eb9c9d65e2e407e85a8697eb2fc9fa8fdf27ec7b5c68aa" data-turbo-track="reload">
  <meta http-equiv="x-pjax-js-version" content="168f2ecfe24c57070c5a08e77466f2b572a65f21fadd22938a8a424cc54028b0" data-turbo-track="reload">

  <meta name="turbo-cache-control" content="no-preview" data-turbo-transient="">

      <meta name="turbo-cache-control" content="no-cache" data-turbo-transient>
    <meta data-hydrostats="publish">
  <meta name="go-import" content="github.com/esphome/esphome git https://github.com/esphome/esphome.git">

  <meta name="octolytics-dimension-user_id" content="45919759" /><meta name="octolytics-dimension-user_login" content="esphome" /><meta name="octolytics-dimension-repository_id" content="128479644" /><meta name="octolytics-dimension-repository_nwo" content="esphome/esphome" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="128479644" /><meta name="octolytics-dimension-repository_network_root_nwo" content="esphome/esphome" />



    

    <meta name="turbo-body-classes" content="logged-in env-production page-responsive">


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark" />


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-in env-production page-responsive" style="word-wrap: break-word;">
    <div data-turbo-body class="logged-in env-production page-responsive" style="word-wrap: break-word;">
      


    <div class="position-relative js-header-wrapper ">
      <a href="#start-of-content" data-skip-target-assigned="false" class="p-3 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>

      <span data-view-component="true" class="progress-pjax-loader Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      
      







<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Button_IconButton_js-node_modules_primer_react_lib--1cd808-94bb79d8a6de.js"></script>

<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/keyboard-shortcuts-dialog-5e74c9152183.js"></script>

<react-partial
  partial-name="keyboard-shortcuts-dialog"
  data-ssr="false"
>
  
  <script type="application/json" data-target="react-partial.embeddedData">{"props":{"docsUrl":"https://docs.github.com/get-started/accessibility/keyboard-shortcuts"}}</script>
  <div data-target="react-partial.reactRoot"></div>
</react-partial>




      

        <script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_allex_crc32_lib_crc32_esm_js-node_modules_github_mini-throttle_dist_deco-a9eeba-555e7418878d.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_clipboard-copy-element_dist_index_esm_js-node_modules_delegated-e-b37f7d-cb3d06ead51a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_command-palette_items_help-item_ts-app_assets_modules_github_comman-48ad9d-cd4d1523cddf.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/command-palette-a99cf9e9f4ca.js"></script>

            <header class="AppHeader" role="banner">
  <h2 class="sr-only">Navigation Menu</h2>

    

    <div class="AppHeader-globalBar pb-2 js-global-bar">
      <div class="AppHeader-globalBar-start">
          <deferred-side-panel data-url="/_side-panels/global">
  <include-fragment data-target="deferred-side-panel.fragment">
      <button aria-label="Open global navigation menu" data-action="click:deferred-side-panel#loadPanel click:deferred-side-panel#panelOpened" data-show-dialog-id="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c" id="dialog-show-dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c" type="button" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button color-bg-transparent p-0 color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-three-bars Button-visual">
    <path d="M1 2.75A.75.75 0 0 1 1.75 2h12.5a.75.75 0 0 1 0 1.5H1.75A.75.75 0 0 1 1 2.75Zm0 5A.75.75 0 0 1 1.75 7h12.5a.75.75 0 0 1 0 1.5H1.75A.75.75 0 0 1 1 7.75ZM1.75 12h12.5a.75.75 0 0 1 0 1.5H1.75a.75.75 0 0 1 0-1.5Z"></path>
</svg>
</button>

<dialog-helper>
  <dialog data-target="deferred-side-panel.panel" id="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c" aria-modal="true" aria-labelledby="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c-title" aria-describedby="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-small-portrait Overlay--motion-scaleFade Overlay--placement-left SidePanel">
    <div styles="flex-direction: row;" data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title sr-only" id="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c-title">
        Global navigation
      </h1>
            <div data-view-component="true" class="d-flex">
      <div data-view-component="true" class="AppHeader-logo position-relative">
        <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path>
</svg>
</div></div>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="dialog-c63339ed-eb89-4cfd-8799-0c69dd71f17c-title">
        <div data-view-component="true" class="Overlay-body d-flex flex-column px-2">    <div data-view-component="true" class="d-flex flex-column mb-3">
        <nav aria-label="Site navigation" data-view-component="true" class="ActionList">
  
  <nav-list>
    <ul data-target="nav-list.topLevelList" data-view-component="true" class="ActionListWrap">
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-hotkey="g d" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;HOME&quot;,&quot;label&quot;:null}" id="item-80df5ef8-76ec-4ba8-a3e4-b5f386e8e043" href="/dashboard" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-home">
    <path d="M6.906.664a1.749 1.749 0 0 1 2.187 0l5.25 4.2c.415.332.657.835.657 1.367v7.019A1.75 1.75 0 0 1 13.25 15h-3.5a.75.75 0 0 1-.75-.75V9H7v5.25a.75.75 0 0 1-.75.75h-3.5A1.75 1.75 0 0 1 1 13.25V6.23c0-.531.242-1.034.657-1.366l5.25-4.2Zm1.25 1.171a.25.25 0 0 0-.312 0l-5.25 4.2a.25.25 0 0 0-.094.196v7.019c0 .138.112.25.25.25H5.5V8.25a.75.75 0 0 1 .75-.75h3.5a.75.75 0 0 1 .75.75v5.25h2.75a.25.25 0 0 0 .25-.25V6.23a.25.25 0 0 0-.094-.195Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Home
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-hotkey="g i" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;ISSUES&quot;,&quot;label&quot;:null}" id="item-e8e5d36e-f94b-41e4-b449-c1773a45db56" href="/issues" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Issues
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-hotkey="g p" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PULL_REQUESTS&quot;,&quot;label&quot;:null}" id="item-f1ac6523-42dd-4a83-83a3-fd08cb77ee73" href="/pulls" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Pull requests
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-item-id="projects" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PROJECTS&quot;,&quot;label&quot;:null}" id="item-acb3edd6-7ffd-4eed-9b26-9971805bb548" href="/projects" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25ZM6.5 6.5v8h7.75a.25.25 0 0 0 .25-.25V6.5Zm8-1.5V1.75a.25.25 0 0 0-.25-.25H6.5V5Zm-13 1.5v7.75c0 .138.112.25.25.25H5v-8ZM5 5V1.5H1.75a.25.25 0 0 0-.25.25V5Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Projects
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;DISCUSSIONS&quot;,&quot;label&quot;:null}" id="item-96363b62-7c70-4b3f-8f44-49913aea7c0e" href="/discussions" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Discussions
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;CODESPACES&quot;,&quot;label&quot;:null}" id="item-f7fb6d34-5b40-48da-b93d-d56c147095f3" href="https://github.com/codespaces" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-codespaces">
    <path d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"></path><path d="M7 12.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Codespaces
</span></a>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;EXPLORE&quot;,&quot;label&quot;:null}" id="item-6e598f19-45b9-4e98-870d-32cdf1ae07a8" href="/explore" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-telescope">
    <path d="M14.184 1.143v-.001l1.422 2.464a1.75 1.75 0 0 1-.757 2.451L3.104 11.713a1.75 1.75 0 0 1-2.275-.702l-.447-.775a1.75 1.75 0 0 1 .53-2.32L11.682.573a1.748 1.748 0 0 1 2.502.57Zm-4.709 9.32h-.001l2.644 3.863a.75.75 0 1 1-1.238.848l-1.881-2.75v2.826a.75.75 0 0 1-1.5 0v-2.826l-1.881 2.75a.75.75 0 1 1-1.238-.848l2.049-2.992a.746.746 0 0 1 .293-.253l1.809-.87a.749.749 0 0 1 .944.252ZM9.436 3.92h-.001l-4.97 3.39.942 1.63 5.42-2.61Zm3.091-2.108h.001l-1.85 1.26 1.505 2.605 2.016-.97a.247.247 0 0 0 .13-.151.247.247 0 0 0-.022-.199l-1.422-2.464a.253.253 0 0 0-.161-.119.254.254 0 0 0-.197.038ZM1.756 9.157a.25.25 0 0 0-.075.33l.447.775a.25.25 0 0 0 .325.1l1.598-.769-.83-1.436-1.465 1Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Explore
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;MARKETPLACE&quot;,&quot;label&quot;:null}" id="item-73b811b6-d8ca-4be6-8d66-731b1b671ff4" href="/marketplace" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-gift">
    <path d="M2 2.75A2.75 2.75 0 0 1 4.75 0c.983 0 1.873.42 2.57 1.232.268.318.497.668.68 1.042.183-.375.411-.725.68-1.044C9.376.42 10.266 0 11.25 0a2.75 2.75 0 0 1 2.45 4h.55c.966 0 1.75.784 1.75 1.75v2c0 .698-.409 1.301-1 1.582v4.918A1.75 1.75 0 0 1 13.25 16H2.75A1.75 1.75 0 0 1 1 14.25V9.332C.409 9.05 0 8.448 0 7.75v-2C0 4.784.784 4 1.75 4h.55c-.192-.375-.3-.8-.3-1.25ZM7.25 9.5H2.5v4.75c0 .138.112.25.25.25h4.5Zm1.5 0v5h4.5a.25.25 0 0 0 .25-.25V9.5Zm0-4V8h5.5a.25.25 0 0 0 .25-.25v-2a.25.25 0 0 0-.25-.25Zm-7 0a.25.25 0 0 0-.25.25v2c0 .138.112.25.25.25h5.5V5.5h-5.5Zm3-4a1.25 1.25 0 0 0 0 2.5h2.309c-.233-.818-.542-1.401-.878-1.793-.43-.502-.915-.707-1.431-.707ZM8.941 4h2.309a1.25 1.25 0 0 0 0-2.5c-.516 0-1 .205-1.43.707-.337.392-.646.975-.879 1.793Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Marketplace
</span></a>
  
</li>

</ul>  </nav-list>
</nav>

        <div data-view-component="true" class="my-3 d-flex flex-justify-center height-full">
          <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</div>
</div>
      <div data-view-component="true" class="flex-1"></div>


      <div data-view-component="true" class="px-2">      <p class="color-fg-subtle text-small text-light">&copy; 2024 GitHub, Inc.</p>

      <div data-view-component="true" class="d-flex flex-wrap text-small text-light">
          <a target="_blank" href="https://github.com/about" data-view-component="true" class="Link mr-2">About</a>
          <a target="_blank" href="https://github.blog" data-view-component="true" class="Link mr-2">Blog</a>
          <a target="_blank" href="https://docs.github.com/site-policy/github-terms/github-terms-of-service" data-view-component="true" class="Link mr-2">Terms</a>
          <a target="_blank" href="https://docs.github.com/site-policy/privacy-policies/github-privacy-statement" data-view-component="true" class="Link mr-2">Privacy</a>
          <a target="_blank" href="https://github.com/security" data-view-component="true" class="Link mr-2">Security</a>
          <a target="_blank" href="https://www.githubstatus.com/" data-view-component="true" class="Link mr-3">Status</a>

</div></div>
</div>
      </scrollable-region>
      
</dialog></dialog-helper>

  </include-fragment>
</deferred-side-panel>

        <a
          class="AppHeader-logo ml-2"
          href="https://github.com/"
          data-hotkey="g d"
          aria-label="Homepage "
          data-turbo="false"
          data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;go to dashboard&quot;,&quot;label&quot;:&quot;icon:logo&quot;}"
        >
          <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github v-align-middle color-fg-default">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path>
</svg>
        </a>

          <div class="AppHeader-context" >
  <div class="AppHeader-context-compact">
      <button aria-expanded="false" aria-haspopup="dialog" aria-label="Page context: esphome / esphome" id="dialog-show-context-region-dialog" data-show-dialog-id="context-region-dialog" type="button" data-view-component="true" class="AppHeader-context-compact-trigger Truncate Button--secondary Button--medium Button box-shadow-none">  <span class="Button-content">
    <span class="Button-label"><span class="AppHeader-context-compact-lead">
                <span class="AppHeader-context-compact-parentItem">esphome</span>
                <span class="no-wrap">&nbsp;/</span>

            </span>

            <strong class="AppHeader-context-compact-mainItem d-flex flex-items-center Truncate" >
  <span class="Truncate-text ">esphome</span>

</strong></span>
  </span>
</button>

<dialog-helper>
  <dialog id="context-region-dialog" aria-modal="true" aria-labelledby="context-region-dialog-title" aria-describedby="context-region-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade">
    <div data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="context-region-dialog-title">
        Navigate back to
      </h1>
        
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="context-region-dialog" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="context-region-dialog-title">
        <div data-view-component="true" class="Overlay-body">          <ul role="list" class="list-style-none" >
    <li>
      <a data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_crumb&quot;,&quot;label&quot;:&quot;esphome&quot;,&quot;screen_size&quot;:&quot;compact&quot;}" href="/esphome" data-view-component="true" class="Link--primary Truncate d-flex flex-items-center py-1">
        <span class="AppHeader-context-item-label Truncate-text ">
            <svg aria-hidden="true" height="12" viewBox="0 0 16 16" version="1.1" width="12" data-view-component="true" class="octicon octicon-organization mr-1">
    <path d="M1.75 16A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0h8.5C11.216 0 12 .784 12 1.75v12.5c0 .085-.006.168-.018.25h2.268a.25.25 0 0 0 .25-.25V8.285a.25.25 0 0 0-.111-.208l-1.055-.703a.749.749 0 1 1 .832-1.248l1.055.703c.487.325.779.871.779 1.456v5.965A1.75 1.75 0 0 1 14.25 16h-3.5a.766.766 0 0 1-.197-.026c-.099.017-.2.026-.303.026h-3a.75.75 0 0 1-.75-.75V14h-1v1.25a.75.75 0 0 1-.75.75Zm-.25-1.75c0 .138.112.25.25.25H4v-1.25a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 .75.75v1.25h2.25a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25ZM3.75 6h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 3.75A.75.75 0 0 1 3.75 3h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 3.75Zm4 3A.75.75 0 0 1 7.75 6h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 7 6.75ZM7.75 3h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 9.75A.75.75 0 0 1 3.75 9h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 9.75ZM7.75 9h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5Z"></path>
</svg>

          esphome
        </span>

</a>
    </li>
    <li>
      <a data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_crumb&quot;,&quot;label&quot;:&quot;esphome&quot;,&quot;screen_size&quot;:&quot;compact&quot;}" href="/esphome/esphome" data-view-component="true" class="Link--primary Truncate d-flex flex-items-center py-1">
        <span class="AppHeader-context-item-label Truncate-text ">
            <svg aria-hidden="true" height="12" viewBox="0 0 16 16" version="1.1" width="12" data-view-component="true" class="octicon octicon-repo mr-1">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>

          esphome
        </span>

</a>
    </li>
</ul>

</div>
      </scrollable-region>
      
</dialog></dialog-helper>
  </div>

  <div class="AppHeader-context-full">
    <nav role="navigation" aria-label="Page context">
      <ul role="list" class="list-style-none" >
    <li>
      <a data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_crumb&quot;,&quot;label&quot;:&quot;esphome&quot;,&quot;screen_size&quot;:&quot;full&quot;}" data-hovercard-type="organization" data-hovercard-url="/orgs/esphome/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/esphome" data-view-component="true" class="AppHeader-context-item">
        <span class="AppHeader-context-item-label  ">

          esphome
        </span>

</a>
        <span class="AppHeader-context-item-separator">/</span>
    </li>
    <li>
      <a data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_crumb&quot;,&quot;label&quot;:&quot;esphome&quot;,&quot;screen_size&quot;:&quot;full&quot;}" href="/esphome/esphome" data-view-component="true" class="AppHeader-context-item">
        <span class="AppHeader-context-item-label  ">

          esphome
        </span>

</a>
    </li>
</ul>

    </nav>
  </div>
</div>

      </div>
      <div class="AppHeader-globalBar-end">
          <div class="AppHeader-search" >
              


<qbsearch-input class="search-input" data-scope="repo:esphome/esphome" data-custom-scopes-path="/search/custom_scopes" data-delete-custom-scopes-csrf="BPMOBv6CVcZM6Gizzq2RCFbCMu_wSi5hZoGR8W2xrCzQC9BIvZD7I8XHtj3au_1aHcdPI4O5HBGF-imxvKEdtQ" data-max-custom-scopes="10" data-header-redesign-enabled="true" data-initial-value="" data-blackbird-suggestions-path="/search/suggestions" data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations" data-current-repository="esphome/esphome" data-current-org="esphome" data-current-owner="" data-logged-in="true" data-copilot-chat-enabled="false" data-blackbird-indexed-repo-csrf="<input type=&quot;hidden&quot; value=&quot;CXN41wwsAgIJWT-kO3FW60Jx0hlAWovegGjaghCrnRnKSdTXtnJjMhW_Ry4JRX6xHj2zB2TD08wJdGcnYA1oMw&quot; data-csrf=&quot;true&quot; />">
  <div
    class="search-input-container search-with-dialog position-relative d-flex flex-row flex-items-center height-auto color-bg-transparent border-0 color-fg-subtle mx-0"
    data-action="click:qbsearch-input#searchInputContainerClicked"
  >
      
            <button type="button" data-action="click:qbsearch-input#handleExpand" class="AppHeader-button AppHeader-search-whenNarrow" aria-label="Search or jump to…" aria-expanded="false" aria-haspopup="dialog">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
          </button>


<div class="AppHeader-search-whenRegular">
  <div class="AppHeader-search-wrap AppHeader-search-wrap--hasTrailing">
    <div class="AppHeader-search-control">
      <label
        for="AppHeader-searchInput"
        aria-label="Search or jump to…"
        class="AppHeader-search-visual--leading"
      >
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
      </label>

                <button
            type="button"
            data-target="qbsearch-input.inputButton"
            data-action="click:qbsearch-input#handleExpand"
            class="AppHeader-searchButton form-control input-contrast text-left color-fg-subtle no-wrap"
            data-hotkey="s,/"
            data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;SEARCH&quot;,&quot;label&quot;:null}"
            aria-describedby="search-error-message-flash"
          >
            <div class="overflow-hidden">
              <span id="qb-input-query" data-target="qbsearch-input.inputButtonText">
                  Type <kbd class="AppHeader-search-kbd">/</kbd> to search
              </span>
            </div>
          </button>

    </div>


      <button type="button" id="AppHeader-commandPalette-button" class="AppHeader-search-action--trailing js-activate-command-palette" data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;command_palette&quot;,&quot;label&quot;:&quot;open command palette&quot;}">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-command-palette">
    <path d="m6.354 8.04-4.773 4.773a.75.75 0 1 0 1.061 1.06L7.945 8.57a.75.75 0 0 0 0-1.06L2.642 2.206a.75.75 0 0 0-1.06 1.061L6.353 8.04ZM8.75 11.5a.75.75 0 0 0 0 1.5h5.5a.75.75 0 0 0 0-1.5h-5.5Z"></path>
</svg>
      </button>

      <tool-tip id="tooltip-dd58903b-84ac-4786-ad7b-a1950f321105" for="AppHeader-commandPalette-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Command palette</tool-tip>
  </div>
</div>

    <input type="hidden" name="type" class="js-site-search-type-field">

    
<div class="Overlay--hidden " data-modal-dialog-overlay>
  <modal-dialog data-action="close:qbsearch-input#handleClose cancel:qbsearch-input#handleClose" data-target="qbsearch-input.searchSuggestionsDialog" role="dialog" id="search-suggestions-dialog" aria-modal="true" aria-labelledby="search-suggestions-dialog-header" data-view-component="true" class="Overlay Overlay--width-medium Overlay--height-auto">
      <h1 id="search-suggestions-dialog-header" class="sr-only">Search code, repositories, users, issues, pull requests...</h1>
    <div class="Overlay-body Overlay-body--paddingNone">
      
          <div data-view-component="true">        <div class="search-suggestions position-absolute width-full color-shadow-large border color-fg-default color-bg-default overflow-hidden d-flex flex-column query-builder-container"
          style="border-radius: 12px;"
          data-target="qbsearch-input.queryBuilderContainer"
          hidden
        >
          <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="query-builder-test-form" action="" accept-charset="UTF-8" method="get">
  <query-builder data-target="qbsearch-input.queryBuilder" id="query-builder-query-builder-test" data-filter-key=":" data-view-component="true" class="QueryBuilder search-query-builder">
    <div class="FormControl FormControl--fullWidth">
      <label id="query-builder-test-label" for="query-builder-test" class="FormControl-label sr-only">
        Search
      </label>
      <div
        class="QueryBuilder-StyledInput width-fit "
        data-target="query-builder.styledInput"
      >
          <span id="query-builder-test-leadingvisual-wrap" class="FormControl-input-leadingVisualWrap QueryBuilder-leadingVisualWrap">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search FormControl-input-leadingVisual">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
          </span>
        <div data-target="query-builder.styledInputContainer" class="QueryBuilder-StyledInputContainer">
          <div
            aria-hidden="true"
            class="QueryBuilder-StyledInputContent"
            data-target="query-builder.styledInputContent"
          ></div>
          <div class="QueryBuilder-InputWrapper">
            <div aria-hidden="true" class="QueryBuilder-Sizer" data-target="query-builder.sizer"></div>
            <input id="query-builder-test" name="query-builder-test" value="" autocomplete="off" type="text" role="combobox" spellcheck="false" aria-expanded="false" aria-describedby="validation-05c23ab2-507e-4d38-b96e-0cfc1818d31c" data-target="query-builder.input" data-action="
          input:query-builder#inputChange
          blur:query-builder#inputBlur
          keydown:query-builder#inputKeydown
          focus:query-builder#inputFocus
        " data-view-component="true" class="FormControl-input QueryBuilder-Input FormControl-medium" />
          </div>
        </div>
          <span class="sr-only" id="query-builder-test-clear">Clear</span>
          <button role="button" id="query-builder-test-clear-button" aria-labelledby="query-builder-test-clear query-builder-test-label" data-target="query-builder.clearButton" data-action="
                click:query-builder#clear
                focus:query-builder#clearButtonFocus
                blur:query-builder#clearButtonBlur
              " variant="small" hidden="hidden" type="button" data-view-component="true" class="Button Button--iconOnly Button--invisible Button--medium mr-1 px-2 py-0 d-flex flex-items-center rounded-1 color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x-circle-fill Button-visual">
    <path d="M2.343 13.657A8 8 0 1 1 13.658 2.343 8 8 0 0 1 2.343 13.657ZM6.03 4.97a.751.751 0 0 0-1.042.018.751.751 0 0 0-.018 1.042L6.94 8 4.97 9.97a.749.749 0 0 0 .326 1.275.749.749 0 0 0 .734-.215L8 9.06l1.97 1.97a.749.749 0 0 0 1.275-.326.749.749 0 0 0-.215-.734L9.06 8l1.97-1.97a.749.749 0 0 0-.326-1.275.749.749 0 0 0-.734.215L8 6.94Z"></path>
</svg>
</button>

      </div>
      <template id="search-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
</template>

<template id="code-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</template>

<template id="file-code-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file-code">
    <path d="M4 1.75C4 .784 4.784 0 5.75 0h5.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v8.586A1.75 1.75 0 0 1 14.25 15h-9a.75.75 0 0 1 0-1.5h9a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 10 4.25V1.5H5.75a.25.25 0 0 0-.25.25v2.5a.75.75 0 0 1-1.5 0Zm1.72 4.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734l1.47-1.47-1.47-1.47a.75.75 0 0 1 0-1.06ZM3.28 7.78 1.81 9.25l1.47 1.47a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Zm8.22-6.218V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path>
</svg>
</template>

<template id="history-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-history">
    <path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path>
</svg>
</template>

<template id="repo-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>
</template>

<template id="bookmark-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bookmark">
    <path d="M3 2.75C3 1.784 3.784 1 4.75 1h6.5c.966 0 1.75.784 1.75 1.75v11.5a.75.75 0 0 1-1.227.579L8 11.722l-3.773 3.107A.751.751 0 0 1 3 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v9.91l3.023-2.489a.75.75 0 0 1 .954 0l3.023 2.49V2.75a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="plus-circle-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus-circle">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm7.25-3.25v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5a.75.75 0 0 1 1.5 0Z"></path>
</svg>
</template>

<template id="circle-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-dot-fill">
    <path d="M8 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z"></path>
</svg>
</template>

<template id="trash-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-trash">
    <path d="M11 1.75V3h2.25a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1 0-1.5H5V1.75C5 .784 5.784 0 6.75 0h2.5C10.216 0 11 .784 11 1.75ZM4.496 6.675l.66 6.6a.25.25 0 0 0 .249.225h5.19a.25.25 0 0 0 .249-.225l.66-6.6a.75.75 0 0 1 1.492.149l-.66 6.6A1.748 1.748 0 0 1 10.595 15h-5.19a1.75 1.75 0 0 1-1.741-1.575l-.66-6.6a.75.75 0 1 1 1.492-.15ZM6.5 1.75V3h3V1.75a.25.25 0 0 0-.25-.25h-2.5a.25.25 0 0 0-.25.25Z"></path>
</svg>
</template>

<template id="team-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-people">
    <path d="M2 5.5a3.5 3.5 0 1 1 5.898 2.549 5.508 5.508 0 0 1 3.034 4.084.75.75 0 1 1-1.482.235 4 4 0 0 0-7.9 0 .75.75 0 0 1-1.482-.236A5.507 5.507 0 0 1 3.102 8.05 3.493 3.493 0 0 1 2 5.5ZM11 4a3.001 3.001 0 0 1 2.22 5.018 5.01 5.01 0 0 1 2.56 3.012.749.749 0 0 1-.885.954.752.752 0 0 1-.549-.514 3.507 3.507 0 0 0-2.522-2.372.75.75 0 0 1-.574-.73v-.352a.75.75 0 0 1 .416-.672A1.5 1.5 0 0 0 11 5.5.75.75 0 0 1 11 4Zm-5.5-.5a2 2 0 1 0-.001 3.999A2 2 0 0 0 5.5 3.5Z"></path>
</svg>
</template>

<template id="project-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project">
    <path d="M1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0ZM1.5 1.75v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25ZM11.75 3a.75.75 0 0 1 .75.75v7.5a.75.75 0 0 1-1.5 0v-7.5a.75.75 0 0 1 .75-.75Zm-8.25.75a.75.75 0 0 1 1.5 0v5.5a.75.75 0 0 1-1.5 0ZM8 3a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 3Z"></path>
</svg>
</template>

<template id="pencil-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-pencil">
    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"></path>
</svg>
</template>

<template id="copilot-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copilot">
    <path d="M7.998 15.035c-4.562 0-7.873-2.914-7.998-3.749V9.338c.085-.628.677-1.686 1.588-2.065.013-.07.024-.143.036-.218.029-.183.06-.384.126-.612-.201-.508-.254-1.084-.254-1.656 0-.87.128-1.769.693-2.484.579-.733 1.494-1.124 2.724-1.261 1.206-.134 2.262.034 2.944.765.05.053.096.108.139.165.044-.057.094-.112.143-.165.682-.731 1.738-.899 2.944-.765 1.23.137 2.145.528 2.724 1.261.566.715.693 1.614.693 2.484 0 .572-.053 1.148-.254 1.656.066.228.098.429.126.612.012.076.024.148.037.218.924.385 1.522 1.471 1.591 2.095v1.872c0 .766-3.351 3.795-8.002 3.795Zm0-1.485c2.28 0 4.584-1.11 5.002-1.433V7.862l-.023-.116c-.49.21-1.075.291-1.727.291-1.146 0-2.059-.327-2.71-.991A3.222 3.222 0 0 1 8 6.303a3.24 3.24 0 0 1-.544.743c-.65.664-1.563.991-2.71.991-.652 0-1.236-.081-1.727-.291l-.023.116v4.255c.419.323 2.722 1.433 5.002 1.433ZM6.762 2.83c-.193-.206-.637-.413-1.682-.297-1.019.113-1.479.404-1.713.7-.247.312-.369.789-.369 1.554 0 .793.129 1.171.308 1.371.162.181.519.379 1.442.379.853 0 1.339-.235 1.638-.54.315-.322.527-.827.617-1.553.117-.935-.037-1.395-.241-1.614Zm4.155-.297c-1.044-.116-1.488.091-1.681.297-.204.219-.359.679-.242 1.614.091.726.303 1.231.618 1.553.299.305.784.54 1.638.54.922 0 1.28-.198 1.442-.379.179-.2.308-.578.308-1.371 0-.765-.123-1.242-.37-1.554-.233-.296-.693-.587-1.713-.7Z"></path><path d="M6.25 9.037a.75.75 0 0 1 .75.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 .75-.75Zm4.25.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 1.5 0Z"></path>
</svg>
</template>

<template id="workflow-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-workflow">
    <path d="M0 1.75C0 .784.784 0 1.75 0h3.5C6.216 0 7 .784 7 1.75v3.5A1.75 1.75 0 0 1 5.25 7H4v4a1 1 0 0 0 1 1h4v-1.25C9 9.784 9.784 9 10.75 9h3.5c.966 0 1.75.784 1.75 1.75v3.5A1.75 1.75 0 0 1 14.25 16h-3.5A1.75 1.75 0 0 1 9 14.25v-.75H5A2.5 2.5 0 0 1 2.5 11V7h-.75A1.75 1.75 0 0 1 0 5.25Zm1.75-.25a.25.25 0 0 0-.25.25v3.5c0 .138.112.25.25.25h3.5a.25.25 0 0 0 .25-.25v-3.5a.25.25 0 0 0-.25-.25Zm9 9a.25.25 0 0 0-.25.25v3.5c0 .138.112.25.25.25h3.5a.25.25 0 0 0 .25-.25v-3.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="book-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-book">
    <path d="M0 1.75A.75.75 0 0 1 .75 1h4.253c1.227 0 2.317.59 3 1.501A3.743 3.743 0 0 1 11.006 1h4.245a.75.75 0 0 1 .75.75v10.5a.75.75 0 0 1-.75.75h-4.507a2.25 2.25 0 0 0-1.591.659l-.622.621a.75.75 0 0 1-1.06 0l-.622-.621A2.25 2.25 0 0 0 5.258 13H.75a.75.75 0 0 1-.75-.75Zm7.251 10.324.004-5.073-.002-2.253A2.25 2.25 0 0 0 5.003 2.5H1.5v9h3.757a3.75 3.75 0 0 1 1.994.574ZM8.755 4.75l-.004 7.322a3.752 3.752 0 0 1 1.992-.572H14.5v-9h-3.495a2.25 2.25 0 0 0-2.25 2.25Z"></path>
</svg>
</template>

<template id="code-review-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code-review">
    <path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0 1 14.25 13H8.061l-2.574 2.573A1.458 1.458 0 0 1 3 14.543V13H1.75A1.75 1.75 0 0 1 0 11.25v-8.5C0 1.784.784 1 1.75 1ZM1.5 2.75v8.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h6.5a.25.25 0 0 0 .25-.25v-8.5a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Zm5.28 1.72a.75.75 0 0 1 0 1.06L5.31 7l1.47 1.47a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018l-2-2a.75.75 0 0 1 0-1.06l2-2a.75.75 0 0 1 1.06 0Zm2.44 0a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L10.69 7 9.22 5.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</template>

<template id="codespaces-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-codespaces">
    <path d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"></path><path d="M7 12.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path>
</svg>
</template>

<template id="comment-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment">
    <path d="M1 2.75C1 1.784 1.784 1 2.75 1h10.5c.966 0 1.75.784 1.75 1.75v7.5A1.75 1.75 0 0 1 13.25 12H9.06l-2.573 2.573A1.458 1.458 0 0 1 4 13.543V12H2.75A1.75 1.75 0 0 1 1 10.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h4.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="comment-discussion-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
</template>

<template id="organization-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-organization">
    <path d="M1.75 16A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0h8.5C11.216 0 12 .784 12 1.75v12.5c0 .085-.006.168-.018.25h2.268a.25.25 0 0 0 .25-.25V8.285a.25.25 0 0 0-.111-.208l-1.055-.703a.749.749 0 1 1 .832-1.248l1.055.703c.487.325.779.871.779 1.456v5.965A1.75 1.75 0 0 1 14.25 16h-3.5a.766.766 0 0 1-.197-.026c-.099.017-.2.026-.303.026h-3a.75.75 0 0 1-.75-.75V14h-1v1.25a.75.75 0 0 1-.75.75Zm-.25-1.75c0 .138.112.25.25.25H4v-1.25a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 .75.75v1.25h2.25a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25ZM3.75 6h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 3.75A.75.75 0 0 1 3.75 3h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 3.75Zm4 3A.75.75 0 0 1 7.75 6h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 7 6.75ZM7.75 3h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 9.75A.75.75 0 0 1 3.75 9h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 9.75ZM7.75 9h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5Z"></path>
</svg>
</template>

<template id="rocket-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-rocket">
    <path d="M14.064 0h.186C15.216 0 16 .784 16 1.75v.186a8.752 8.752 0 0 1-2.564 6.186l-.458.459c-.314.314-.641.616-.979.904v3.207c0 .608-.315 1.172-.833 1.49l-2.774 1.707a.749.749 0 0 1-1.11-.418l-.954-3.102a1.214 1.214 0 0 1-.145-.125L3.754 9.816a1.218 1.218 0 0 1-.124-.145L.528 8.717a.749.749 0 0 1-.418-1.11l1.71-2.774A1.748 1.748 0 0 1 3.31 4h3.204c.288-.338.59-.665.904-.979l.459-.458A8.749 8.749 0 0 1 14.064 0ZM8.938 3.623h-.002l-.458.458c-.76.76-1.437 1.598-2.02 2.5l-1.5 2.317 2.143 2.143 2.317-1.5c.902-.583 1.74-1.26 2.499-2.02l.459-.458a7.25 7.25 0 0 0 2.123-5.127V1.75a.25.25 0 0 0-.25-.25h-.186a7.249 7.249 0 0 0-5.125 2.123ZM3.56 14.56c-.732.732-2.334 1.045-3.005 1.148a.234.234 0 0 1-.201-.064.234.234 0 0 1-.064-.201c.103-.671.416-2.273 1.15-3.003a1.502 1.502 0 1 1 2.12 2.12Zm6.94-3.935c-.088.06-.177.118-.266.175l-2.35 1.521.548 1.783 1.949-1.2a.25.25 0 0 0 .119-.213ZM3.678 8.116 5.2 5.766c.058-.09.117-.178.176-.266H3.309a.25.25 0 0 0-.213.119l-1.2 1.95ZM12 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
</template>

<template id="shield-check-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield-check">
    <path d="m8.533.133 5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667l5.25-1.68a1.748 1.748 0 0 1 1.066 0Zm-.61 1.429.001.001-5.25 1.68a.251.251 0 0 0-.174.237V7c0 1.36.275 2.666 1.057 3.859.784 1.194 2.121 2.342 4.366 3.298a.196.196 0 0 0 .154 0c2.245-.957 3.582-2.103 4.366-3.297C13.225 9.666 13.5 8.358 13.5 7V3.48a.25.25 0 0 0-.174-.238l-5.25-1.68a.25.25 0 0 0-.153 0ZM11.28 6.28l-3.5 3.5a.75.75 0 0 1-1.06 0l-1.5-1.5a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l.97.97 2.97-2.97a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
</template>

<template id="heart-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-heart">
    <path d="m8 14.25.345.666a.75.75 0 0 1-.69 0l-.008-.004-.018-.01a7.152 7.152 0 0 1-.31-.17 22.055 22.055 0 0 1-3.434-2.414C2.045 10.731 0 8.35 0 5.5 0 2.836 2.086 1 4.25 1 5.797 1 7.153 1.802 8 3.02 8.847 1.802 10.203 1 11.75 1 13.914 1 16 2.836 16 5.5c0 2.85-2.045 5.231-3.885 6.818a22.066 22.066 0 0 1-3.744 2.584l-.018.01-.006.003h-.002ZM4.25 2.5c-1.336 0-2.75 1.164-2.75 3 0 2.15 1.58 4.144 3.365 5.682A20.58 20.58 0 0 0 8 13.393a20.58 20.58 0 0 0 3.135-2.211C12.92 9.644 14.5 7.65 14.5 5.5c0-1.836-1.414-3-2.75-3-1.373 0-2.609.986-3.029 2.456a.749.749 0 0 1-1.442 0C6.859 3.486 5.623 2.5 4.25 2.5Z"></path>
</svg>
</template>

<template id="server-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-server">
    <path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v4c0 .372-.116.717-.314 1 .198.283.314.628.314 1v4a1.75 1.75 0 0 1-1.75 1.75H1.75A1.75 1.75 0 0 1 0 12.75v-4c0-.358.109-.707.314-1a1.739 1.739 0 0 1-.314-1v-4C0 1.784.784 1 1.75 1ZM1.5 2.75v4c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-4a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Zm.25 5.75a.25.25 0 0 0-.25.25v4c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-4a.25.25 0 0 0-.25-.25ZM7 4.75A.75.75 0 0 1 7.75 4h4.5a.75.75 0 0 1 0 1.5h-4.5A.75.75 0 0 1 7 4.75ZM7.75 10h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1 0-1.5ZM3 4.75A.75.75 0 0 1 3.75 4h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 4.75ZM3.75 10h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5Z"></path>
</svg>
</template>

<template id="globe-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-globe">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM5.78 8.75a9.64 9.64 0 0 0 1.363 4.177c.255.426.542.832.857 1.215.245-.296.551-.705.857-1.215A9.64 9.64 0 0 0 10.22 8.75Zm4.44-1.5a9.64 9.64 0 0 0-1.363-4.177c-.307-.51-.612-.919-.857-1.215a9.927 9.927 0 0 0-.857 1.215A9.64 9.64 0 0 0 5.78 7.25Zm-5.944 1.5H1.543a6.507 6.507 0 0 0 4.666 5.5c-.123-.181-.24-.365-.352-.552-.715-1.192-1.437-2.874-1.581-4.948Zm-2.733-1.5h2.733c.144-2.074.866-3.756 1.58-4.948.12-.197.237-.381.353-.552a6.507 6.507 0 0 0-4.666 5.5Zm10.181 1.5c-.144 2.074-.866 3.756-1.58 4.948-.12.197-.237.381-.353.552a6.507 6.507 0 0 0 4.666-5.5Zm2.733-1.5a6.507 6.507 0 0 0-4.666-5.5c.123.181.24.365.353.552.714 1.192 1.436 2.874 1.58 4.948Z"></path>
</svg>
</template>

<template id="issue-opened-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
</template>

<template id="device-mobile-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-device-mobile">
    <path d="M3.75 0h8.5C13.216 0 14 .784 14 1.75v12.5A1.75 1.75 0 0 1 12.25 16h-8.5A1.75 1.75 0 0 1 2 14.25V1.75C2 .784 2.784 0 3.75 0ZM3.5 1.75v12.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25ZM8 13a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path>
</svg>
</template>

<template id="package-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-package">
    <path d="m8.878.392 5.25 3.045c.54.314.872.89.872 1.514v6.098a1.75 1.75 0 0 1-.872 1.514l-5.25 3.045a1.75 1.75 0 0 1-1.756 0l-5.25-3.045A1.75 1.75 0 0 1 1 11.049V4.951c0-.624.332-1.201.872-1.514L7.122.392a1.75 1.75 0 0 1 1.756 0ZM7.875 1.69l-4.63 2.685L8 7.133l4.755-2.758-4.63-2.685a.248.248 0 0 0-.25 0ZM2.5 5.677v5.372c0 .09.047.171.125.216l4.625 2.683V8.432Zm6.25 8.271 4.625-2.683a.25.25 0 0 0 .125-.216V5.677L8.75 8.432Z"></path>
</svg>
</template>

<template id="credit-card-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-credit-card">
    <path d="M10.75 9a.75.75 0 0 0 0 1.5h1.5a.75.75 0 0 0 0-1.5h-1.5Z"></path><path d="M0 3.75C0 2.784.784 2 1.75 2h12.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0 1 14.25 14H1.75A1.75 1.75 0 0 1 0 12.25ZM14.5 6.5h-13v5.75c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25Zm0-2.75a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25V5h13Z"></path>
</svg>
</template>

<template id="play-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
</template>

<template id="gift-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-gift">
    <path d="M2 2.75A2.75 2.75 0 0 1 4.75 0c.983 0 1.873.42 2.57 1.232.268.318.497.668.68 1.042.183-.375.411-.725.68-1.044C9.376.42 10.266 0 11.25 0a2.75 2.75 0 0 1 2.45 4h.55c.966 0 1.75.784 1.75 1.75v2c0 .698-.409 1.301-1 1.582v4.918A1.75 1.75 0 0 1 13.25 16H2.75A1.75 1.75 0 0 1 1 14.25V9.332C.409 9.05 0 8.448 0 7.75v-2C0 4.784.784 4 1.75 4h.55c-.192-.375-.3-.8-.3-1.25ZM7.25 9.5H2.5v4.75c0 .138.112.25.25.25h4.5Zm1.5 0v5h4.5a.25.25 0 0 0 .25-.25V9.5Zm0-4V8h5.5a.25.25 0 0 0 .25-.25v-2a.25.25 0 0 0-.25-.25Zm-7 0a.25.25 0 0 0-.25.25v2c0 .138.112.25.25.25h5.5V5.5h-5.5Zm3-4a1.25 1.25 0 0 0 0 2.5h2.309c-.233-.818-.542-1.401-.878-1.793-.43-.502-.915-.707-1.431-.707ZM8.941 4h2.309a1.25 1.25 0 0 0 0-2.5c-.516 0-1 .205-1.43.707-.337.392-.646.975-.879 1.793Z"></path>
</svg>
</template>

<template id="code-square-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code-square">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25Zm7.47 3.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L10.69 8 9.22 6.53a.75.75 0 0 1 0-1.06ZM6.78 6.53 5.31 8l1.47 1.47a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
</template>

<template id="device-desktop-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-device-desktop">
    <path d="M14.25 1c.966 0 1.75.784 1.75 1.75v7.5A1.75 1.75 0 0 1 14.25 12h-3.727c.099 1.041.52 1.872 1.292 2.757A.752.752 0 0 1 11.25 16h-6.5a.75.75 0 0 1-.565-1.243c.772-.885 1.192-1.716 1.292-2.757H1.75A1.75 1.75 0 0 1 0 10.25v-7.5C0 1.784.784 1 1.75 1ZM1.75 2.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25ZM9.018 12H6.982a5.72 5.72 0 0 1-.765 2.5h3.566a5.72 5.72 0 0 1-.765-2.5Z"></path>
</svg>
</template>

        <div class="position-relative">
                <ul
                  role="listbox"
                  class="ActionListWrap QueryBuilder-ListWrap"
                  aria-label="Suggestions"
                  data-action="
                    combobox-commit:query-builder#comboboxCommit
                    mousedown:query-builder#resultsMousedown
                  "
                  data-target="query-builder.resultsList"
                  data-persist-list=false
                  id="query-builder-test-results"
                ></ul>
        </div>
      <div class="FormControl-inlineValidation" id="validation-05c23ab2-507e-4d38-b96e-0cfc1818d31c" hidden="hidden">
        <span class="FormControl-inlineValidation--visual">
          <svg aria-hidden="true" height="12" viewBox="0 0 12 12" version="1.1" width="12" data-view-component="true" class="octicon octicon-alert-fill">
    <path d="M4.855.708c.5-.896 1.79-.896 2.29 0l4.675 8.351a1.312 1.312 0 0 1-1.146 1.954H1.33A1.313 1.313 0 0 1 .183 9.058ZM7 7V3H5v4Zm-1 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"></path>
</svg>
        </span>
        <span></span>
</div>    </div>
    <div data-target="query-builder.screenReaderFeedback" aria-live="polite" aria-atomic="true" class="sr-only"></div>
</query-builder></form>
          <div class="d-flex flex-row color-fg-muted px-3 text-small color-bg-default search-feedback-prompt">
            <a target="_blank" href="https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax" data-view-component="true" class="Link color-fg-accent text-normal ml-2">
              Search syntax tips
</a>            <div class="d-flex flex-1"></div>
              <button data-action="click:qbsearch-input#showFeedbackDialog" type="button" data-view-component="true" class="Button--link Button--medium Button color-fg-accent text-normal ml-2">  <span class="Button-content">
    <span class="Button-label">Give feedback</span>
  </span>
</button>
          </div>
        </div>
</div>

    </div>
</modal-dialog></div>
  </div>
  <div data-action="click:qbsearch-input#retract" class="dark-backdrop position-fixed" hidden data-target="qbsearch-input.darkBackdrop"></div>
  <div class="color-fg-default">
    
<dialog-helper>
  <dialog data-target="qbsearch-input.feedbackDialog" data-action="close:qbsearch-input#handleDialogClose cancel:qbsearch-input#handleDialogClose" id="feedback-dialog" aria-modal="true" aria-labelledby="feedback-dialog-title" aria-describedby="feedback-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade">
    <div data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="feedback-dialog-title">
        Provide feedback
      </h1>
        
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="feedback-dialog" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="feedback-dialog-title">
        <div data-view-component="true" class="Overlay-body">        <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="code-search-feedback-form" data-turbo="false" action="/search/feedback" accept-charset="UTF-8" method="post"><input type="hidden" name="authenticity_token" value="K__ZY4CvVTjPhqVbof_ZPyImOol8IsZRsHxVhNqmbf75WW0uTKw8_wrY8gDUBC8B-INRCk9iC8iaeC2d5LGT0Q" />
          <p>We read every piece of feedback, and take your input very seriously.</p>
          <textarea name="feedback" class="form-control width-full mb-2" style="height: 120px" id="feedback"></textarea>
          <input name="include_email" id="include_email" aria-label="Include my email address so I can be contacted" class="form-control mr-2" type="checkbox">
          <label for="include_email" style="font-weight: normal">Include my email address so I can be contacted</label>
</form></div>
      </scrollable-region>
      <div data-view-component="true" class="Overlay-footer Overlay-footer--alignEnd">          <button data-close-dialog-id="feedback-dialog" type="button" data-view-component="true" class="btn">    Cancel
</button>
          <button form="code-search-feedback-form" data-action="click:qbsearch-input#submitFeedback" type="submit" data-view-component="true" class="btn-primary btn">    Submit feedback
</button>
</div>
</dialog></dialog-helper>

    <custom-scopes data-target="qbsearch-input.customScopesManager">
    
<dialog-helper>
  <dialog data-target="custom-scopes.customScopesModalDialog" data-action="close:qbsearch-input#handleDialogClose cancel:qbsearch-input#handleDialogClose" id="custom-scopes-dialog" aria-modal="true" aria-labelledby="custom-scopes-dialog-title" aria-describedby="custom-scopes-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade">
    <div data-view-component="true" class="Overlay-header Overlay-header--divided">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="custom-scopes-dialog-title">
        Saved searches
      </h1>
        <h2 id="custom-scopes-dialog-description" class="Overlay-description">Use saved searches to filter your results more quickly</h2>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="custom-scopes-dialog" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="custom-scopes-dialog-title">
        <div data-view-component="true" class="Overlay-body">        <div data-target="custom-scopes.customScopesModalDialogFlash"></div>

        <div hidden class="create-custom-scope-form" data-target="custom-scopes.createCustomScopeForm">
        <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="custom-scopes-dialog-form" data-turbo="false" action="/search/custom_scopes" accept-charset="UTF-8" method="post"><input type="hidden" name="authenticity_token" value="F4yr6ObUcYgHUu2B5WGTvAYd1O9ZmJVhktgLFVITQjVoyyDQTbymrJrzLj805iIxS4hSqoUlG2Cq4DI68zLQYg" />
          <div data-target="custom-scopes.customScopesModalDialogFlash"></div>

          <input type="hidden" id="custom_scope_id" name="custom_scope_id" data-target="custom-scopes.customScopesIdField">

          <div class="form-group">
            <label for="custom_scope_name">Name</label>
            <auto-check src="/search/custom_scopes/check_name" required>
              <input
                type="text"
                name="custom_scope_name"
                id="custom_scope_name"
                data-target="custom-scopes.customScopesNameField"
                class="form-control"
                autocomplete="off"
                placeholder="github-ruby"
                required
                maxlength="50">
              <input type="hidden" value="76DvT27mlKg0nZqmagcC2mtqN2eJyo6yybGHo4jBPZWKREz28Js9MuWvuRSeQuh6meTz-a3Rlxk_GtEChewjjA" data-csrf="true" />
            </auto-check>
          </div>

          <div class="form-group">
            <label for="custom_scope_query">Query</label>
            <input
              type="text"
              name="custom_scope_query"
              id="custom_scope_query"
              data-target="custom-scopes.customScopesQueryField"
              class="form-control"
              autocomplete="off"
              placeholder="(repo:mona/a OR repo:mona/b) AND lang:python"
              required
              maxlength="500">
          </div>

          <p class="text-small color-fg-muted">
            To see all available qualifiers, see our <a class="Link--inTextBlock" href="https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax">documentation</a>.
          </p>
</form>        </div>

        <div data-target="custom-scopes.manageCustomScopesForm">
          <div data-target="custom-scopes.list"></div>
        </div>

</div>
      </scrollable-region>
      <div data-view-component="true" class="Overlay-footer Overlay-footer--alignEnd Overlay-footer--divided">          <button data-action="click:custom-scopes#customScopesCancel" type="button" data-view-component="true" class="btn">    Cancel
</button>
          <button form="custom-scopes-dialog-form" data-action="click:custom-scopes#customScopesSubmit" data-target="custom-scopes.customScopesSubmitButton" type="submit" data-view-component="true" class="btn-primary btn">    Create saved search
</button>
</div>
</dialog></dialog-helper>
    </custom-scopes>
  </div>
</qbsearch-input><input type="hidden" value="1YjPzQaYP-xVEkql_6YYBVqNS_lmv0i64fll9FBvZJ9ScusBmCt05ckQ322g936JqWhA2uPEqd3bzml6BdohAQ" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" />

          </div>

        <div class="AppHeader-actions position-relative">
             <react-partial-anchor>
      <button id="global-create-menu-anchor" aria-label="Create something new" data-target="react-partial-anchor.anchor" type="button" disabled="disabled" data-view-component="true" class="AppHeader-button global-create-button cursor-wait Button--secondary Button--medium Button width-auto color-fg-muted">  <span class="Button-content">
      <span class="Button-visual Button-leadingVisual">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus">
    <path d="M7.75 2a.75.75 0 0 1 .75.75V7h4.25a.75.75 0 0 1 0 1.5H8.5v4.25a.75.75 0 0 1-1.5 0V8.5H2.75a.75.75 0 0 1 0-1.5H7V2.75A.75.75 0 0 1 7.75 2Z"></path>
</svg>
      </span>
    <span class="Button-label"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path>
</svg></span>
  </span>
</button><tool-tip id="tooltip-80b8acee-98a7-4133-8626-ec877a9133f4" for="global-create-menu-anchor" popover="manual" data-direction="s" data-type="description" data-view-component="true" class="sr-only position-absolute">Create new...</tool-tip>

      <template data-target="react-partial-anchor.template">
        








<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Heading_Heading_js-node_modules_primer_react_lib-es-fb1d41-3656792e8019.js"></script>

<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_react-core_register-partial_ts-ui_packages_global-create-menu_GlobalCreateMenu_tsx-6d5eef248ee2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/global-create-menu-13d11aff58d2.js"></script>

<react-partial
  partial-name="global-create-menu"
  data-ssr="false"
>
  
  <script type="application/json" data-target="react-partial.embeddedData">{"props":{"createRepo":true,"importRepo":true,"codespaces":true,"gist":true,"createOrg":true,"createProject":false,"createProjectUrl":"/tiimsvk?tab=projects","createLegacyProject":false,"createIssue":false,"org":{"login":"esphome","canAdmin":true,"addWord":"Invite"},"owner":"esphome","repo":"esphome"}}</script>
  <div data-target="react-partial.reactRoot"></div>
</react-partial>

      </template>
    </react-partial-anchor>


          <a href="/issues" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;ISSUES_HEADER&quot;,&quot;label&quot;:null}" id="icon-button-aab37130-029b-4da3-a40f-ce471115639c" aria-labelledby="tooltip-fc1c8255-1170-42cf-b465-028dee81a008" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened Button-visual">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
</a><tool-tip id="tooltip-fc1c8255-1170-42cf-b465-028dee81a008" for="icon-button-aab37130-029b-4da3-a40f-ce471115639c" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Issues</tool-tip>

          <a href="/pulls" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PULL_REQUESTS_HEADER&quot;,&quot;label&quot;:null}" id="icon-button-d11f7c4c-4da3-4e55-a6e4-40a1bf628436" aria-labelledby="tooltip-5b119de9-76e1-4d31-858b-b7c87fd40f03" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request Button-visual">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
</a><tool-tip id="tooltip-5b119de9-76e1-4d31-858b-b7c87fd40f03" for="icon-button-d11f7c4c-4da3-4e55-a6e4-40a1bf628436" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Pull requests</tool-tip>

        </div>

        <notification-indicator data-channel="eyJjIjoibm90aWZpY2F0aW9uLWNoYW5nZWQ6NTI4OTM2NDAiLCJ0IjoxNzE4NTYyMDYxfQ==--e748ba91994afdbe41784c19160b480aa7062343ed868e682c6cbe05ed61a62d" data-indicator-mode="none" data-tooltip-global="You have unread notifications" data-tooltip-unavailable="Notifications are unavailable at the moment." data-tooltip-none="You have no unread notifications" data-header-redesign-enabled="true" data-fetch-indicator-src="/notifications/indicator" data-fetch-indicator-enabled="true" data-view-component="true" class="js-socket-channel">
    <a id="AppHeader-notifications-button" href="/notifications" aria-labelledby="notification-indicator-tooltip" data-hotkey="g n" data-target="notification-indicator.link" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;NOTIFICATIONS_HEADER&quot;,&quot;label&quot;:null}" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button  color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-inbox Button-visual">
    <path d="M2.8 2.06A1.75 1.75 0 0 1 4.41 1h7.18c.7 0 1.333.417 1.61 1.06l2.74 6.395c.04.093.06.194.06.295v4.5A1.75 1.75 0 0 1 14.25 15H1.75A1.75 1.75 0 0 1 0 13.25v-4.5c0-.101.02-.202.06-.295Zm1.61.44a.25.25 0 0 0-.23.152L1.887 8H4.75a.75.75 0 0 1 .6.3L6.625 10h2.75l1.275-1.7a.75.75 0 0 1 .6-.3h2.863L11.82 2.652a.25.25 0 0 0-.23-.152Zm10.09 7h-2.875l-1.275 1.7a.75.75 0 0 1-.6.3h-3.5a.75.75 0 0 1-.6-.3L4.375 9.5H1.5v3.75c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25Z"></path>
</svg>
</a>

    <tool-tip id="notification-indicator-tooltip" data-target="notification-indicator.tooltip" for="AppHeader-notifications-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Notifications</tool-tip>
</notification-indicator>

        

        <div class="AppHeader-user">
          <deferred-side-panel data-url="/_side-panels/user?react_global_nav=false&amp;repository_id=128479644">
  <include-fragment data-target="deferred-side-panel.fragment">
        <user-drawer-side-panel>
      <button aria-label="Open user account menu" data-action="click:deferred-side-panel#loadPanel click:deferred-side-panel#panelOpened" data-login="tiimsvk" data-show-dialog-id="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378" id="dialog-show-dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378" type="button" data-view-component="true" class="AppHeader-logo Button--invisible Button--medium Button Button--invisible-noVisuals color-bg-transparent p-0">  <span class="Button-content">
    <span class="Button-label"><img src="https://avatars.githubusercontent.com/u/52893640?v=4" alt="" size="32" height="32" width="32" data-view-component="true" class="avatar circle" /></span>
  </span>
</button>

<dialog-helper>
  <dialog data-target="deferred-side-panel.panel" id="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378" aria-modal="true" aria-labelledby="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378-title" aria-describedby="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-small-portrait Overlay--motion-scaleFade Overlay--placement-right SidePanel">
    <div styles="flex-direction: row;" data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title sr-only" id="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378-title">
        Account menu
      </h1>
            <div data-view-component="true" class="d-flex">
      <div data-view-component="true" class="AppHeader-logo position-relative">
        <img src="https://avatars.githubusercontent.com/u/52893640?v=4" alt="" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
</div>        <div data-view-component="true" class="overflow-hidden d-flex width-full">          <div data-view-component="true" class="lh-condensed overflow-hidden d-flex flex-column flex-justify-center ml-2 f5 mr-auto width-full">
            <span data-view-component="true" class="Truncate text-bold">
    <span data-view-component="true" class="Truncate-text">
              tiimsvk
</span>
</span>            </div>
            <action-menu data-select-variant="none" data-view-component="true" class="d-sm-none d-md-none d-lg-none">
  <focus-group direction="vertical" mnemonics retain>
    <button id="user-create-menu-button" popovertarget="user-create-menu-overlay" aria-label="Create something new" aria-controls="user-create-menu-list" aria-haspopup="true" type="button" data-view-component="true" class="AppHeader-button global-create-button Button--secondary Button--medium Button width-auto color-fg-muted">  <span class="Button-content">
      <span class="Button-visual Button-leadingVisual">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus">
    <path d="M7.75 2a.75.75 0 0 1 .75.75V7h4.25a.75.75 0 0 1 0 1.5H8.5v4.25a.75.75 0 0 1-1.5 0V8.5H2.75a.75.75 0 0 1 0-1.5H7V2.75A.75.75 0 0 1 7.75 2Z"></path>
</svg>
      </span>
    <span class="Button-label"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path>
</svg></span>
  </span>
</button><tool-tip id="tooltip-91131765-501f-471c-ac71-a5c11cbcdea1" for="user-create-menu-button" popover="manual" data-direction="s" data-type="description" data-view-component="true" class="sr-only position-absolute">Create new...</tool-tip>


<anchored-position id="user-create-menu-overlay" anchor="user-create-menu-button" align="end" side="outside-bottom" anchor-offset="normal" popover="auto" data-view-component="true">
  <div data-view-component="true" class="Overlay Overlay--size-auto">
    
      <div data-view-component="true" class="Overlay-body Overlay-body--paddingNone">          <action-list>
  <div data-view-component="true">
    <ul aria-labelledby="user-create-menu-button" id="user-create-menu-list" role="menu" data-view-component="true" class="ActionListWrap--inset ActionListWrap">
        <li data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;add_dropdown&quot;,&quot;label&quot;:&quot;new repository&quot;}" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a href="/new" tabindex="-1" id="item-fdba3ac0-be2d-430f-b092-34e43950a4ee" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
                  New repository

</span></a>
  
</li>
        <li data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;add_dropdown&quot;,&quot;label&quot;:&quot;import repository&quot;}" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a href="/new/import" tabindex="-1" id="item-c191ef3b-9caa-4684-b51f-0b9afaeb2066" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-push">
    <path d="M1 2.5A2.5 2.5 0 0 1 3.5 0h8.75a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0V1.5h-8a1 1 0 0 0-1 1v6.708A2.493 2.493 0 0 1 3.5 9h3.25a.75.75 0 0 1 0 1.5H3.5a1 1 0 0 0 0 2h5.75a.75.75 0 0 1 0 1.5H3.5A2.5 2.5 0 0 1 1 11.5Zm13.23 7.79h-.001l-1.224-1.224v6.184a.75.75 0 0 1-1.5 0V9.066L10.28 10.29a.75.75 0 0 1-1.06-1.061l2.505-2.504a.75.75 0 0 1 1.06 0L15.29 9.23a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
                  Import repository

</span></a>
  
</li>
        <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        <li data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;add_dropdown&quot;,&quot;label&quot;:&quot;new codespace&quot;}" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a href="/codespaces/new" tabindex="-1" id="item-3701b085-7257-4c4d-b84e-80b4307520c0" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-codespaces">
    <path d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"></path><path d="M7 12.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
                  New codespace

</span></a>
  
</li>
        <li data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;add_dropdown&quot;,&quot;label&quot;:&quot;new gist&quot;}" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a href="https://gist.github.com/" tabindex="-1" id="item-7cd3d9e6-8462-49fd-8abf-6ec89c4437fd" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
                  New gist

</span></a>
  
</li>
        <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        <li data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a href="/account/organizations/new" tabindex="-1" data-dont-follow-via-test="true" data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;add_dropdown&quot;,&quot;label&quot;:&quot;new organization&quot;}" id="item-2865f427-fd81-4e2e-b046-abf53f6a4f57" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-organization">
    <path d="M1.75 16A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0h8.5C11.216 0 12 .784 12 1.75v12.5c0 .085-.006.168-.018.25h2.268a.25.25 0 0 0 .25-.25V8.285a.25.25 0 0 0-.111-.208l-1.055-.703a.749.749 0 1 1 .832-1.248l1.055.703c.487.325.779.871.779 1.456v5.965A1.75 1.75 0 0 1 14.25 16h-3.5a.766.766 0 0 1-.197-.026c-.099.017-.2.026-.303.026h-3a.75.75 0 0 1-.75-.75V14h-1v1.25a.75.75 0 0 1-.75.75Zm-.25-1.75c0 .138.112.25.25.25H4v-1.25a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 .75.75v1.25h2.25a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25ZM3.75 6h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 3.75A.75.75 0 0 1 3.75 3h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 3.75Zm4 3A.75.75 0 0 1 7.75 6h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 7 6.75ZM7.75 3h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 9.75A.75.75 0 0 1 3.75 9h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 9.75ZM7.75 9h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
                  New organization

</span></a>
  
</li>
</ul>    
</div></action-list>


</div>
      
</div></anchored-position>  </focus-group>
</action-menu>
</div>
</div>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="dialog-0cf0beb4-12ac-4ee1-b541-df52e75bc378-title">
        <div data-view-component="true" class="Overlay-body d-flex flex-column px-2">    <div data-view-component="true" class="d-flex flex-column mb-3">
        <nav aria-label="User navigation" data-view-component="true" class="ActionList">
  
  <nav-list>
    <ul data-target="nav-list.topLevelList" data-view-component="true" class="ActionListWrap">
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <button id="item-7f67f0e6-531e-43d7-8365-c4d62ca74690" type="button" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <span data-view-component="true" class="d-flex flex-items-center">    <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</span>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          

  <span class="color-fg-muted">
    Loading...
  </span>

</span></button>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PROFILE&quot;,&quot;label&quot;:null}" id="item-9e49abb4-6da3-4bb2-93d2-a8e0288a2b34" href="https://github.com/tiimsvk" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-person">
    <path d="M10.561 8.073a6.005 6.005 0 0 1 3.432 5.142.75.75 0 1 1-1.498.07 4.5 4.5 0 0 0-8.99 0 .75.75 0 0 1-1.498-.07 6.004 6.004 0 0 1 3.431-5.142 3.999 3.999 0 1 1 5.123 0ZM10.5 5a2.5 2.5 0 1 0-5 0 2.5 2.5 0 0 0 5 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Your profile
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <button id="item-482508f3-6a89-4f7a-be29-0183d7b61191" type="button" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <span data-view-component="true" class="d-flex flex-items-center">    <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</span>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          

  <span class="color-fg-muted">
    Loading...
  </span>

</span></button>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;YOUR_REPOSITORIES&quot;,&quot;label&quot;:null}" id="item-ba2d5747-f35a-409e-a4c1-fb28aac2983f" href="/tiimsvk?tab=repositories" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Your repositories
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;YOUR_PROJECTS&quot;,&quot;label&quot;:null}" id="item-c8fef382-d5c5-47f4-ae8d-a8d3b5222fb9" href="/tiimsvk?tab=projects" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project">
    <path d="M1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0ZM1.5 1.75v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25ZM11.75 3a.75.75 0 0 1 .75.75v7.5a.75.75 0 0 1-1.5 0v-7.5a.75.75 0 0 1 .75-.75Zm-8.25.75a.75.75 0 0 1 1.5 0v5.5a.75.75 0 0 1-1.5 0ZM8 3a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 3Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Your projects
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <button id="item-eae32aae-c1d2-4c6c-acba-7dd6a593d64d" type="button" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <span data-view-component="true" class="d-flex flex-items-center">    <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</span>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          

  <span class="color-fg-muted">
    Loading...
  </span>

</span></button>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <button id="item-3a6b35a8-bac8-44b5-a04c-cf7a9d171cbe" type="button" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <span data-view-component="true" class="d-flex flex-items-center">    <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</span>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          

  <span class="color-fg-muted">
    Loading...
  </span>

</span></button>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;YOUR_STARS&quot;,&quot;label&quot;:null}" id="item-d737aab6-2137-45f9-917a-a7ff7d6a07ce" href="/tiimsvk?tab=stars" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star">
    <path d="M8 .25a.75.75 0 0 1 .673.418l1.882 3.815 4.21.612a.75.75 0 0 1 .416 1.279l-3.046 2.97.719 4.192a.751.751 0 0 1-1.088.791L8 12.347l-3.766 1.98a.75.75 0 0 1-1.088-.79l.72-4.194L.818 6.374a.75.75 0 0 1 .416-1.28l4.21-.611L7.327.668A.75.75 0 0 1 8 .25Zm0 2.445L6.615 5.5a.75.75 0 0 1-.564.41l-3.097.45 2.24 2.184a.75.75 0 0 1 .216.664l-.528 3.084 2.769-1.456a.75.75 0 0 1 .698 0l2.77 1.456-.53-3.084a.75.75 0 0 1 .216-.664l2.24-2.183-3.096-.45a.75.75 0 0 1-.564-.41L8 2.694Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Your stars
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;SPONSORS&quot;,&quot;label&quot;:null}" id="item-db66ec17-84f8-4925-b423-5112197759f6" href="/sponsors/accounts" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-heart">
    <path d="m8 14.25.345.666a.75.75 0 0 1-.69 0l-.008-.004-.018-.01a7.152 7.152 0 0 1-.31-.17 22.055 22.055 0 0 1-3.434-2.414C2.045 10.731 0 8.35 0 5.5 0 2.836 2.086 1 4.25 1 5.797 1 7.153 1.802 8 3.02 8.847 1.802 10.203 1 11.75 1 13.914 1 16 2.836 16 5.5c0 2.85-2.045 5.231-3.885 6.818a22.066 22.066 0 0 1-3.744 2.584l-.018.01-.006.003h-.002ZM4.25 2.5c-1.336 0-2.75 1.164-2.75 3 0 2.15 1.58 4.144 3.365 5.682A20.58 20.58 0 0 0 8 13.393a20.58 20.58 0 0 0 3.135-2.211C12.92 9.644 14.5 7.65 14.5 5.5c0-1.836-1.414-3-2.75-3-1.373 0-2.609.986-3.029 2.456a.749.749 0 0 1-1.442 0C6.859 3.486 5.623 2.5 4.25 2.5Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Your sponsors
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;YOUR_GISTS&quot;,&quot;label&quot;:null}" id="item-d3a63f5b-3037-4f71-b234-ac2ff7acf124" href="https://gist.github.com/mine" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code-square">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25Zm7.47 3.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L10.69 8 9.22 6.53a.75.75 0 0 1 0-1.06ZM6.78 6.53 5.31 8l1.47 1.47a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Your gists
</span></a>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <button id="item-a0d8b3c3-f3d6-4658-8926-2542f3eb8026" type="button" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <span data-view-component="true" class="d-flex flex-items-center">    <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</span>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          

  <span class="color-fg-muted">
    Loading...
  </span>

</span></button>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <button id="item-d08be4c3-8243-46de-a7e3-139e0d3c7e86" type="button" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <span data-view-component="true" class="d-flex flex-items-center">    <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
</span>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          

  <span class="color-fg-muted">
    Loading...
  </span>

</span></button>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;SETTINGS&quot;,&quot;label&quot;:null}" id="item-b6173964-eac6-4077-8be6-1cec3201508b" href="/settings/profile" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-gear">
    <path d="M8 0a8.2 8.2 0 0 1 .701.031C9.444.095 9.99.645 10.16 1.29l.288 1.107c.018.066.079.158.212.224.231.114.454.243.668.386.123.082.233.09.299.071l1.103-.303c.644-.176 1.392.021 1.82.63.27.385.506.792.704 1.218.315.675.111 1.422-.364 1.891l-.814.806c-.049.048-.098.147-.088.294.016.257.016.515 0 .772-.01.147.038.246.088.294l.814.806c.475.469.679 1.216.364 1.891a7.977 7.977 0 0 1-.704 1.217c-.428.61-1.176.807-1.82.63l-1.102-.302c-.067-.019-.177-.011-.3.071a5.909 5.909 0 0 1-.668.386c-.133.066-.194.158-.211.224l-.29 1.106c-.168.646-.715 1.196-1.458 1.26a8.006 8.006 0 0 1-1.402 0c-.743-.064-1.289-.614-1.458-1.26l-.289-1.106c-.018-.066-.079-.158-.212-.224a5.738 5.738 0 0 1-.668-.386c-.123-.082-.233-.09-.299-.071l-1.103.303c-.644.176-1.392-.021-1.82-.63a8.12 8.12 0 0 1-.704-1.218c-.315-.675-.111-1.422.363-1.891l.815-.806c.05-.048.098-.147.088-.294a6.214 6.214 0 0 1 0-.772c.01-.147-.038-.246-.088-.294l-.815-.806C.635 6.045.431 5.298.746 4.623a7.92 7.92 0 0 1 .704-1.217c.428-.61 1.176-.807 1.82-.63l1.102.302c.067.019.177.011.3-.071.214-.143.437-.272.668-.386.133-.066.194-.158.211-.224l.29-1.106C6.009.645 6.556.095 7.299.03 7.53.01 7.764 0 8 0Zm-.571 1.525c-.036.003-.108.036-.137.146l-.289 1.105c-.147.561-.549.967-.998 1.189-.173.086-.34.183-.5.29-.417.278-.97.423-1.529.27l-1.103-.303c-.109-.03-.175.016-.195.045-.22.312-.412.644-.573.99-.014.031-.021.11.059.19l.815.806c.411.406.562.957.53 1.456a4.709 4.709 0 0 0 0 .582c.032.499-.119 1.05-.53 1.456l-.815.806c-.081.08-.073.159-.059.19.162.346.353.677.573.989.02.03.085.076.195.046l1.102-.303c.56-.153 1.113-.008 1.53.27.161.107.328.204.501.29.447.222.85.629.997 1.189l.289 1.105c.029.109.101.143.137.146a6.6 6.6 0 0 0 1.142 0c.036-.003.108-.036.137-.146l.289-1.105c.147-.561.549-.967.998-1.189.173-.086.34-.183.5-.29.417-.278.97-.423 1.529-.27l1.103.303c.109.029.175-.016.195-.045.22-.313.411-.644.573-.99.014-.031.021-.11-.059-.19l-.815-.806c-.411-.406-.562-.957-.53-1.456a4.709 4.709 0 0 0 0-.582c-.032-.499.119-1.05.53-1.456l.815-.806c.081-.08.073-.159.059-.19a6.464 6.464 0 0 0-.573-.989c-.02-.03-.085-.076-.195-.046l-1.102.303c-.56.153-1.113.008-1.53-.27a4.44 4.44 0 0 0-.501-.29c-.447-.222-.85-.629-.997-1.189l-.289-1.105c-.029-.11-.101-.143-.137-.146a6.6 6.6 0 0 0-1.142 0ZM11 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM9.5 8a1.5 1.5 0 1 0-3.001.001A1.5 1.5 0 0 0 9.5 8Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Settings
</span></a>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;SUPPORT&quot;,&quot;label&quot;:null}" id="item-b6f03103-ed3b-4752-a084-7d7e0d1a7d1c" href="https://support.github.com" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-people">
    <path d="M2 5.5a3.5 3.5 0 1 1 5.898 2.549 5.508 5.508 0 0 1 3.034 4.084.75.75 0 1 1-1.482.235 4 4 0 0 0-7.9 0 .75.75 0 0 1-1.482-.236A5.507 5.507 0 0 1 3.102 8.05 3.493 3.493 0 0 1 2 5.5ZM11 4a3.001 3.001 0 0 1 2.22 5.018 5.01 5.01 0 0 1 2.56 3.012.749.749 0 0 1-.885.954.752.752 0 0 1-.549-.514 3.507 3.507 0 0 0-2.522-2.372.75.75 0 0 1-.574-.73v-.352a.75.75 0 0 1 .416-.672A1.5 1.5 0 0 0 11 5.5.75.75 0 0 1 11 4Zm-5.5-.5a2 2 0 1 0-.001 3.999A2 2 0 0 0 5.5 3.5Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          GitHub Support
</span></a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;COMMUNITY&quot;,&quot;label&quot;:null}" id="item-272d83ec-7c2f-4de9-b026-8399f911ab81" href="https://community.github.com" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          GitHub Community
</span></a>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;LOGOUT&quot;,&quot;label&quot;:null}" id="item-4d296978-3515-4796-9fd8-bd6228773315" href="/logout" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          Sign out
</span></a>
  
</li>

</ul>  </nav-list>
</nav>


</div>
</div>
      </scrollable-region>
      
</dialog></dialog-helper>
    </user-drawer-side-panel>

  </include-fragment>
</deferred-side-panel>
        </div>

        <div class="position-absolute mt-2">
            
<site-header-logged-in-user-menu>

</site-header-logged-in-user-menu>

        </div>
      </div>
    </div>


      <div class="AppHeader-localBar" >
        <nav data-pjax="#js-repo-pjax-container" aria-label="Repository" data-view-component="true" class="js-repo-nav js-sidenav-container-pjax js-responsive-underlinenav overflow-hidden UnderlineNav">

  <ul data-view-component="true" class="UnderlineNav-body list-style-none">
      <li data-view-component="true" class="d-inline-flex">
  <a id="code-tab" href="/esphome/esphome" data-tab-item="i0code-tab" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments repo_attestations /esphome/esphome" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g c" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Code&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
        <span data-content="Code">Code</span>
          <span id="code-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="issues-tab" href="/esphome/esphome/issues" data-tab-item="i1issues-tab" data-selected-links="repo_issues repo_labels repo_milestones /esphome/esphome/issues /_view_fragments/issues/index/esphome/esphome/layout" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g i" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Issues&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        <span data-content="Issues">Issues</span>
          <span id="issues-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="1" data-view-component="true" class="Counter">1</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="pull-requests-tab" href="/esphome/esphome/pulls" data-tab-item="i2pull-requests-tab" data-selected-links="repo_pulls checks /esphome/esphome/pulls" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g p" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Pull requests&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        <span data-content="Pull requests">Pull requests</span>
          <span id="pull-requests-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="207" data-view-component="true" class="Counter">207</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="discussions-tab" href="/esphome/esphome/discussions" data-tab-item="i3discussions-tab" data-selected-links="repo_discussions /esphome/esphome/discussions" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g g" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Discussions&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
        <span data-content="Discussions">Discussions</span>
          <span id="discussions-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="actions-tab" href="/esphome/esphome/actions" data-tab-item="i4actions-tab" data-selected-links="repo_actions /esphome/esphome/actions" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g a" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Actions&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
        <span data-content="Actions">Actions</span>
          <span id="actions-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="security-tab" href="/esphome/esphome/security" data-tab-item="i5security-tab" data-selected-links="security overview alerts policy token_scanning code_scanning /esphome/esphome/security" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g s" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Security&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield UnderlineNav-octicon d-none d-sm-inline">
    <path d="M7.467.133a1.748 1.748 0 0 1 1.066 0l5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667Zm.61 1.429a.25.25 0 0 0-.153 0l-5.25 1.68a.25.25 0 0 0-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.196.196 0 0 0 .154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.251.251 0 0 0-.174-.237l-5.25-1.68ZM8.75 4.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 1.5 0ZM9 10.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        <span data-content="Security">Security</span>
          <include-fragment src="/esphome/esphome/security/overall-count" accept="text/fragment+html"></include-fragment>

    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="insights-tab" href="/esphome/esphome/pulse" data-tab-item="i6insights-tab" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /esphome/esphome/pulse" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Insights&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.5 1.75V13.5h13.75a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1-.75-.75V1.75a.75.75 0 0 1 1.5 0Zm14.28 2.53-5.25 5.25a.75.75 0 0 1-1.06 0L7 7.06 4.28 9.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.25-3.25a.75.75 0 0 1 1.06 0L10 7.94l4.72-4.72a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
        <span data-content="Insights">Insights</span>
          <span id="insights-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
</ul>
    <div style="visibility:hidden;" data-view-component="true" class="UnderlineNav-actions js-responsive-underlinenav-overflow position-absolute pr-3 pr-md-4 pr-lg-5 right-0">      <action-menu data-select-variant="none" data-view-component="true">
  <focus-group direction="vertical" mnemonics retain>
    <button id="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-button" popovertarget="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-overlay" aria-controls="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-list" aria-haspopup="true" aria-labelledby="tooltip-91fd8743-dd4c-4ee3-a504-c556b04677aa" type="button" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium UnderlineNav-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal Button-visual">
    <path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path>
</svg>
</button><tool-tip id="tooltip-91fd8743-dd4c-4ee3-a504-c556b04677aa" for="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Additional navigation options</tool-tip>


<anchored-position id="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-overlay" anchor="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-button" align="start" side="outside-bottom" anchor-offset="normal" popover="auto" data-view-component="true">
  <div data-view-component="true" class="Overlay Overlay--size-auto">
    
      <div data-view-component="true" class="Overlay-body Overlay-body--paddingNone">          <action-list>
  <div data-view-component="true">
    <ul aria-labelledby="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-button" id="action-menu-2d2fa2dc-b85f-4140-ada0-6ffdabeac0f8-list" role="menu" data-view-component="true" class="ActionListWrap--inset ActionListWrap">
        <li hidden="hidden" data-menu-item="i0code-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-e7b2f479-f403-4e5b-97e5-e352417a0e4d" href="/esphome/esphome" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Code
</span></a>
  
</li>
        <li hidden="hidden" data-menu-item="i1issues-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-fc283c88-d978-46d1-b566-f86b684ef492" href="/esphome/esphome/issues" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Issues
</span></a>
  
</li>
        <li hidden="hidden" data-menu-item="i2pull-requests-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-4311373a-5640-4c51-bf74-5515d6cd73a0" href="/esphome/esphome/pulls" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Pull requests
</span></a>
  
</li>
        <li hidden="hidden" data-menu-item="i3discussions-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-e03a22c8-86ad-4f82-aa79-29e4c1417b04" href="/esphome/esphome/discussions" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Discussions
</span></a>
  
</li>
        <li hidden="hidden" data-menu-item="i4actions-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-52c1b96c-4ef4-4636-9045-41db842ef32c" href="/esphome/esphome/actions" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Actions
</span></a>
  
</li>
        <li hidden="hidden" data-menu-item="i5security-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-f9e6c9e6-5400-4ee9-87df-0f1899366c62" href="/esphome/esphome/security" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield">
    <path d="M7.467.133a1.748 1.748 0 0 1 1.066 0l5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667Zm.61 1.429a.25.25 0 0 0-.153 0l-5.25 1.68a.25.25 0 0 0-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.196.196 0 0 0 .154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.251.251 0 0 0-.174-.237l-5.25-1.68ZM8.75 4.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 1.5 0ZM9 10.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Security
</span></a>
  
</li>
        <li hidden="hidden" data-menu-item="i6insights-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-4420e438-56f9-47b0-8fc8-a69ccf1cbf7b" href="/esphome/esphome/pulse" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph">
    <path d="M1.5 1.75V13.5h13.75a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1-.75-.75V1.75a.75.75 0 0 1 1.5 0Zm14.28 2.53-5.25 5.25a.75.75 0 0 1-1.06 0L7 7.06 4.28 9.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.25-3.25a.75.75 0 0 1 1.06 0L10 7.94l4.72-4.72a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Insights
</span></a>
  
</li>
</ul>    
</div></action-list>


</div>
      
</div></anchored-position>  </focus-group>
</action-menu></div>
</nav>
      </div>
</header>


      <div hidden="hidden" data-view-component="true" class="js-stale-session-flash stale-session-flash flash flash-warn flash-full mb-3">
  
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>
        <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>
        <span class="js-stale-session-flash-switched" hidden>You switched accounts on another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>

    <button id="icon-button-58819e1f-7db3-490b-aca4-04066d744044" aria-labelledby="tooltip-ec20509d-0afb-45ad-9aa5-b59a559b25ef" type="button" data-view-component="true" class="Button Button--iconOnly Button--invisible Button--medium flash-close js-flash-close">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x Button-visual">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</button><tool-tip id="tooltip-ec20509d-0afb-45ad-9aa5-b59a559b25ef" for="icon-button-58819e1f-7db3-490b-aca4-04066d744044" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Dismiss alert</tool-tip>


  
</div>
          
    </div>

  <div id="start-of-content" class="show-on-focus"></div>








    <div id="js-flash-container" class="flash-container" data-turbo-replace>





  <template class="js-flash-template">
    
<div class="flash flash-full   {{ className }}">
  <div >
    <button autofocus class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
    </button>
    <div aria-atomic="true" role="alert" class="js-flash-alert">
      
      <div>{{ message }}</div>

    </div>
  </div>
</div>
  </template>
</div>


    
    <notification-shelf-watcher data-base-url="https://github.com/notifications/beta/shelf" data-channel="eyJjIjoibm90aWZpY2F0aW9uLWNoYW5nZWQ6NTI4OTM2NDAiLCJ0IjoxNzE4NTYyMDYxfQ==--e748ba91994afdbe41784c19160b480aa7062343ed868e682c6cbe05ed61a62d" data-view-component="true" class="js-socket-channel"></notification-shelf-watcher>
  <div hidden data-initial data-target="notification-shelf-watcher.placeholder"></div>





      <details
  class="details-reset details-overlay details-overlay-dark js-command-palette-dialog"
  id="command-palette-pjax-container"
  data-turbo-replace
>
  <summary aria-label="Command palette trigger" tabindex="-1"></summary>
  <details-dialog class="command-palette-details-dialog d-flex flex-column flex-justify-center height-fit" aria-label="Command palette">
    <command-palette
      class="command-palette color-bg-default rounded-3 border color-shadow-small"
      return-to=/esphome/esphome/blob/dev/esphome/components/dallas_temp/dallas_temp.cpp
      user-id="52893640"
      activation-hotkey="Mod+k,Mod+Alt+k"
      command-mode-hotkey="Mod+Shift+K"
      data-action="
        command-palette-input-ready:command-palette#inputReady
        command-palette-page-stack-updated:command-palette#updateInputScope
        itemsUpdated:command-palette#itemsUpdated
        keydown:command-palette#onKeydown
        loadingStateChanged:command-palette#loadingStateChanged
        selectedItemChanged:command-palette#selectedItemChanged
        pageFetchError:command-palette#pageFetchError
      ">

        <command-palette-mode
          data-char="#"
            data-scope-types="[&quot;&quot;]"
            data-placeholder="Search issues and pull requests"
        ></command-palette-mode>
        <command-palette-mode
          data-char="#"
            data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
            data-placeholder="Search issues, pull requests, discussions, and projects"
        ></command-palette-mode>
        <command-palette-mode
          data-char="!"
            data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
            data-placeholder="Search projects"
        ></command-palette-mode>
        <command-palette-mode
          data-char="@"
            data-scope-types="[&quot;&quot;]"
            data-placeholder="Search or jump to a user, organization, or repository"
        ></command-palette-mode>
        <command-palette-mode
          data-char="@"
            data-scope-types="[&quot;owner&quot;]"
            data-placeholder="Search or jump to a repository"
        ></command-palette-mode>
        <command-palette-mode
          data-char="/"
            data-scope-types="[&quot;repository&quot;]"
            data-placeholder="Search files"
        ></command-palette-mode>
        <command-palette-mode
          data-char="?"
        ></command-palette-mode>
        <command-palette-mode
          data-char="&gt;"
            data-placeholder="Run a command"
        ></command-palette-mode>
        <command-palette-mode
          data-char=""
            data-scope-types="[&quot;&quot;]"
            data-placeholder="Search or jump to..."
        ></command-palette-mode>
        <command-palette-mode
          data-char=""
            data-scope-types="[&quot;owner&quot;]"
            data-placeholder="Search or jump to..."
        ></command-palette-mode>
      <command-palette-mode
        class="js-command-palette-default-mode"
        data-char=""
        data-placeholder="Search or jump to..."
      ></command-palette-mode>

      <command-palette-input placeholder="Search or jump to..."

        data-action="
          command-palette-input:command-palette#onInput
          command-palette-select:command-palette#onSelect
          command-palette-descope:command-palette#onDescope
          command-palette-cleared:command-palette#onInputClear
        "
      >
        <div class="js-search-icon d-flex flex-items-center mr-2" style="height: 26px">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search color-fg-muted">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
        </div>
        <div class="js-spinner d-flex flex-items-center mr-2 color-fg-muted" hidden>
          <svg aria-label="Loading" class="anim-rotate" viewBox="0 0 16 16" fill="none" width="16" height="16">
            <circle
              cx="8"
              cy="8"
              r="7"
              stroke="currentColor"
              stroke-opacity="0.25"
              stroke-width="2"
              vector-effect="non-scaling-stroke"
            ></circle>
            <path
              d="M15 8a7.002 7.002 0 00-7-7"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              vector-effect="non-scaling-stroke"
            ></path>
          </svg>
        </div>
        <command-palette-scope >
          <div data-target="command-palette-scope.placeholder" hidden class="color-fg-subtle">/&nbsp;&nbsp;<span class="text-semibold color-fg-default">...</span>&nbsp;&nbsp;/&nbsp;&nbsp;</div>
              <command-palette-token
                data-text="esphome"
                data-id="MDEyOk9yZ2FuaXphdGlvbjQ1OTE5NzU5"
                data-type="owner"
                data-value="esphome"
                data-targets="command-palette-scope.tokens"
                class="color-fg-default text-semibold"
                style="white-space:nowrap;line-height:20px;"
                >esphome<span class="color-fg-subtle text-normal">&nbsp;&nbsp;/&nbsp;&nbsp;</span></command-palette-token>
              <command-palette-token
                data-text="esphome"
                data-id="MDEwOlJlcG9zaXRvcnkxMjg0Nzk2NDQ="
                data-type="repository"
                data-value="esphome"
                data-targets="command-palette-scope.tokens"
                class="color-fg-default text-semibold"
                style="white-space:nowrap;line-height:20px;"
                >esphome<span class="color-fg-subtle text-normal">&nbsp;&nbsp;/&nbsp;&nbsp;</span></command-palette-token>
        </command-palette-scope>
        <div class="command-palette-input-group flex-1 form-control border-0 box-shadow-none" style="z-index: 0">
          <div class="command-palette-typeahead position-absolute d-flex flex-items-center Truncate">
            <span class="typeahead-segment input-mirror" data-target="command-palette-input.mirror"></span>
            <span class="Truncate-text" data-target="command-palette-input.typeaheadText"></span>
            <span class="typeahead-segment" data-target="command-palette-input.typeaheadPlaceholder"></span>
          </div>
          <input
            class="js-overlay-input typeahead-input d-none"
            disabled
            tabindex="-1"
            aria-label="Hidden input for typeahead"
          >
          <input
            type="text"
            autocomplete="off"
            autocorrect="off"
            autocapitalize="off"
            spellcheck="false"
            class="js-input typeahead-input form-control border-0 box-shadow-none input-block width-full no-focus-indicator"
            aria-label="Command palette input"
            aria-haspopup="listbox"
            aria-expanded="false"
            aria-autocomplete="list"
            aria-controls="command-palette-page-stack"
            role="combobox"
            data-action="
              input:command-palette-input#onInput
              keydown:command-palette-input#onKeydown
            "
          >
        </div>
          <div data-view-component="true" class="position-relative d-inline-block">
    <button aria-keyshortcuts="Control+Backspace" data-action="click:command-palette-input#onClear keypress:command-palette-input#onClear" data-target="command-palette-input.clearButton" id="command-palette-clear-button" hidden="hidden" type="button" data-view-component="true" class="btn-octicon command-palette-input-clear-button">      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x-circle-fill">
    <path d="M2.343 13.657A8 8 0 1 1 13.658 2.343 8 8 0 0 1 2.343 13.657ZM6.03 4.97a.751.751 0 0 0-1.042.018.751.751 0 0 0-.018 1.042L6.94 8 4.97 9.97a.749.749 0 0 0 .326 1.275.749.749 0 0 0 .734-.215L8 9.06l1.97 1.97a.749.749 0 0 0 1.275-.326.749.749 0 0 0-.215-.734L9.06 8l1.97-1.97a.749.749 0 0 0-.326-1.275.749.749 0 0 0-.734.215L8 6.94Z"></path>
</svg>
</button>    <tool-tip id="tooltip-93a0bb15-bf1c-4a4e-acaf-a223eb8f3162" for="command-palette-clear-button" popover="manual" data-direction="w" data-type="label" data-view-component="true" class="sr-only position-absolute">Clear Command Palette</tool-tip>
</div>
      </command-palette-input>

      <command-palette-page-stack
        data-default-scope-id="MDEwOlJlcG9zaXRvcnkxMjg0Nzk2NDQ="
        data-default-scope-type="Repository"
        data-action="command-palette-page-octicons-cached:command-palette-page-stack#cacheOcticons"
      >
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">#</kbd> to search pull requests
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">#</kbd> to search issues
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">#</kbd> to search discussions
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">!</kbd> to search projects
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;owner&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">@</kbd> to search teams
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">@</kbd> to search people and organizations
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type <kbd class="hx_kbd">&gt;</kbd> to activate command mode
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode=""
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Go to your accessibility settings to change your keyboard shortcuts
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode="#"
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type author:@me to search your content
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode="#"
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type is:pr to filter to pull requests
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode="#"
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type is:issue to filter to issues
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
            data-mode="#"
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type is:project to filter to projects
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
          <command-palette-tip
            class="color-fg-muted f6 px-3 py-1 my-2"
              data-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
            data-mode="#"
            data-value="">
            <div class="d-flex flex-items-start flex-justify-between">
              <div>
                <span class="text-bold">Tip:</span>
                  Type is:open to filter to open content
              </div>
              <div class="ml-2 flex-shrink-0">
                Type <kbd class="hx_kbd">?</kbd> for help and tips
              </div>
            </div>
          </command-palette-tip>
        <command-palette-tip class="mx-3 my-2 flash flash-error d-flex flex-items-center" data-scope-types="*" data-on-error>
          <div>
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
          </div>
          <div class="px-2">
            We’ve encountered an error and some results aren't available at this time. Type a new search or try again later.
          </div>
        </command-palette-tip>
        <command-palette-tip class="h4 color-fg-default pl-3 pb-2 pt-3" data-on-empty data-scope-types="*" data-match-mode="[^?]|^$">
          No results matched your search
        </command-palette-tip>

        <div hidden>

            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="arrow-right-color-fg-muted">
              <svg height="16" class="octicon octicon-arrow-right color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M8.22 2.97a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l2.97-2.97H3.75a.75.75 0 0 1 0-1.5h7.44L8.22 4.03a.75.75 0 0 1 0-1.06Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="arrow-right-color-fg-default">
              <svg height="16" class="octicon octicon-arrow-right color-fg-default" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M8.22 2.97a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l2.97-2.97H3.75a.75.75 0 0 1 0-1.5h7.44L8.22 4.03a.75.75 0 0 1 0-1.06Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="codespaces-color-fg-muted">
              <svg height="16" class="octicon octicon-codespaces color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"></path><path d="M7 12.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="copy-color-fg-muted">
              <svg height="16" class="octicon octicon-copy color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="dash-color-fg-muted">
              <svg height="16" class="octicon octicon-dash color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M2 7.75A.75.75 0 0 1 2.75 7h10a.75.75 0 0 1 0 1.5h-10A.75.75 0 0 1 2 7.75Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="file-color-fg-muted">
              <svg height="16" class="octicon octicon-file color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 9 4.25V1.5Zm6.75.062V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="gear-color-fg-muted">
              <svg height="16" class="octicon octicon-gear color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M8 0a8.2 8.2 0 0 1 .701.031C9.444.095 9.99.645 10.16 1.29l.288 1.107c.018.066.079.158.212.224.231.114.454.243.668.386.123.082.233.09.299.071l1.103-.303c.644-.176 1.392.021 1.82.63.27.385.506.792.704 1.218.315.675.111 1.422-.364 1.891l-.814.806c-.049.048-.098.147-.088.294.016.257.016.515 0 .772-.01.147.038.246.088.294l.814.806c.475.469.679 1.216.364 1.891a7.977 7.977 0 0 1-.704 1.217c-.428.61-1.176.807-1.82.63l-1.102-.302c-.067-.019-.177-.011-.3.071a5.909 5.909 0 0 1-.668.386c-.133.066-.194.158-.211.224l-.29 1.106c-.168.646-.715 1.196-1.458 1.26a8.006 8.006 0 0 1-1.402 0c-.743-.064-1.289-.614-1.458-1.26l-.289-1.106c-.018-.066-.079-.158-.212-.224a5.738 5.738 0 0 1-.668-.386c-.123-.082-.233-.09-.299-.071l-1.103.303c-.644.176-1.392-.021-1.82-.63a8.12 8.12 0 0 1-.704-1.218c-.315-.675-.111-1.422.363-1.891l.815-.806c.05-.048.098-.147.088-.294a6.214 6.214 0 0 1 0-.772c.01-.147-.038-.246-.088-.294l-.815-.806C.635 6.045.431 5.298.746 4.623a7.92 7.92 0 0 1 .704-1.217c.428-.61 1.176-.807 1.82-.63l1.102.302c.067.019.177.011.3-.071.214-.143.437-.272.668-.386.133-.066.194-.158.211-.224l.29-1.106C6.009.645 6.556.095 7.299.03 7.53.01 7.764 0 8 0Zm-.571 1.525c-.036.003-.108.036-.137.146l-.289 1.105c-.147.561-.549.967-.998 1.189-.173.086-.34.183-.5.29-.417.278-.97.423-1.529.27l-1.103-.303c-.109-.03-.175.016-.195.045-.22.312-.412.644-.573.99-.014.031-.021.11.059.19l.815.806c.411.406.562.957.53 1.456a4.709 4.709 0 0 0 0 .582c.032.499-.119 1.05-.53 1.456l-.815.806c-.081.08-.073.159-.059.19.162.346.353.677.573.989.02.03.085.076.195.046l1.102-.303c.56-.153 1.113-.008 1.53.27.161.107.328.204.501.29.447.222.85.629.997 1.189l.289 1.105c.029.109.101.143.137.146a6.6 6.6 0 0 0 1.142 0c.036-.003.108-.036.137-.146l.289-1.105c.147-.561.549-.967.998-1.189.173-.086.34-.183.5-.29.417-.278.97-.423 1.529-.27l1.103.303c.109.029.175-.016.195-.045.22-.313.411-.644.573-.99.014-.031.021-.11-.059-.19l-.815-.806c-.411-.406-.562-.957-.53-1.456a4.709 4.709 0 0 0 0-.582c-.032-.499.119-1.05.53-1.456l.815-.806c.081-.08.073-.159.059-.19a6.464 6.464 0 0 0-.573-.989c-.02-.03-.085-.076-.195-.046l-1.102.303c-.56.153-1.113.008-1.53-.27a4.44 4.44 0 0 0-.501-.29c-.447-.222-.85-.629-.997-1.189l-.289-1.105c-.029-.11-.101-.143-.137-.146a6.6 6.6 0 0 0-1.142 0ZM11 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM9.5 8a1.5 1.5 0 1 0-3.001.001A1.5 1.5 0 0 0 9.5 8Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="lock-color-fg-muted">
              <svg height="16" class="octicon octicon-lock color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M4 4a4 4 0 0 1 8 0v2h.25c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 12.25 15h-8.5A1.75 1.75 0 0 1 2 13.25v-5.5C2 6.784 2.784 6 3.75 6H4Zm8.25 3.5h-8.5a.25.25 0 0 0-.25.25v5.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25ZM10.5 6V4a2.5 2.5 0 1 0-5 0v2Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="moon-color-fg-muted">
              <svg height="16" class="octicon octicon-moon color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M9.598 1.591a.749.749 0 0 1 .785-.175 7.001 7.001 0 1 1-8.967 8.967.75.75 0 0 1 .961-.96 5.5 5.5 0 0 0 7.046-7.046.75.75 0 0 1 .175-.786Zm1.616 1.945a7 7 0 0 1-7.678 7.678 5.499 5.499 0 1 0 7.678-7.678Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="person-color-fg-muted">
              <svg height="16" class="octicon octicon-person color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M10.561 8.073a6.005 6.005 0 0 1 3.432 5.142.75.75 0 1 1-1.498.07 4.5 4.5 0 0 0-8.99 0 .75.75 0 0 1-1.498-.07 6.004 6.004 0 0 1 3.431-5.142 3.999 3.999 0 1 1 5.123 0ZM10.5 5a2.5 2.5 0 1 0-5 0 2.5 2.5 0 0 0 5 0Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="pencil-color-fg-muted">
              <svg height="16" class="octicon octicon-pencil color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="issue-opened-open">
              <svg height="16" class="octicon octicon-issue-opened open" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="git-pull-request-draft-color-fg-muted">
              <svg height="16" class="octicon octicon-git-pull-request-draft color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M3.25 1A2.25 2.25 0 0 1 4 5.372v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.251 2.251 0 0 1 3.25 1Zm9.5 14a2.25 2.25 0 1 1 0-4.5 2.25 2.25 0 0 1 0 4.5ZM2.5 3.25a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0ZM3.25 12a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm9.5 0a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5ZM14 7.5a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0Zm0-4.25a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="search-color-fg-muted">
              <svg height="16" class="octicon octicon-search color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="sun-color-fg-muted">
              <svg height="16" class="octicon octicon-sun color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M8 12a4 4 0 1 1 0-8 4 4 0 0 1 0 8Zm0-1.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Zm5.657-8.157a.75.75 0 0 1 0 1.061l-1.061 1.06a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734l1.06-1.06a.75.75 0 0 1 1.06 0Zm-9.193 9.193a.75.75 0 0 1 0 1.06l-1.06 1.061a.75.75 0 1 1-1.061-1.06l1.06-1.061a.75.75 0 0 1 1.061 0ZM8 0a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0V.75A.75.75 0 0 1 8 0ZM3 8a.75.75 0 0 1-.75.75H.75a.75.75 0 0 1 0-1.5h1.5A.75.75 0 0 1 3 8Zm13 0a.75.75 0 0 1-.75.75h-1.5a.75.75 0 0 1 0-1.5h1.5A.75.75 0 0 1 16 8Zm-8 5a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 8 13Zm3.536-1.464a.75.75 0 0 1 1.06 0l1.061 1.06a.75.75 0 0 1-1.06 1.061l-1.061-1.06a.75.75 0 0 1 0-1.061ZM2.343 2.343a.75.75 0 0 1 1.061 0l1.06 1.061a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018l-1.06-1.06a.75.75 0 0 1 0-1.06Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="sync-color-fg-muted">
              <svg height="16" class="octicon octicon-sync color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M1.705 8.005a.75.75 0 0 1 .834.656 5.5 5.5 0 0 0 9.592 2.97l-1.204-1.204a.25.25 0 0 1 .177-.427h3.646a.25.25 0 0 1 .25.25v3.646a.25.25 0 0 1-.427.177l-1.38-1.38A7.002 7.002 0 0 1 1.05 8.84a.75.75 0 0 1 .656-.834ZM8 2.5a5.487 5.487 0 0 0-4.131 1.869l1.204 1.204A.25.25 0 0 1 4.896 6H1.25A.25.25 0 0 1 1 5.75V2.104a.25.25 0 0 1 .427-.177l1.38 1.38A7.002 7.002 0 0 1 14.95 7.16a.75.75 0 0 1-1.49.178A5.5 5.5 0 0 0 8 2.5Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="trash-color-fg-muted">
              <svg height="16" class="octicon octicon-trash color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M11 1.75V3h2.25a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1 0-1.5H5V1.75C5 .784 5.784 0 6.75 0h2.5C10.216 0 11 .784 11 1.75ZM4.496 6.675l.66 6.6a.25.25 0 0 0 .249.225h5.19a.25.25 0 0 0 .249-.225l.66-6.6a.75.75 0 0 1 1.492.149l-.66 6.6A1.748 1.748 0 0 1 10.595 15h-5.19a1.75 1.75 0 0 1-1.741-1.575l-.66-6.6a.75.75 0 1 1 1.492-.15ZM6.5 1.75V3h3V1.75a.25.25 0 0 0-.25-.25h-2.5a.25.25 0 0 0-.25.25Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="key-color-fg-muted">
              <svg height="16" class="octicon octicon-key color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M10.5 0a5.499 5.499 0 1 1-1.288 10.848l-.932.932a.749.749 0 0 1-.53.22H7v.75a.749.749 0 0 1-.22.53l-.5.5a.749.749 0 0 1-.53.22H5v.75a.749.749 0 0 1-.22.53l-.5.5a.749.749 0 0 1-.53.22h-2A1.75 1.75 0 0 1 0 14.25v-2c0-.199.079-.389.22-.53l4.932-4.932A5.5 5.5 0 0 1 10.5 0Zm-4 5.5c-.001.431.069.86.205 1.269a.75.75 0 0 1-.181.768L1.5 12.56v1.69c0 .138.112.25.25.25h1.69l.06-.06v-1.19a.75.75 0 0 1 .75-.75h1.19l.06-.06v-1.19a.75.75 0 0 1 .75-.75h1.19l1.023-1.025a.75.75 0 0 1 .768-.18A4 4 0 1 0 6.5 5.5ZM11 6a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="comment-discussion-color-fg-muted">
              <svg height="16" class="octicon octicon-comment-discussion color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="bell-color-fg-muted">
              <svg height="16" class="octicon octicon-bell color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M8 16a2 2 0 0 0 1.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 0 0 8 16ZM3 5a5 5 0 0 1 10 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.519 1.519 0 0 1 13.482 13H2.518a1.516 1.516 0 0 1-1.263-2.36l1.703-2.554A.255.255 0 0 0 3 7.947Zm5-3.5A3.5 3.5 0 0 0 4.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.017.017 0 0 0-.003.01l.001.006c0 .002.002.004.004.006l.006.004.007.001h10.964l.007-.001.006-.004.004-.006.001-.007a.017.017 0 0 0-.003-.01l-1.703-2.554a1.745 1.745 0 0 1-.294-.97V5A3.5 3.5 0 0 0 8 1.5Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="bell-slash-color-fg-muted">
              <svg height="16" class="octicon octicon-bell-slash color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="m4.182 4.31.016.011 10.104 7.316.013.01 1.375.996a.75.75 0 1 1-.88 1.214L13.626 13H2.518a1.516 1.516 0 0 1-1.263-2.36l1.703-2.554A.255.255 0 0 0 3 7.947V5.305L.31 3.357a.75.75 0 1 1 .88-1.214Zm7.373 7.19L4.5 6.391v1.556c0 .346-.102.683-.294.97l-1.703 2.556a.017.017 0 0 0-.003.01c0 .005.002.009.005.012l.006.004.007.001ZM8 1.5c-.997 0-1.895.416-2.534 1.086A.75.75 0 1 1 4.38 1.55 5 5 0 0 1 13 5v2.373a.75.75 0 0 1-1.5 0V5A3.5 3.5 0 0 0 8 1.5ZM8 16a2 2 0 0 1-1.985-1.75c-.017-.137.097-.25.235-.25h3.5c.138 0 .252.113.235.25A2 2 0 0 1 8 16Z"></path></svg>
            </div>
            <div data-targets="command-palette-page-stack.localOcticons" data-octicon-id="paintbrush-color-fg-muted">
              <svg height="16" class="octicon octicon-paintbrush color-fg-muted" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path d="M11.134 1.535c.7-.509 1.416-.942 2.076-1.155.649-.21 1.463-.267 2.069.34.603.601.568 1.411.368 2.07-.202.668-.624 1.39-1.125 2.096-1.011 1.424-2.496 2.987-3.775 4.249-1.098 1.084-2.132 1.839-3.04 2.3a3.744 3.744 0 0 1-1.055 3.217c-.431.431-1.065.691-1.657.861-.614.177-1.294.287-1.914.357A21.151 21.151 0 0 1 .797 16H.743l.007-.75H.749L.742 16a.75.75 0 0 1-.743-.742l.743-.008-.742.007v-.054a21.25 21.25 0 0 1 .13-2.284c.067-.647.187-1.287.358-1.914.17-.591.43-1.226.86-1.657a3.746 3.746 0 0 1 3.227-1.054c.466-.893 1.225-1.907 2.314-2.982 1.271-1.255 2.833-2.75 4.245-3.777ZM1.62 13.089c-.051.464-.086.929-.104 1.395.466-.018.932-.053 1.396-.104a10.511 10.511 0 0 0 1.668-.309c.526-.151.856-.325 1.011-.48a2.25 2.25 0 1 0-3.182-3.182c-.155.155-.329.485-.48 1.01a10.515 10.515 0 0 0-.309 1.67Zm10.396-10.34c-1.224.89-2.605 2.189-3.822 3.384l1.718 1.718c1.21-1.205 2.51-2.597 3.387-3.833.47-.662.78-1.227.912-1.662.134-.444.032-.551.009-.575h-.001V1.78c-.014-.014-.113-.113-.548.027-.432.14-.995.462-1.655.942Zm-4.832 7.266-.001.001a9.859 9.859 0 0 0 1.63-1.142L7.155 7.216a9.7 9.7 0 0 0-1.161 1.607c.482.302.889.71 1.19 1.192Z"></path></svg>
            </div>

            <command-palette-item-group
              data-group-id="top"
              data-group-title="Top result"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="0"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="commands"
              data-group-title="Commands"
              data-group-hint="Type &gt; to filter"
              data-group-limits="{&quot;static_items_page&quot;:50,&quot;issue&quot;:50,&quot;pull_request&quot;:50,&quot;discussion&quot;:50}"
              data-default-priority="1"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="global_commands"
              data-group-title="Global Commands"
              data-group-hint="Type &gt; to filter"
              data-group-limits="{&quot;issue&quot;:0,&quot;pull_request&quot;:0,&quot;discussion&quot;:0}"
              data-default-priority="2"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="this_page"
              data-group-title="This Page"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="3"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="files"
              data-group-title="Files"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="4"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="default"
              data-group-title="Default"
              data-group-hint=""
              data-group-limits="{&quot;static_items_page&quot;:50}"
              data-default-priority="5"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="pages"
              data-group-title="Pages"
              data-group-hint=""
              data-group-limits="{&quot;repository&quot;:10}"
              data-default-priority="6"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="access_policies"
              data-group-title="Access Policies"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="7"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="organizations"
              data-group-title="Organizations"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="8"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="repositories"
              data-group-title="Repositories"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="9"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="references"
              data-group-title="Issues, pull requests, and discussions"
              data-group-hint="Type # to filter"
              data-group-limits="{}"
              data-default-priority="10"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="teams"
              data-group-title="Teams"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="11"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="users"
              data-group-title="Users"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="12"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="memex_projects"
              data-group-title="Projects"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="13"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="projects"
              data-group-title="Projects (classic)"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="14"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="footer"
              data-group-title="Footer"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="15"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="modes_help"
              data-group-title="Modes"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="16"
            >
            </command-palette-item-group>
            <command-palette-item-group
              data-group-id="filters_help"
              data-group-title="Use filters in issues, pull requests, discussions, and projects"
              data-group-hint=""
              data-group-limits="{}"
              data-default-priority="17"
            >
            </command-palette-item-group>

            <command-palette-page
              data-page-title="esphome"
              data-scope-id="MDEyOk9yZ2FuaXphdGlvbjQ1OTE5NzU5"
              data-scope-type="owner"
              data-targets="command-palette-page-stack.defaultPages"
              hidden
            >
            </command-palette-page>
            <command-palette-page
              data-page-title="esphome"
              data-scope-id="MDEwOlJlcG9zaXRvcnkxMjg0Nzk2NDQ="
              data-scope-type="repository"
              data-targets="command-palette-page-stack.defaultPages"
              hidden
            >
            </command-palette-page>
        </div>

        <command-palette-page data-is-root>
        </command-palette-page>
          <command-palette-page
            data-page-title="esphome"
            data-scope-id="MDEyOk9yZ2FuaXphdGlvbjQ1OTE5NzU5"
            data-scope-type="owner"
          >
          </command-palette-page>
          <command-palette-page
            data-page-title="esphome"
            data-scope-id="MDEwOlJlcG9zaXRvcnkxMjg0Nzk2NDQ="
            data-scope-type="repository"
          >
          </command-palette-page>
      </command-palette-page-stack>

      <server-defined-provider data-type="search-links" data-targets="command-palette.serverDefinedProviderElements"></server-defined-provider>
      <server-defined-provider data-type="help" data-targets="command-palette.serverDefinedProviderElements">
          <command-palette-help
            data-group="modes_help"
              data-prefix="#"
              data-scope-types="[&quot;&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Search for <strong>issues</strong> and <strong>pull requests</strong></span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd">#</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="modes_help"
              data-prefix="#"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Search for <strong>issues, pull requests, discussions,</strong> and <strong>projects</strong></span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd">#</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="modes_help"
              data-prefix="@"
              data-scope-types="[&quot;&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Search for <strong>organizations, repositories,</strong> and <strong>users</strong></span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd">@</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="modes_help"
              data-prefix="!"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Search for <strong>projects</strong></span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd">!</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="modes_help"
              data-prefix="/"
              data-scope-types="[&quot;repository&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Search for <strong>files</strong></span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd">/</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="modes_help"
              data-prefix="&gt;"
          >
            <span data-target="command-palette-help.titleElement">Activate <strong>command mode</strong></span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd">&gt;</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# author:@me"
          >
            <span data-target="command-palette-help.titleElement">Search your issues, pull requests, and discussions</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># author:@me</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# author:@me"
          >
            <span data-target="command-palette-help.titleElement">Search your issues, pull requests, and discussions</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># author:@me</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# is:pr"
          >
            <span data-target="command-palette-help.titleElement">Filter to pull requests</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># is:pr</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# is:issue"
          >
            <span data-target="command-palette-help.titleElement">Filter to issues</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># is:issue</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# is:discussion"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Filter to discussions</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># is:discussion</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# is:project"
              data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
          >
            <span data-target="command-palette-help.titleElement">Filter to projects</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># is:project</kbd>
              </span>
          </command-palette-help>
          <command-palette-help
            data-group="filters_help"
              data-prefix="# is:open"
          >
            <span data-target="command-palette-help.titleElement">Filter to open issues, pull requests, and discussions</span>
              <span data-target="command-palette-help.hintElement">
                <kbd class="hx_kbd"># is:open</kbd>
              </span>
          </command-palette-help>
      </server-defined-provider>

        <server-defined-provider
          data-type="commands"
          data-fetch-debounce="0"
            data-src="/command_palette/commands"
          data-supported-modes="[]"
            data-supports-commands
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="prefetched"
          data-fetch-debounce="0"
            data-src="/command_palette/jump_to_page_navigation"
          data-supported-modes="[&quot;&quot;]"
            data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;,&quot;repository&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/issues"
          data-supported-modes="[&quot;#&quot;,&quot;#&quot;]"
            data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;,&quot;&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/jump_to"
          data-supported-modes="[&quot;@&quot;,&quot;@&quot;]"
            data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/jump_to_members_only"
          data-supported-modes="[&quot;@&quot;,&quot;@&quot;,&quot;&quot;,&quot;&quot;]"
            data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="prefetched"
          data-fetch-debounce="0"
            data-src="/command_palette/jump_to_members_only_prefetched"
          data-supported-modes="[&quot;@&quot;,&quot;@&quot;,&quot;&quot;,&quot;&quot;]"
            data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="files"
          data-fetch-debounce="0"
            data-src="/command_palette/files"
          data-supported-modes="[&quot;/&quot;]"
            data-supported-scope-types="[&quot;repository&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/discussions"
          data-supported-modes="[&quot;#&quot;]"
            data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/projects"
          data-supported-modes="[&quot;#&quot;,&quot;!&quot;]"
            data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="prefetched"
          data-fetch-debounce="0"
            data-src="/command_palette/recent_issues"
          data-supported-modes="[&quot;#&quot;,&quot;#&quot;]"
            data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;,&quot;&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/teams"
          data-supported-modes="[&quot;@&quot;,&quot;&quot;]"
            data-supported-scope-types="[&quot;owner&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
        <server-defined-provider
          data-type="remote"
          data-fetch-debounce="200"
            data-src="/command_palette/name_with_owner_repository"
          data-supported-modes="[&quot;@&quot;,&quot;@&quot;,&quot;&quot;,&quot;&quot;]"
            data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;]"
          
          data-targets="command-palette.serverDefinedProviderElements"
          ></server-defined-provider>
    </command-palette>
  </details-dialog>
</details>

<div class="position-fixed bottom-0 left-0 ml-5 mb-5 js-command-palette-toasts" style="z-index: 1000">
  <div hidden class="Toast Toast--loading">
    <span class="Toast-icon">
      <svg class="Toast--spinner" viewBox="0 0 32 32" width="18" height="18" aria-hidden="true">
        <path
          fill="#959da5"
          d="M16 0 A16 16 0 0 0 16 32 A16 16 0 0 0 16 0 M16 4 A12 12 0 0 1 16 28 A12 12 0 0 1 16 4"
        />
        <path fill="#ffffff" d="M16 0 A16 16 0 0 1 32 16 L28 16 A12 12 0 0 0 16 4z"></path>
      </svg>
    </span>
    <span class="Toast-content"></span>
  </div>

  <div hidden class="anim-fade-in fast Toast Toast--error">
    <span class="Toast-icon">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-stop">
    <path d="M4.47.22A.749.749 0 0 1 5 0h6c.199 0 .389.079.53.22l4.25 4.25c.141.14.22.331.22.53v6a.749.749 0 0 1-.22.53l-4.25 4.25A.749.749 0 0 1 11 16H5a.749.749 0 0 1-.53-.22L.22 11.53A.749.749 0 0 1 0 11V5c0-.199.079-.389.22-.53Zm.84 1.28L1.5 5.31v5.38l3.81 3.81h5.38l3.81-3.81V5.31L10.69 1.5ZM8 4a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 4Zm0 8a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path>
</svg>
    </span>
    <span class="Toast-content"></span>
  </div>

  <div hidden class="anim-fade-in fast Toast Toast--warning">
    <span class="Toast-icon">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
    </span>
    <span class="Toast-content"></span>
  </div>


  <div hidden class="anim-fade-in fast Toast Toast--success">
    <span class="Toast-icon">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </span>
    <span class="Toast-content"></span>
  </div>

  <div hidden class="anim-fade-in fast Toast">
    <span class="Toast-icon">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-info">
    <path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8Zm8-6.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM6.5 7.75A.75.75 0 0 1 7.25 7h1a.75.75 0 0 1 .75.75v2.75h.25a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1 0-1.5h.25v-2h-.25a.75.75 0 0 1-.75-.75ZM8 6a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path>
</svg>
    </span>
    <span class="Toast-content"></span>
  </div>
</div>


  <div
    class="application-main "
    data-commit-hovercards-enabled
    data-discussion-hovercards-enabled
    data-issue-and-pr-hovercards-enabled
  >
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" >
      
      
    

    






    
  <div id="repository-container-header" data-turbo-replace hidden></div>




<turbo-frame id="repo-content-turbo-frame" target="_top" data-turbo-action="advance" class="">
    <div id="repo-content-pjax-container" class="repository-content " >
      <a href="https://github.dev/" class="d-none js-github-dev-shortcut" data-hotkey=".,Mod+Alt+.">Open in github.dev</a>
  <a href="https://github.dev/" class="d-none js-github-dev-new-tab-shortcut" data-hotkey="Shift+.,Shift+&gt;,&gt;" target="_blank" rel="noopener noreferrer">Open in a new github.dev tab</a>
    <a class="d-none" data-hotkey=",,Mod+Alt+," target="_blank" href="/codespaces/new/esphome/esphome/tree/dev?resume=1">Open in codespace</a>




    
      
    






<react-app
  app-name="react-code-view"
  initial-path="/esphome/esphome/blob/dev/esphome/components/dallas_temp/dallas_temp.cpp"
  style="display: block; min-height: calc(100vh - 64px)" 
  data-ssr="true"
  data-lazy="false"
  data-alternate="false"
>
  
  <script type="application/json" data-target="react-app.embeddedData">{"payload":{"allShortcutsEnabled":true,"fileTree":{"esphome/components/dallas_temp":{"items":[{"name":"__init__.py","path":"esphome/components/dallas_temp/__init__.py","contentType":"file"},{"name":"dallas_temp.cpp","path":"esphome/components/dallas_temp/dallas_temp.cpp","contentType":"file"},{"name":"dallas_temp.h","path":"esphome/components/dallas_temp/dallas_temp.h","contentType":"file"},{"name":"sensor.py","path":"esphome/components/dallas_temp/sensor.py","contentType":"file"}],"totalCount":4},"esphome/components":{"items":[{"name":"a01nyub","path":"esphome/components/a01nyub","contentType":"directory"},{"name":"a02yyuw","path":"esphome/components/a02yyuw","contentType":"directory"},{"name":"a4988","path":"esphome/components/a4988","contentType":"directory"},{"name":"absolute_humidity","path":"esphome/components/absolute_humidity","contentType":"directory"},{"name":"ac_dimmer","path":"esphome/components/ac_dimmer","contentType":"directory"},{"name":"adalight","path":"esphome/components/adalight","contentType":"directory"},{"name":"adc","path":"esphome/components/adc","contentType":"directory"},{"name":"adc128s102","path":"esphome/components/adc128s102","contentType":"directory"},{"name":"addressable_light","path":"esphome/components/addressable_light","contentType":"directory"},{"name":"ade7880","path":"esphome/components/ade7880","contentType":"directory"},{"name":"ade7953","path":"esphome/components/ade7953","contentType":"directory"},{"name":"ade7953_base","path":"esphome/components/ade7953_base","contentType":"directory"},{"name":"ade7953_i2c","path":"esphome/components/ade7953_i2c","contentType":"directory"},{"name":"ade7953_spi","path":"esphome/components/ade7953_spi","contentType":"directory"},{"name":"ads1115","path":"esphome/components/ads1115","contentType":"directory"},{"name":"ads1118","path":"esphome/components/ads1118","contentType":"directory"},{"name":"ags10","path":"esphome/components/ags10","contentType":"directory"},{"name":"aht10","path":"esphome/components/aht10","contentType":"directory"},{"name":"airthings_ble","path":"esphome/components/airthings_ble","contentType":"directory"},{"name":"airthings_wave_base","path":"esphome/components/airthings_wave_base","contentType":"directory"},{"name":"airthings_wave_mini","path":"esphome/components/airthings_wave_mini","contentType":"directory"},{"name":"airthings_wave_plus","path":"esphome/components/airthings_wave_plus","contentType":"directory"},{"name":"alarm_control_panel","path":"esphome/components/alarm_control_panel","contentType":"directory"},{"name":"alpha3","path":"esphome/components/alpha3","contentType":"directory"},{"name":"am2315c","path":"esphome/components/am2315c","contentType":"directory"},{"name":"am2320","path":"esphome/components/am2320","contentType":"directory"},{"name":"am43","path":"esphome/components/am43","contentType":"directory"},{"name":"analog_threshold","path":"esphome/components/analog_threshold","contentType":"directory"},{"name":"animation","path":"esphome/components/animation","contentType":"directory"},{"name":"anova","path":"esphome/components/anova","contentType":"directory"},{"name":"apds9960","path":"esphome/components/apds9960","contentType":"directory"},{"name":"api","path":"esphome/components/api","contentType":"directory"},{"name":"as3935","path":"esphome/components/as3935","contentType":"directory"},{"name":"as3935_i2c","path":"esphome/components/as3935_i2c","contentType":"directory"},{"name":"as3935_spi","path":"esphome/components/as3935_spi","contentType":"directory"},{"name":"as5600","path":"esphome/components/as5600","contentType":"directory"},{"name":"as7341","path":"esphome/components/as7341","contentType":"directory"},{"name":"async_tcp","path":"esphome/components/async_tcp","contentType":"directory"},{"name":"at581x","path":"esphome/components/at581x","contentType":"directory"},{"name":"atc_mithermometer","path":"esphome/components/atc_mithermometer","contentType":"directory"},{"name":"atm90e26","path":"esphome/components/atm90e26","contentType":"directory"},{"name":"atm90e32","path":"esphome/components/atm90e32","contentType":"directory"},{"name":"b_parasite","path":"esphome/components/b_parasite","contentType":"directory"},{"name":"ballu","path":"esphome/components/ballu","contentType":"directory"},{"name":"bang_bang","path":"esphome/components/bang_bang","contentType":"directory"},{"name":"bedjet","path":"esphome/components/bedjet","contentType":"directory"},{"name":"beken_spi_led_strip","path":"esphome/components/beken_spi_led_strip","contentType":"directory"},{"name":"bh1750","path":"esphome/components/bh1750","contentType":"directory"},{"name":"binary","path":"esphome/components/binary","contentType":"directory"},{"name":"binary_sensor","path":"esphome/components/binary_sensor","contentType":"directory"},{"name":"binary_sensor_map","path":"esphome/components/binary_sensor_map","contentType":"directory"},{"name":"bk72xx","path":"esphome/components/bk72xx","contentType":"directory"},{"name":"bl0939","path":"esphome/components/bl0939","contentType":"directory"},{"name":"bl0940","path":"esphome/components/bl0940","contentType":"directory"},{"name":"bl0942","path":"esphome/components/bl0942","contentType":"directory"},{"name":"ble_client","path":"esphome/components/ble_client","contentType":"directory"},{"name":"ble_presence","path":"esphome/components/ble_presence","contentType":"directory"},{"name":"ble_rssi","path":"esphome/components/ble_rssi","contentType":"directory"},{"name":"ble_scanner","path":"esphome/components/ble_scanner","contentType":"directory"},{"name":"bluetooth_proxy","path":"esphome/components/bluetooth_proxy","contentType":"directory"},{"name":"bme280_base","path":"esphome/components/bme280_base","contentType":"directory"},{"name":"bme280_i2c","path":"esphome/components/bme280_i2c","contentType":"directory"},{"name":"bme280_spi","path":"esphome/components/bme280_spi","contentType":"directory"},{"name":"bme680","path":"esphome/components/bme680","contentType":"directory"},{"name":"bme680_bsec","path":"esphome/components/bme680_bsec","contentType":"directory"},{"name":"bmi160","path":"esphome/components/bmi160","contentType":"directory"},{"name":"bmp085","path":"esphome/components/bmp085","contentType":"directory"},{"name":"bmp280","path":"esphome/components/bmp280","contentType":"directory"},{"name":"bmp3xx","path":"esphome/components/bmp3xx","contentType":"directory"},{"name":"bmp3xx_base","path":"esphome/components/bmp3xx_base","contentType":"directory"},{"name":"bmp3xx_i2c","path":"esphome/components/bmp3xx_i2c","contentType":"directory"},{"name":"bmp3xx_spi","path":"esphome/components/bmp3xx_spi","contentType":"directory"},{"name":"bmp581","path":"esphome/components/bmp581","contentType":"directory"},{"name":"bp1658cj","path":"esphome/components/bp1658cj","contentType":"directory"},{"name":"bp5758d","path":"esphome/components/bp5758d","contentType":"directory"},{"name":"button","path":"esphome/components/button","contentType":"directory"},{"name":"canbus","path":"esphome/components/canbus","contentType":"directory"},{"name":"cap1188","path":"esphome/components/cap1188","contentType":"directory"},{"name":"captive_portal","path":"esphome/components/captive_portal","contentType":"directory"},{"name":"ccs811","path":"esphome/components/ccs811","contentType":"directory"},{"name":"cd74hc4067","path":"esphome/components/cd74hc4067","contentType":"directory"},{"name":"climate","path":"esphome/components/climate","contentType":"directory"},{"name":"climate_ir","path":"esphome/components/climate_ir","contentType":"directory"},{"name":"climate_ir_lg","path":"esphome/components/climate_ir_lg","contentType":"directory"},{"name":"color","path":"esphome/components/color","contentType":"directory"},{"name":"color_temperature","path":"esphome/components/color_temperature","contentType":"directory"},{"name":"combination","path":"esphome/components/combination","contentType":"directory"},{"name":"coolix","path":"esphome/components/coolix","contentType":"directory"},{"name":"copy","path":"esphome/components/copy","contentType":"directory"},{"name":"cover","path":"esphome/components/cover","contentType":"directory"},{"name":"cs5460a","path":"esphome/components/cs5460a","contentType":"directory"},{"name":"cse7761","path":"esphome/components/cse7761","contentType":"directory"},{"name":"cse7766","path":"esphome/components/cse7766","contentType":"directory"},{"name":"cst226","path":"esphome/components/cst226","contentType":"directory"},{"name":"cst816","path":"esphome/components/cst816","contentType":"directory"},{"name":"ct_clamp","path":"esphome/components/ct_clamp","contentType":"directory"},{"name":"current_based","path":"esphome/components/current_based","contentType":"directory"},{"name":"custom","path":"esphome/components/custom","contentType":"directory"},{"name":"custom_component","path":"esphome/components/custom_component","contentType":"directory"},{"name":"cwww","path":"esphome/components/cwww","contentType":"directory"},{"name":"dac7678","path":"esphome/components/dac7678","contentType":"directory"},{"name":"daikin","path":"esphome/components/daikin","contentType":"directory"},{"name":"daikin_arc","path":"esphome/components/daikin_arc","contentType":"directory"},{"name":"daikin_brc","path":"esphome/components/daikin_brc","contentType":"directory"},{"name":"dallas","path":"esphome/components/dallas","contentType":"directory"},{"name":"dallas_temp","path":"esphome/components/dallas_temp","contentType":"directory"},{"name":"daly_bms","path":"esphome/components/daly_bms","contentType":"directory"},{"name":"dashboard_import","path":"esphome/components/dashboard_import","contentType":"directory"},{"name":"datetime","path":"esphome/components/datetime","contentType":"directory"},{"name":"debug","path":"esphome/components/debug","contentType":"directory"},{"name":"deep_sleep","path":"esphome/components/deep_sleep","contentType":"directory"},{"name":"delonghi","path":"esphome/components/delonghi","contentType":"directory"},{"name":"demo","path":"esphome/components/demo","contentType":"directory"},{"name":"dfplayer","path":"esphome/components/dfplayer","contentType":"directory"},{"name":"dfrobot_sen0395","path":"esphome/components/dfrobot_sen0395","contentType":"directory"},{"name":"dht","path":"esphome/components/dht","contentType":"directory"},{"name":"dht12","path":"esphome/components/dht12","contentType":"directory"},{"name":"display","path":"esphome/components/display","contentType":"directory"},{"name":"display_menu_base","path":"esphome/components/display_menu_base","contentType":"directory"},{"name":"dps310","path":"esphome/components/dps310","contentType":"directory"},{"name":"ds1307","path":"esphome/components/ds1307","contentType":"directory"},{"name":"dsmr","path":"esphome/components/dsmr","contentType":"directory"},{"name":"duty_cycle","path":"esphome/components/duty_cycle","contentType":"directory"},{"name":"duty_time","path":"esphome/components/duty_time","contentType":"directory"},{"name":"e131","path":"esphome/components/e131","contentType":"directory"},{"name":"ee895","path":"esphome/components/ee895","contentType":"directory"},{"name":"ektf2232","path":"esphome/components/ektf2232","contentType":"directory"},{"name":"emc2101","path":"esphome/components/emc2101","contentType":"directory"},{"name":"emmeti","path":"esphome/components/emmeti","contentType":"directory"},{"name":"endstop","path":"esphome/components/endstop","contentType":"directory"},{"name":"ens160","path":"esphome/components/ens160","contentType":"directory"},{"name":"ens160_base","path":"esphome/components/ens160_base","contentType":"directory"},{"name":"ens160_i2c","path":"esphome/components/ens160_i2c","contentType":"directory"},{"name":"ens160_spi","path":"esphome/components/ens160_spi","contentType":"directory"},{"name":"ens210","path":"esphome/components/ens210","contentType":"directory"},{"name":"esp32","path":"esphome/components/esp32","contentType":"directory"},{"name":"esp32_ble","path":"esphome/components/esp32_ble","contentType":"directory"},{"name":"esp32_ble_beacon","path":"esphome/components/esp32_ble_beacon","contentType":"directory"},{"name":"esp32_ble_client","path":"esphome/components/esp32_ble_client","contentType":"directory"},{"name":"esp32_ble_server","path":"esphome/components/esp32_ble_server","contentType":"directory"},{"name":"esp32_ble_tracker","path":"esphome/components/esp32_ble_tracker","contentType":"directory"},{"name":"esp32_camera","path":"esphome/components/esp32_camera","contentType":"directory"},{"name":"esp32_camera_web_server","path":"esphome/components/esp32_camera_web_server","contentType":"directory"},{"name":"esp32_can","path":"esphome/components/esp32_can","contentType":"directory"},{"name":"esp32_dac","path":"esphome/components/esp32_dac","contentType":"directory"},{"name":"esp32_hall","path":"esphome/components/esp32_hall","contentType":"directory"},{"name":"esp32_improv","path":"esphome/components/esp32_improv","contentType":"directory"},{"name":"esp32_rmt","path":"esphome/components/esp32_rmt","contentType":"directory"},{"name":"esp32_rmt_led_strip","path":"esphome/components/esp32_rmt_led_strip","contentType":"directory"},{"name":"esp32_touch","path":"esphome/components/esp32_touch","contentType":"directory"},{"name":"esp8266","path":"esphome/components/esp8266","contentType":"directory"},{"name":"esp8266_pwm","path":"esphome/components/esp8266_pwm","contentType":"directory"},{"name":"esphome","path":"esphome/components/esphome","contentType":"directory"},{"name":"ethernet","path":"esphome/components/ethernet","contentType":"directory"},{"name":"ethernet_info","path":"esphome/components/ethernet_info","contentType":"directory"},{"name":"event","path":"esphome/components/event","contentType":"directory"},{"name":"exposure_notifications","path":"esphome/components/exposure_notifications","contentType":"directory"},{"name":"external_components","path":"esphome/components/external_components","contentType":"directory"},{"name":"ezo","path":"esphome/components/ezo","contentType":"directory"},{"name":"ezo_pmp","path":"esphome/components/ezo_pmp","contentType":"directory"},{"name":"factory_reset","path":"esphome/components/factory_reset","contentType":"directory"},{"name":"fan","path":"esphome/components/fan","contentType":"directory"},{"name":"fastled_base","path":"esphome/components/fastled_base","contentType":"directory"},{"name":"fastled_clockless","path":"esphome/components/fastled_clockless","contentType":"directory"},{"name":"fastled_spi","path":"esphome/components/fastled_spi","contentType":"directory"},{"name":"feedback","path":"esphome/components/feedback","contentType":"directory"},{"name":"fingerprint_grow","path":"esphome/components/fingerprint_grow","contentType":"directory"},{"name":"font","path":"esphome/components/font","contentType":"directory"},{"name":"fs3000","path":"esphome/components/fs3000","contentType":"directory"},{"name":"ft5x06","path":"esphome/components/ft5x06","contentType":"directory"},{"name":"ft63x6","path":"esphome/components/ft63x6","contentType":"directory"},{"name":"fujitsu_general","path":"esphome/components/fujitsu_general","contentType":"directory"},{"name":"gcja5","path":"esphome/components/gcja5","contentType":"directory"},{"name":"gdk101","path":"esphome/components/gdk101","contentType":"directory"},{"name":"globals","path":"esphome/components/globals","contentType":"directory"},{"name":"gp8403","path":"esphome/components/gp8403","contentType":"directory"},{"name":"gpio","path":"esphome/components/gpio","contentType":"directory"},{"name":"gps","path":"esphome/components/gps","contentType":"directory"},{"name":"graph","path":"esphome/components/graph","contentType":"directory"},{"name":"graphical_display_menu","path":"esphome/components/graphical_display_menu","contentType":"directory"},{"name":"gree","path":"esphome/components/gree","contentType":"directory"},{"name":"grove_tb6612fng","path":"esphome/components/grove_tb6612fng","contentType":"directory"},{"name":"growatt_solar","path":"esphome/components/growatt_solar","contentType":"directory"},{"name":"gt911","path":"esphome/components/gt911","contentType":"directory"},{"name":"haier","path":"esphome/components/haier","contentType":"directory"},{"name":"havells_solar","path":"esphome/components/havells_solar","contentType":"directory"},{"name":"hbridge","path":"esphome/components/hbridge","contentType":"directory"},{"name":"hdc1080","path":"esphome/components/hdc1080","contentType":"directory"},{"name":"he60r","path":"esphome/components/he60r","contentType":"directory"},{"name":"heatpumpir","path":"esphome/components/heatpumpir","contentType":"directory"},{"name":"hitachi_ac344","path":"esphome/components/hitachi_ac344","contentType":"directory"},{"name":"hitachi_ac424","path":"esphome/components/hitachi_ac424","contentType":"directory"},{"name":"hlw8012","path":"esphome/components/hlw8012","contentType":"directory"},{"name":"hm3301","path":"esphome/components/hm3301","contentType":"directory"},{"name":"hmc5883l","path":"esphome/components/hmc5883l","contentType":"directory"},{"name":"homeassistant","path":"esphome/components/homeassistant","contentType":"directory"},{"name":"honeywell_hih_i2c","path":"esphome/components/honeywell_hih_i2c","contentType":"directory"},{"name":"honeywellabp","path":"esphome/components/honeywellabp","contentType":"directory"},{"name":"honeywellabp2_i2c","path":"esphome/components/honeywellabp2_i2c","contentType":"directory"},{"name":"host","path":"esphome/components/host","contentType":"directory"},{"name":"hrxl_maxsonar_wr","path":"esphome/components/hrxl_maxsonar_wr","contentType":"directory"},{"name":"hte501","path":"esphome/components/hte501","contentType":"directory"},{"name":"http_request","path":"esphome/components/http_request","contentType":"directory"},{"name":"htu21d","path":"esphome/components/htu21d","contentType":"directory"},{"name":"htu31d","path":"esphome/components/htu31d","contentType":"directory"},{"name":"hx711","path":"esphome/components/hx711","contentType":"directory"},{"name":"hydreon_rgxx","path":"esphome/components/hydreon_rgxx","contentType":"directory"},{"name":"hyt271","path":"esphome/components/hyt271","contentType":"directory"},{"name":"i2c","path":"esphome/components/i2c","contentType":"directory"},{"name":"i2s_audio","path":"esphome/components/i2s_audio","contentType":"directory"},{"name":"iaqcore","path":"esphome/components/iaqcore","contentType":"directory"},{"name":"ili9341","path":"esphome/components/ili9341","contentType":"directory"},{"name":"ili9xxx","path":"esphome/components/ili9xxx","contentType":"directory"},{"name":"image","path":"esphome/components/image","contentType":"directory"},{"name":"improv_base","path":"esphome/components/improv_base","contentType":"directory"},{"name":"improv_serial","path":"esphome/components/improv_serial","contentType":"directory"},{"name":"ina219","path":"esphome/components/ina219","contentType":"directory"},{"name":"ina226","path":"esphome/components/ina226","contentType":"directory"},{"name":"ina260","path":"esphome/components/ina260","contentType":"directory"},{"name":"ina2xx_base","path":"esphome/components/ina2xx_base","contentType":"directory"},{"name":"ina2xx_i2c","path":"esphome/components/ina2xx_i2c","contentType":"directory"},{"name":"ina2xx_spi","path":"esphome/components/ina2xx_spi","contentType":"directory"},{"name":"ina3221","path":"esphome/components/ina3221","contentType":"directory"},{"name":"inkbird_ibsth1_mini","path":"esphome/components/inkbird_ibsth1_mini","contentType":"directory"},{"name":"inkplate6","path":"esphome/components/inkplate6","contentType":"directory"},{"name":"integration","path":"esphome/components/integration","contentType":"directory"},{"name":"internal_temperature","path":"esphome/components/internal_temperature","contentType":"directory"},{"name":"interval","path":"esphome/components/interval","contentType":"directory"},{"name":"jsn_sr04t","path":"esphome/components/jsn_sr04t","contentType":"directory"},{"name":"json","path":"esphome/components/json","contentType":"directory"},{"name":"kalman_combinator","path":"esphome/components/kalman_combinator","contentType":"directory"},{"name":"kamstrup_kmp","path":"esphome/components/kamstrup_kmp","contentType":"directory"},{"name":"key_collector","path":"esphome/components/key_collector","contentType":"directory"},{"name":"key_provider","path":"esphome/components/key_provider","contentType":"directory"},{"name":"kmeteriso","path":"esphome/components/kmeteriso","contentType":"directory"},{"name":"kuntze","path":"esphome/components/kuntze","contentType":"directory"},{"name":"lcd_base","path":"esphome/components/lcd_base","contentType":"directory"},{"name":"lcd_gpio","path":"esphome/components/lcd_gpio","contentType":"directory"},{"name":"lcd_menu","path":"esphome/components/lcd_menu","contentType":"directory"},{"name":"lcd_pcf8574","path":"esphome/components/lcd_pcf8574","contentType":"directory"},{"name":"ld2410","path":"esphome/components/ld2410","contentType":"directory"},{"name":"ld2420","path":"esphome/components/ld2420","contentType":"directory"},{"name":"ledc","path":"esphome/components/ledc","contentType":"directory"},{"name":"libretiny","path":"esphome/components/libretiny","contentType":"directory"},{"name":"libretiny_pwm","path":"esphome/components/libretiny_pwm","contentType":"directory"},{"name":"light","path":"esphome/components/light","contentType":"directory"},{"name":"lightwaverf","path":"esphome/components/lightwaverf","contentType":"directory"},{"name":"lilygo_t5_47","path":"esphome/components/lilygo_t5_47","contentType":"directory"},{"name":"lock","path":"esphome/components/lock","contentType":"directory"},{"name":"logger","path":"esphome/components/logger","contentType":"directory"},{"name":"ltr390","path":"esphome/components/ltr390","contentType":"directory"},{"name":"ltr_als_ps","path":"esphome/components/ltr_als_ps","contentType":"directory"},{"name":"matrix_keypad","path":"esphome/components/matrix_keypad","contentType":"directory"},{"name":"max31855","path":"esphome/components/max31855","contentType":"directory"},{"name":"max31856","path":"esphome/components/max31856","contentType":"directory"},{"name":"max31865","path":"esphome/components/max31865","contentType":"directory"},{"name":"max44009","path":"esphome/components/max44009","contentType":"directory"},{"name":"max6675","path":"esphome/components/max6675","contentType":"directory"},{"name":"max6956","path":"esphome/components/max6956","contentType":"directory"},{"name":"max7219","path":"esphome/components/max7219","contentType":"directory"},{"name":"max7219digit","path":"esphome/components/max7219digit","contentType":"directory"},{"name":"max9611","path":"esphome/components/max9611","contentType":"directory"},{"name":"mcp23008","path":"esphome/components/mcp23008","contentType":"directory"},{"name":"mcp23016","path":"esphome/components/mcp23016","contentType":"directory"},{"name":"mcp23017","path":"esphome/components/mcp23017","contentType":"directory"},{"name":"mcp23s08","path":"esphome/components/mcp23s08","contentType":"directory"},{"name":"mcp23s17","path":"esphome/components/mcp23s17","contentType":"directory"},{"name":"mcp23x08_base","path":"esphome/components/mcp23x08_base","contentType":"directory"},{"name":"mcp23x17_base","path":"esphome/components/mcp23x17_base","contentType":"directory"},{"name":"mcp23xxx_base","path":"esphome/components/mcp23xxx_base","contentType":"directory"},{"name":"mcp2515","path":"esphome/components/mcp2515","contentType":"directory"},{"name":"mcp3008","path":"esphome/components/mcp3008","contentType":"directory"},{"name":"mcp3204","path":"esphome/components/mcp3204","contentType":"directory"},{"name":"mcp4725","path":"esphome/components/mcp4725","contentType":"directory"},{"name":"mcp4728","path":"esphome/components/mcp4728","contentType":"directory"},{"name":"mcp47a1","path":"esphome/components/mcp47a1","contentType":"directory"},{"name":"mcp9600","path":"esphome/components/mcp9600","contentType":"directory"},{"name":"mcp9808","path":"esphome/components/mcp9808","contentType":"directory"},{"name":"md5","path":"esphome/components/md5","contentType":"directory"},{"name":"mdns","path":"esphome/components/mdns","contentType":"directory"},{"name":"media_player","path":"esphome/components/media_player","contentType":"directory"},{"name":"mhz19","path":"esphome/components/mhz19","contentType":"directory"},{"name":"micro_wake_word","path":"esphome/components/micro_wake_word","contentType":"directory"},{"name":"micronova","path":"esphome/components/micronova","contentType":"directory"},{"name":"microphone","path":"esphome/components/microphone","contentType":"directory"},{"name":"mics_4514","path":"esphome/components/mics_4514","contentType":"directory"},{"name":"midea","path":"esphome/components/midea","contentType":"directory"},{"name":"midea_ac","path":"esphome/components/midea_ac","contentType":"directory"},{"name":"midea_ir","path":"esphome/components/midea_ir","contentType":"directory"},{"name":"mitsubishi","path":"esphome/components/mitsubishi","contentType":"directory"},{"name":"mlx90393","path":"esphome/components/mlx90393","contentType":"directory"},{"name":"mlx90614","path":"esphome/components/mlx90614","contentType":"directory"},{"name":"mmc5603","path":"esphome/components/mmc5603","contentType":"directory"},{"name":"mmc5983","path":"esphome/components/mmc5983","contentType":"directory"},{"name":"modbus","path":"esphome/components/modbus","contentType":"directory"},{"name":"modbus_controller","path":"esphome/components/modbus_controller","contentType":"directory"},{"name":"monochromatic","path":"esphome/components/monochromatic","contentType":"directory"},{"name":"mopeka_ble","path":"esphome/components/mopeka_ble","contentType":"directory"},{"name":"mopeka_pro_check","path":"esphome/components/mopeka_pro_check","contentType":"directory"},{"name":"mopeka_std_check","path":"esphome/components/mopeka_std_check","contentType":"directory"},{"name":"mpl3115a2","path":"esphome/components/mpl3115a2","contentType":"directory"},{"name":"mpr121","path":"esphome/components/mpr121","contentType":"directory"},{"name":"mpu6050","path":"esphome/components/mpu6050","contentType":"directory"},{"name":"mpu6886","path":"esphome/components/mpu6886","contentType":"directory"},{"name":"mqtt","path":"esphome/components/mqtt","contentType":"directory"},{"name":"mqtt_subscribe","path":"esphome/components/mqtt_subscribe","contentType":"directory"},{"name":"ms5611","path":"esphome/components/ms5611","contentType":"directory"},{"name":"ms8607","path":"esphome/components/ms8607","contentType":"directory"},{"name":"my9231","path":"esphome/components/my9231","contentType":"directory"},{"name":"neopixelbus","path":"esphome/components/neopixelbus","contentType":"directory"},{"name":"network","path":"esphome/components/network","contentType":"directory"},{"name":"nextion","path":"esphome/components/nextion","contentType":"directory"},{"name":"nfc","path":"esphome/components/nfc","contentType":"directory"},{"name":"noblex","path":"esphome/components/noblex","contentType":"directory"},{"name":"ntc","path":"esphome/components/ntc","contentType":"directory"},{"name":"number","path":"esphome/components/number","contentType":"directory"},{"name":"one_wire","path":"esphome/components/one_wire","contentType":"directory"},{"name":"ota","path":"esphome/components/ota","contentType":"directory"},{"name":"output","path":"esphome/components/output","contentType":"directory"},{"name":"packages","path":"esphome/components/packages","contentType":"directory"},{"name":"partition","path":"esphome/components/partition","contentType":"directory"},{"name":"pca6416a","path":"esphome/components/pca6416a","contentType":"directory"},{"name":"pca9554","path":"esphome/components/pca9554","contentType":"directory"},{"name":"pca9685","path":"esphome/components/pca9685","contentType":"directory"},{"name":"pcd8544","path":"esphome/components/pcd8544","contentType":"directory"},{"name":"pcf85063","path":"esphome/components/pcf85063","contentType":"directory"},{"name":"pcf8563","path":"esphome/components/pcf8563","contentType":"directory"},{"name":"pcf8574","path":"esphome/components/pcf8574","contentType":"directory"},{"name":"pid","path":"esphome/components/pid","contentType":"directory"},{"name":"pipsolar","path":"esphome/components/pipsolar","contentType":"directory"},{"name":"pm1006","path":"esphome/components/pm1006","contentType":"directory"},{"name":"pmsa003i","path":"esphome/components/pmsa003i","contentType":"directory"},{"name":"pmsx003","path":"esphome/components/pmsx003","contentType":"directory"},{"name":"pmwcs3","path":"esphome/components/pmwcs3","contentType":"directory"},{"name":"pn532","path":"esphome/components/pn532","contentType":"directory"},{"name":"pn532_i2c","path":"esphome/components/pn532_i2c","contentType":"directory"},{"name":"pn532_spi","path":"esphome/components/pn532_spi","contentType":"directory"},{"name":"pn7150","path":"esphome/components/pn7150","contentType":"directory"},{"name":"pn7150_i2c","path":"esphome/components/pn7150_i2c","contentType":"directory"},{"name":"pn7160","path":"esphome/components/pn7160","contentType":"directory"},{"name":"pn7160_i2c","path":"esphome/components/pn7160_i2c","contentType":"directory"},{"name":"pn7160_spi","path":"esphome/components/pn7160_spi","contentType":"directory"},{"name":"power_supply","path":"esphome/components/power_supply","contentType":"directory"},{"name":"preferences","path":"esphome/components/preferences","contentType":"directory"},{"name":"prometheus","path":"esphome/components/prometheus","contentType":"directory"},{"name":"psram","path":"esphome/components/psram","contentType":"directory"},{"name":"pulse_counter","path":"esphome/components/pulse_counter","contentType":"directory"},{"name":"pulse_meter","path":"esphome/components/pulse_meter","contentType":"directory"},{"name":"pulse_width","path":"esphome/components/pulse_width","contentType":"directory"},{"name":"pvvx_mithermometer","path":"esphome/components/pvvx_mithermometer","contentType":"directory"},{"name":"pylontech","path":"esphome/components/pylontech","contentType":"directory"},{"name":"pzem004t","path":"esphome/components/pzem004t","contentType":"directory"},{"name":"pzemac","path":"esphome/components/pzemac","contentType":"directory"},{"name":"pzemdc","path":"esphome/components/pzemdc","contentType":"directory"},{"name":"qmc5883l","path":"esphome/components/qmc5883l","contentType":"directory"},{"name":"qmp6988","path":"esphome/components/qmp6988","contentType":"directory"},{"name":"qr_code","path":"esphome/components/qr_code","contentType":"directory"},{"name":"qspi_amoled","path":"esphome/components/qspi_amoled","contentType":"directory"},{"name":"qwiic_pir","path":"esphome/components/qwiic_pir","contentType":"directory"},{"name":"radon_eye_ble","path":"esphome/components/radon_eye_ble","contentType":"directory"},{"name":"radon_eye_rd200","path":"esphome/components/radon_eye_rd200","contentType":"directory"},{"name":"rc522","path":"esphome/components/rc522","contentType":"directory"},{"name":"rc522_i2c","path":"esphome/components/rc522_i2c","contentType":"directory"},{"name":"rc522_spi","path":"esphome/components/rc522_spi","contentType":"directory"},{"name":"rdm6300","path":"esphome/components/rdm6300","contentType":"directory"},{"name":"remote_base","path":"esphome/components/remote_base","contentType":"directory"},{"name":"remote_receiver","path":"esphome/components/remote_receiver","contentType":"directory"},{"name":"remote_transmitter","path":"esphome/components/remote_transmitter","contentType":"directory"},{"name":"resistance","path":"esphome/components/resistance","contentType":"directory"},{"name":"resistance_sampler","path":"esphome/components/resistance_sampler","contentType":"directory"},{"name":"restart","path":"esphome/components/restart","contentType":"directory"},{"name":"rf_bridge","path":"esphome/components/rf_bridge","contentType":"directory"},{"name":"rgb","path":"esphome/components/rgb","contentType":"directory"},{"name":"rgbct","path":"esphome/components/rgbct","contentType":"directory"},{"name":"rgbw","path":"esphome/components/rgbw","contentType":"directory"},{"name":"rgbww","path":"esphome/components/rgbww","contentType":"directory"},{"name":"rotary_encoder","path":"esphome/components/rotary_encoder","contentType":"directory"},{"name":"rp2040","path":"esphome/components/rp2040","contentType":"directory"},{"name":"rp2040_pio","path":"esphome/components/rp2040_pio","contentType":"directory"},{"name":"rp2040_pio_led_strip","path":"esphome/components/rp2040_pio_led_strip","contentType":"directory"},{"name":"rp2040_pwm","path":"esphome/components/rp2040_pwm","contentType":"directory"},{"name":"rpi_dpi_rgb","path":"esphome/components/rpi_dpi_rgb","contentType":"directory"},{"name":"rtl87xx","path":"esphome/components/rtl87xx","contentType":"directory"},{"name":"rtttl","path":"esphome/components/rtttl","contentType":"directory"},{"name":"ruuvi_ble","path":"esphome/components/ruuvi_ble","contentType":"directory"},{"name":"ruuvitag","path":"esphome/components/ruuvitag","contentType":"directory"},{"name":"safe_mode","path":"esphome/components/safe_mode","contentType":"directory"},{"name":"scd30","path":"esphome/components/scd30","contentType":"directory"},{"name":"scd4x","path":"esphome/components/scd4x","contentType":"directory"},{"name":"script","path":"esphome/components/script","contentType":"directory"},{"name":"sdl","path":"esphome/components/sdl","contentType":"directory"},{"name":"sdm_meter","path":"esphome/components/sdm_meter","contentType":"directory"},{"name":"sdp3x","path":"esphome/components/sdp3x","contentType":"directory"},{"name":"sds011","path":"esphome/components/sds011","contentType":"directory"},{"name":"seeed_mr24hpc1","path":"esphome/components/seeed_mr24hpc1","contentType":"directory"},{"name":"selec_meter","path":"esphome/components/selec_meter","contentType":"directory"},{"name":"select","path":"esphome/components/select","contentType":"directory"},{"name":"sen0321","path":"esphome/components/sen0321","contentType":"directory"},{"name":"sen21231","path":"esphome/components/sen21231","contentType":"directory"},{"name":"sen5x","path":"esphome/components/sen5x","contentType":"directory"},{"name":"senseair","path":"esphome/components/senseair","contentType":"directory"},{"name":"sensirion_common","path":"esphome/components/sensirion_common","contentType":"directory"},{"name":"sensor","path":"esphome/components/sensor","contentType":"directory"},{"name":"servo","path":"esphome/components/servo","contentType":"directory"},{"name":"sfa30","path":"esphome/components/sfa30","contentType":"directory"},{"name":"sgp30","path":"esphome/components/sgp30","contentType":"directory"},{"name":"sgp40","path":"esphome/components/sgp40","contentType":"directory"},{"name":"sgp4x","path":"esphome/components/sgp4x","contentType":"directory"},{"name":"shelly_dimmer","path":"esphome/components/shelly_dimmer","contentType":"directory"},{"name":"sht3xd","path":"esphome/components/sht3xd","contentType":"directory"},{"name":"sht4x","path":"esphome/components/sht4x","contentType":"directory"},{"name":"shtcx","path":"esphome/components/shtcx","contentType":"directory"},{"name":"shutdown","path":"esphome/components/shutdown","contentType":"directory"},{"name":"sigma_delta_output","path":"esphome/components/sigma_delta_output","contentType":"directory"},{"name":"sim800l","path":"esphome/components/sim800l","contentType":"directory"},{"name":"slow_pwm","path":"esphome/components/slow_pwm","contentType":"directory"},{"name":"sm10bit_base","path":"esphome/components/sm10bit_base","contentType":"directory"},{"name":"sm16716","path":"esphome/components/sm16716","contentType":"directory"},{"name":"sm2135","path":"esphome/components/sm2135","contentType":"directory"},{"name":"sm2235","path":"esphome/components/sm2235","contentType":"directory"},{"name":"sm2335","path":"esphome/components/sm2335","contentType":"directory"},{"name":"sm300d2","path":"esphome/components/sm300d2","contentType":"directory"},{"name":"sml","path":"esphome/components/sml","contentType":"directory"},{"name":"smt100","path":"esphome/components/smt100","contentType":"directory"},{"name":"sn74hc165","path":"esphome/components/sn74hc165","contentType":"directory"},{"name":"sn74hc595","path":"esphome/components/sn74hc595","contentType":"directory"},{"name":"sntp","path":"esphome/components/sntp","contentType":"directory"},{"name":"socket","path":"esphome/components/socket","contentType":"directory"},{"name":"sonoff_d1","path":"esphome/components/sonoff_d1","contentType":"directory"},{"name":"speaker","path":"esphome/components/speaker","contentType":"directory"},{"name":"speed","path":"esphome/components/speed","contentType":"directory"},{"name":"spi","path":"esphome/components/spi","contentType":"directory"},{"name":"spi_device","path":"esphome/components/spi_device","contentType":"directory"},{"name":"spi_led_strip","path":"esphome/components/spi_led_strip","contentType":"directory"},{"name":"sprinkler","path":"esphome/components/sprinkler","contentType":"directory"},{"name":"sps30","path":"esphome/components/sps30","contentType":"directory"},{"name":"ssd1306_base","path":"esphome/components/ssd1306_base","contentType":"directory"},{"name":"ssd1306_i2c","path":"esphome/components/ssd1306_i2c","contentType":"directory"},{"name":"ssd1306_spi","path":"esphome/components/ssd1306_spi","contentType":"directory"},{"name":"ssd1322_base","path":"esphome/components/ssd1322_base","contentType":"directory"},{"name":"ssd1322_spi","path":"esphome/components/ssd1322_spi","contentType":"directory"},{"name":"ssd1325_base","path":"esphome/components/ssd1325_base","contentType":"directory"},{"name":"ssd1325_spi","path":"esphome/components/ssd1325_spi","contentType":"directory"},{"name":"ssd1327_base","path":"esphome/components/ssd1327_base","contentType":"directory"},{"name":"ssd1327_i2c","path":"esphome/components/ssd1327_i2c","contentType":"directory"},{"name":"ssd1327_spi","path":"esphome/components/ssd1327_spi","contentType":"directory"},{"name":"ssd1331_base","path":"esphome/components/ssd1331_base","contentType":"directory"},{"name":"ssd1331_spi","path":"esphome/components/ssd1331_spi","contentType":"directory"},{"name":"ssd1351_base","path":"esphome/components/ssd1351_base","contentType":"directory"},{"name":"ssd1351_spi","path":"esphome/components/ssd1351_spi","contentType":"directory"},{"name":"st7567_base","path":"esphome/components/st7567_base","contentType":"directory"},{"name":"st7567_i2c","path":"esphome/components/st7567_i2c","contentType":"directory"},{"name":"st7567_spi","path":"esphome/components/st7567_spi","contentType":"directory"},{"name":"st7701s","path":"esphome/components/st7701s","contentType":"directory"},{"name":"st7735","path":"esphome/components/st7735","contentType":"directory"},{"name":"st7789v","path":"esphome/components/st7789v","contentType":"directory"},{"name":"st7920","path":"esphome/components/st7920","contentType":"directory"},{"name":"status","path":"esphome/components/status","contentType":"directory"},{"name":"status_led","path":"esphome/components/status_led","contentType":"directory"},{"name":"stepper","path":"esphome/components/stepper","contentType":"directory"},{"name":"sts3x","path":"esphome/components/sts3x","contentType":"directory"},{"name":"substitutions","path":"esphome/components/substitutions","contentType":"directory"},{"name":"sun","path":"esphome/components/sun","contentType":"directory"},{"name":"sun_gtil2","path":"esphome/components/sun_gtil2","contentType":"directory"},{"name":"switch","path":"esphome/components/switch","contentType":"directory"},{"name":"sx1509","path":"esphome/components/sx1509","contentType":"directory"},{"name":"t6615","path":"esphome/components/t6615","contentType":"directory"},{"name":"tca9548a","path":"esphome/components/tca9548a","contentType":"directory"},{"name":"tcl112","path":"esphome/components/tcl112","contentType":"directory"},{"name":"tcs34725","path":"esphome/components/tcs34725","contentType":"directory"},{"name":"tee501","path":"esphome/components/tee501","contentType":"directory"},{"name":"teleinfo","path":"esphome/components/teleinfo","contentType":"directory"},{"name":"template","path":"esphome/components/template","contentType":"directory"},{"name":"text","path":"esphome/components/text","contentType":"directory"},{"name":"text_sensor","path":"esphome/components/text_sensor","contentType":"directory"},{"name":"thermostat","path":"esphome/components/thermostat","contentType":"directory"},{"name":"time","path":"esphome/components/time","contentType":"directory"},{"name":"time_based","path":"esphome/components/time_based","contentType":"directory"},{"name":"tlc59208f","path":"esphome/components/tlc59208f","contentType":"directory"},{"name":"tlc5947","path":"esphome/components/tlc5947","contentType":"directory"},{"name":"tlc5971","path":"esphome/components/tlc5971","contentType":"directory"},{"name":"tm1621","path":"esphome/components/tm1621","contentType":"directory"},{"name":"tm1637","path":"esphome/components/tm1637","contentType":"directory"},{"name":"tm1638","path":"esphome/components/tm1638","contentType":"directory"},{"name":"tm1651","path":"esphome/components/tm1651","contentType":"directory"},{"name":"tmp102","path":"esphome/components/tmp102","contentType":"directory"},{"name":"tmp1075","path":"esphome/components/tmp1075","contentType":"directory"},{"name":"tmp117","path":"esphome/components/tmp117","contentType":"directory"},{"name":"tof10120","path":"esphome/components/tof10120","contentType":"directory"},{"name":"toshiba","path":"esphome/components/toshiba","contentType":"directory"},{"name":"total_daily_energy","path":"esphome/components/total_daily_energy","contentType":"directory"},{"name":"touchscreen","path":"esphome/components/touchscreen","contentType":"directory"},{"name":"tsl2561","path":"esphome/components/tsl2561","contentType":"directory"},{"name":"tsl2591","path":"esphome/components/tsl2591","contentType":"directory"},{"name":"tt21100","path":"esphome/components/tt21100","contentType":"directory"},{"name":"ttp229_bsf","path":"esphome/components/ttp229_bsf","contentType":"directory"},{"name":"ttp229_lsf","path":"esphome/components/ttp229_lsf","contentType":"directory"},{"name":"tuya","path":"esphome/components/tuya","contentType":"directory"},{"name":"tx20","path":"esphome/components/tx20","contentType":"directory"},{"name":"uart","path":"esphome/components/uart","contentType":"directory"},{"name":"ufire_ec","path":"esphome/components/ufire_ec","contentType":"directory"},{"name":"ufire_ise","path":"esphome/components/ufire_ise","contentType":"directory"},{"name":"uln2003","path":"esphome/components/uln2003","contentType":"directory"},{"name":"ultrasonic","path":"esphome/components/ultrasonic","contentType":"directory"},{"name":"update","path":"esphome/components/update","contentType":"directory"},{"name":"uponor_smatrix","path":"esphome/components/uponor_smatrix","contentType":"directory"},{"name":"uptime","path":"esphome/components/uptime","contentType":"directory"},{"name":"valve","path":"esphome/components/valve","contentType":"directory"},{"name":"vbus","path":"esphome/components/vbus","contentType":"directory"},{"name":"veml3235","path":"esphome/components/veml3235","contentType":"directory"},{"name":"veml7700","path":"esphome/components/veml7700","contentType":"directory"},{"name":"version","path":"esphome/components/version","contentType":"directory"},{"name":"vl53l0x","path":"esphome/components/vl53l0x","contentType":"directory"},{"name":"voice_assistant","path":"esphome/components/voice_assistant","contentType":"directory"},{"name":"voltage_sampler","path":"esphome/components/voltage_sampler","contentType":"directory"},{"name":"wake_on_lan","path":"esphome/components/wake_on_lan","contentType":"directory"},{"name":"waveshare_epaper","path":"esphome/components/waveshare_epaper","contentType":"directory"},{"name":"web_server","path":"esphome/components/web_server","contentType":"directory"},{"name":"web_server_base","path":"esphome/components/web_server_base","contentType":"directory"},{"name":"web_server_idf","path":"esphome/components/web_server_idf","contentType":"directory"},{"name":"weikai","path":"esphome/components/weikai","contentType":"directory"},{"name":"weikai_i2c","path":"esphome/components/weikai_i2c","contentType":"directory"},{"name":"weikai_spi","path":"esphome/components/weikai_spi","contentType":"directory"},{"name":"whirlpool","path":"esphome/components/whirlpool","contentType":"directory"},{"name":"whynter","path":"esphome/components/whynter","contentType":"directory"},{"name":"wiegand","path":"esphome/components/wiegand","contentType":"directory"},{"name":"wifi","path":"esphome/components/wifi","contentType":"directory"},{"name":"wifi_info","path":"esphome/components/wifi_info","contentType":"directory"},{"name":"wifi_signal","path":"esphome/components/wifi_signal","contentType":"directory"},{"name":"wireguard","path":"esphome/components/wireguard","contentType":"directory"},{"name":"wk2132_i2c","path":"esphome/components/wk2132_i2c","contentType":"directory"},{"name":"wk2132_spi","path":"esphome/components/wk2132_spi","contentType":"directory"},{"name":"wk2168_i2c","path":"esphome/components/wk2168_i2c","contentType":"directory"},{"name":"wk2168_spi","path":"esphome/components/wk2168_spi","contentType":"directory"},{"name":"wk2204_i2c","path":"esphome/components/wk2204_i2c","contentType":"directory"},{"name":"wk2204_spi","path":"esphome/components/wk2204_spi","contentType":"directory"},{"name":"wk2212_i2c","path":"esphome/components/wk2212_i2c","contentType":"directory"},{"name":"wk2212_spi","path":"esphome/components/wk2212_spi","contentType":"directory"},{"name":"wl_134","path":"esphome/components/wl_134","contentType":"directory"},{"name":"wled","path":"esphome/components/wled","contentType":"directory"},{"name":"x9c","path":"esphome/components/x9c","contentType":"directory"},{"name":"xgzp68xx","path":"esphome/components/xgzp68xx","contentType":"directory"},{"name":"xiaomi_ble","path":"esphome/components/xiaomi_ble","contentType":"directory"},{"name":"xiaomi_cgd1","path":"esphome/components/xiaomi_cgd1","contentType":"directory"},{"name":"xiaomi_cgdk2","path":"esphome/components/xiaomi_cgdk2","contentType":"directory"},{"name":"xiaomi_cgg1","path":"esphome/components/xiaomi_cgg1","contentType":"directory"},{"name":"xiaomi_cgpr1","path":"esphome/components/xiaomi_cgpr1","contentType":"directory"},{"name":"xiaomi_gcls002","path":"esphome/components/xiaomi_gcls002","contentType":"directory"},{"name":"xiaomi_hhccjcy01","path":"esphome/components/xiaomi_hhccjcy01","contentType":"directory"},{"name":"xiaomi_hhccjcy10","path":"esphome/components/xiaomi_hhccjcy10","contentType":"directory"},{"name":"xiaomi_hhccpot002","path":"esphome/components/xiaomi_hhccpot002","contentType":"directory"},{"name":"xiaomi_jqjcy01ym","path":"esphome/components/xiaomi_jqjcy01ym","contentType":"directory"},{"name":"xiaomi_lywsd02","path":"esphome/components/xiaomi_lywsd02","contentType":"directory"},{"name":"xiaomi_lywsd03mmc","path":"esphome/components/xiaomi_lywsd03mmc","contentType":"directory"},{"name":"xiaomi_lywsdcgq","path":"esphome/components/xiaomi_lywsdcgq","contentType":"directory"},{"name":"xiaomi_mhoc303","path":"esphome/components/xiaomi_mhoc303","contentType":"directory"},{"name":"xiaomi_mhoc401","path":"esphome/components/xiaomi_mhoc401","contentType":"directory"},{"name":"xiaomi_miscale","path":"esphome/components/xiaomi_miscale","contentType":"directory"},{"name":"xiaomi_miscale2","path":"esphome/components/xiaomi_miscale2","contentType":"directory"},{"name":"xiaomi_mjyd02yla","path":"esphome/components/xiaomi_mjyd02yla","contentType":"directory"},{"name":"xiaomi_mue4094rt","path":"esphome/components/xiaomi_mue4094rt","contentType":"directory"},{"name":"xiaomi_rtcgq02lm","path":"esphome/components/xiaomi_rtcgq02lm","contentType":"directory"},{"name":"xiaomi_wx08zm","path":"esphome/components/xiaomi_wx08zm","contentType":"directory"},{"name":"xl9535","path":"esphome/components/xl9535","contentType":"directory"},{"name":"xpt2046","path":"esphome/components/xpt2046","contentType":"directory"},{"name":"yashima","path":"esphome/components/yashima","contentType":"directory"},{"name":"zhlt01","path":"esphome/components/zhlt01","contentType":"directory"},{"name":"zio_ultrasonic","path":"esphome/components/zio_ultrasonic","contentType":"directory"},{"name":"zyaura","path":"esphome/components/zyaura","contentType":"directory"},{"name":"__init__.py","path":"esphome/components/__init__.py","contentType":"file"}],"totalCount":570},"esphome":{"items":[{"name":"components","path":"esphome/components","contentType":"directory"}]},"":{"items":[{"name":"esphome","path":"esphome","contentType":"directory"}]}},"fileTreeProcessingTime":239.642829,"foldersToFetch":["esphome",""],"repo":{"id":128479644,"defaultBranch":"dev","name":"esphome","ownerLogin":"esphome","currentUserCanPush":false,"isFork":false,"isEmpty":false,"createdAt":"2018-04-07T01:23:25.000+02:00","ownerAvatar":"https://avatars.githubusercontent.com/u/45919759?v=4","public":true,"private":false,"isOrgOwned":true},"codeLineWrapEnabled":false,"symbolsExpanded":true,"treeExpanded":true,"refInfo":{"name":"dev","listCacheKey":"v0:1718263477.0","canEdit":true,"refType":"branch","currentOid":"d49f2cbec80355694f046088ac0c35ef6483f77a"},"path":"esphome/components/dallas_temp/dallas_temp.cpp","currentUser":{"id":52893640,"login":"tiimsvk","userEmail":"tiimsvk@gmail.com"},"blob":{"rawLines":["#include \"dallas_temp.h\"","#include \"esphome/core/log.h\"","","namespace esphome {","namespace dallas_temp {","","static const char *const TAG = \"dallas.temp.sensor\";","","static const uint8_t DALLAS_MODEL_DS18S20 = 0x10;","static const uint8_t DALLAS_COMMAND_START_CONVERSION = 0x44;","static const uint8_t DALLAS_COMMAND_READ_SCRATCH_PAD = 0xBE;","static const uint8_t DALLAS_COMMAND_WRITE_SCRATCH_PAD = 0x4E;","static const uint8_t DALLAS_COMMAND_COPY_SCRATCH_PAD = 0x48;","","uint16_t DallasTemperatureSensor::millis_to_wait_for_conversion_() const {","  switch (this-\u003eresolution_) {","    case 9:","      return 94;","    case 10:","      return 188;","    case 11:","      return 375;","    default:","      return 750;","  }","}","","void DallasTemperatureSensor::dump_config() {","  ESP_LOGCONFIG(TAG, \"Dallas Temperature Sensor:\");","  if (this-\u003eaddress_ == 0) {","    ESP_LOGW(TAG, \"  Unable to select an address\");","    return;","  }","  LOG_ONE_WIRE_DEVICE(this);","  ESP_LOGCONFIG(TAG, \"  Resolution: %u bits\", this-\u003eresolution_);","  LOG_UPDATE_INTERVAL(this);","}","","void DallasTemperatureSensor::update() {","  if (this-\u003eaddress_ == 0)","    return;","","  this-\u003estatus_clear_warning();","","  this-\u003esend_command_(DALLAS_COMMAND_START_CONVERSION);","","  this-\u003eset_timeout(this-\u003eget_address_name(), this-\u003emillis_to_wait_for_conversion_(), [this] {","    if (!this-\u003eread_scratch_pad_() || !this-\u003echeck_scratch_pad_()) {","      this-\u003epublish_state(NAN);","      return;","    }","","    float tempc = this-\u003eget_temp_c_();","    ESP_LOGD(TAG, \"'%s': Got Temperature=%.1f°C\", this-\u003eget_name().c_str(), tempc);","    this-\u003epublish_state(tempc);","  });","}","","void IRAM_ATTR DallasTemperatureSensor::read_scratch_pad_int_() {","  for (uint8_t \u0026i : this-\u003escratch_pad_) {","    i = this-\u003ebus_-\u003eread8();","  }","}","","bool DallasTemperatureSensor::read_scratch_pad_() {","  bool success;","  {","    InterruptLock lock;","    success = this-\u003esend_command_(DALLAS_COMMAND_READ_SCRATCH_PAD);","    if (success)","      this-\u003eread_scratch_pad_int_();","  }","  if (!success) {","    ESP_LOGW(TAG, \"'%s' - reading scratch pad failed bus reset\", this-\u003eget_name().c_str());","    this-\u003estatus_set_warning(\"bus reset failed\");","  }","  return success;","}","","void DallasTemperatureSensor::setup() {","  ESP_LOGCONFIG(TAG, \"setting up Dallas temperature sensor...\");","  if (!this-\u003echeck_address_())","    return;","  if (!this-\u003eread_scratch_pad_())","    return;","  if (!this-\u003echeck_scratch_pad_())","    return;","","  if ((this-\u003eaddress_ \u0026 0xff) == DALLAS_MODEL_DS18S20) {","    // DS18S20 doesn't support resolution.","    ESP_LOGW(TAG, \"DS18S20 doesn't support setting resolution.\");","    return;","  }","","  uint8_t res;","  switch (this-\u003eresolution_) {","    case 12:","      res = 0x7F;","      break;","    case 11:","      res = 0x5F;","      break;","    case 10:","      res = 0x3F;","      break;","    case 9:","    default:","      res = 0x1F;","      break;","  }","","  if (this-\u003escratch_pad_[4] == res)","    return;","  this-\u003escratch_pad_[4] = res;","","  {","    InterruptLock lock;","    if (this-\u003esend_command_(DALLAS_COMMAND_WRITE_SCRATCH_PAD)) {","      this-\u003ebus_-\u003ewrite8(this-\u003escratch_pad_[2]);  // high alarm temp","      this-\u003ebus_-\u003ewrite8(this-\u003escratch_pad_[3]);  // low alarm temp","      this-\u003ebus_-\u003ewrite8(this-\u003escratch_pad_[4]);  // resolution","    }","","    // write value to EEPROM","    this-\u003esend_command_(DALLAS_COMMAND_COPY_SCRATCH_PAD);","  }","}","","bool DallasTemperatureSensor::check_scratch_pad_() {","  bool chksum_validity = (crc8(this-\u003escratch_pad_, 8) == this-\u003escratch_pad_[8]);","","#ifdef ESPHOME_LOG_LEVEL_VERY_VERBOSE","  ESP_LOGVV(TAG, \"Scratch pad: %02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X (%02X)\", this-\u003escratch_pad_[0],","            this-\u003escratch_pad_[1], this-\u003escratch_pad_[2], this-\u003escratch_pad_[3], this-\u003escratch_pad_[4],","            this-\u003escratch_pad_[5], this-\u003escratch_pad_[6], this-\u003escratch_pad_[7], this-\u003escratch_pad_[8],","            crc8(this-\u003escratch_pad_, 8));","#endif","  if (!chksum_validity) {","    ESP_LOGW(TAG, \"'%s' - Scratch pad checksum invalid!\", this-\u003eget_name().c_str());","    this-\u003estatus_set_warning(\"scratch pad checksum invalid\");","  }","  return chksum_validity;","}","","float DallasTemperatureSensor::get_temp_c_() {","  int16_t temp = (this-\u003escratch_pad_[1] \u003c\u003c 8) | this-\u003escratch_pad_[0];","  if ((this-\u003eaddress_ \u0026 0xff) == DALLAS_MODEL_DS18S20) {","    if (this-\u003escratch_pad_[7] != 0x10)","      ESP_LOGE(TAG, \"unexpected COUNT_PER_C value: %u\", this-\u003escratch_pad_[7]);","    temp = ((temp \u0026 0xfff7) \u003c\u003c 3) + (0x10 - this-\u003escratch_pad_[6]) - 4;","  } else {","    switch (this-\u003eresolution_) {","      case 9:","        temp \u0026= 0xfff8;","        break;","      case 10:","        temp \u0026= 0xfffc;","        break;","      case 11:","        temp \u0026= 0xfffe;","        break;","      case 12:","      default:","        break;","    }","  }","","  return temp / 16.0f;","}","","}  // namespace dallas_temp","}  // namespace esphome"],"stylingDirectives":null,"colorizedLines":["#\u003cspan class=\"pl-k\"\u003einclude\u003c/span\u003e \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003edallas_temp.h\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e","#\u003cspan class=\"pl-k\"\u003einclude\u003c/span\u003e \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003eesphome/core/log.h\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e","","\u003cspan class=\"pl-k\"\u003enamespace\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eesphome\u003c/span\u003e {","\u003cspan class=\"pl-k\"\u003enamespace\u003c/span\u003e \u003cspan class=\"pl-en\"\u003edallas_temp\u003c/span\u003e {","","\u003cspan class=\"pl-k\"\u003estatic\u003c/span\u003e \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e \u003cspan class=\"pl-k\"\u003echar\u003c/span\u003e *\u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e TAG = \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003edallas.temp.sensor\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e;","","\u003cspan class=\"pl-k\"\u003estatic\u003c/span\u003e \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e DALLAS_MODEL_DS18S20 = \u003cspan class=\"pl-c1\"\u003e0x10\u003c/span\u003e;","\u003cspan class=\"pl-k\"\u003estatic\u003c/span\u003e \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e DALLAS_COMMAND_START_CONVERSION = \u003cspan class=\"pl-c1\"\u003e0x44\u003c/span\u003e;","\u003cspan class=\"pl-k\"\u003estatic\u003c/span\u003e \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e DALLAS_COMMAND_READ_SCRATCH_PAD = \u003cspan class=\"pl-c1\"\u003e0xBE\u003c/span\u003e;","\u003cspan class=\"pl-k\"\u003estatic\u003c/span\u003e \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e DALLAS_COMMAND_WRITE_SCRATCH_PAD = \u003cspan class=\"pl-c1\"\u003e0x4E\u003c/span\u003e;","\u003cspan class=\"pl-k\"\u003estatic\u003c/span\u003e \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e DALLAS_COMMAND_COPY_SCRATCH_PAD = \u003cspan class=\"pl-c1\"\u003e0x48\u003c/span\u003e;","","\u003cspan class=\"pl-c1\"\u003euint16_t\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::millis_to_wait_for_conversion_\u003c/span\u003e() \u003cspan class=\"pl-k\"\u003econst\u003c/span\u003e {","  \u003cspan class=\"pl-k\"\u003eswitch\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eresolution_\u003c/span\u003e) {","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e9\u003c/span\u003e:","      \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e94\u003c/span\u003e;","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e10\u003c/span\u003e:","      \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e188\u003c/span\u003e;","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e11\u003c/span\u003e:","      \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e375\u003c/span\u003e;","    \u003cspan class=\"pl-k\"\u003edefault\u003c/span\u003e:","      \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e750\u003c/span\u003e;","  }","}","","\u003cspan class=\"pl-k\"\u003evoid\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::dump_config\u003c/span\u003e() {","  \u003cspan class=\"pl-c1\"\u003eESP_LOGCONFIG\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003eDallas Temperature Sensor:\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e);","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eaddress_\u003c/span\u003e == \u003cspan class=\"pl-c1\"\u003e0\u003c/span\u003e) {","    \u003cspan class=\"pl-c1\"\u003eESP_LOGW\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e  Unable to select an address\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e);","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","  }","  \u003cspan class=\"pl-c1\"\u003eLOG_ONE_WIRE_DEVICE\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e);","  \u003cspan class=\"pl-c1\"\u003eESP_LOGCONFIG\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e  Resolution: %u bits\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eresolution_\u003c/span\u003e);","  \u003cspan class=\"pl-c1\"\u003eLOG_UPDATE_INTERVAL\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e);","}","","\u003cspan class=\"pl-k\"\u003evoid\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::update\u003c/span\u003e() {","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eaddress_\u003c/span\u003e == \u003cspan class=\"pl-c1\"\u003e0\u003c/span\u003e)","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","","  \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003estatus_clear_warning\u003c/span\u003e();","","  \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003esend_command_\u003c/span\u003e(DALLAS_COMMAND_START_CONVERSION);","","  \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eset_timeout\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eget_address_name\u003c/span\u003e(), \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003emillis_to_wait_for_conversion_\u003c/span\u003e(), [\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e] {","    \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (!\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eread_scratch_pad_\u003c/span\u003e() || !\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003echeck_scratch_pad_\u003c/span\u003e()) {","      \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003epublish_state\u003c/span\u003e(NAN);","      \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","    }","","    \u003cspan class=\"pl-k\"\u003efloat\u003c/span\u003e tempc = \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eget_temp_c_\u003c/span\u003e();","    \u003cspan class=\"pl-c1\"\u003eESP_LOGD\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u0026#39;%s\u0026#39;: Got Temperature=%.1f°C\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eget_name\u003c/span\u003e().\u003cspan class=\"pl-c1\"\u003ec_str\u003c/span\u003e(), tempc);","    \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003epublish_state\u003c/span\u003e(tempc);","  });","}","","\u003cspan class=\"pl-k\"\u003evoid\u003c/span\u003e IRAM_ATTR \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::read_scratch_pad_int_\u003c/span\u003e() {","  \u003cspan class=\"pl-k\"\u003efor\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e \u0026amp;i : \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e) {","    i = \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003ebus_\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eread8\u003c/span\u003e();","  }","}","","\u003cspan class=\"pl-k\"\u003ebool\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::read_scratch_pad_\u003c/span\u003e() {","  \u003cspan class=\"pl-k\"\u003ebool\u003c/span\u003e success;","  {","    InterruptLock lock;","    success = \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003esend_command_\u003c/span\u003e(DALLAS_COMMAND_READ_SCRATCH_PAD);","    \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (success)","      \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eread_scratch_pad_int_\u003c/span\u003e();","  }","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (!success) {","    \u003cspan class=\"pl-c1\"\u003eESP_LOGW\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u0026#39;%s\u0026#39; - reading scratch pad failed bus reset\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eget_name\u003c/span\u003e().\u003cspan class=\"pl-c1\"\u003ec_str\u003c/span\u003e());","    \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003estatus_set_warning\u003c/span\u003e(\u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003ebus reset failed\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e);","  }","  \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e success;","}","","\u003cspan class=\"pl-k\"\u003evoid\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::setup\u003c/span\u003e() {","  \u003cspan class=\"pl-c1\"\u003eESP_LOGCONFIG\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003esetting up Dallas temperature sensor...\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e);","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (!\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003echeck_address_\u003c/span\u003e())","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (!\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eread_scratch_pad_\u003c/span\u003e())","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (!\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003echeck_scratch_pad_\u003c/span\u003e())","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e ((\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eaddress_\u003c/span\u003e \u0026amp; \u003cspan class=\"pl-c1\"\u003e0xff\u003c/span\u003e) == DALLAS_MODEL_DS18S20) {","    \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e DS18S20 doesn\u0026#39;t support resolution.\u003c/span\u003e","    \u003cspan class=\"pl-c1\"\u003eESP_LOGW\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003eDS18S20 doesn\u0026#39;t support setting resolution.\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e);","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","  }","","  \u003cspan class=\"pl-c1\"\u003euint8_t\u003c/span\u003e res;","  \u003cspan class=\"pl-k\"\u003eswitch\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eresolution_\u003c/span\u003e) {","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e12\u003c/span\u003e:","      res = \u003cspan class=\"pl-c1\"\u003e0x7F\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e11\u003c/span\u003e:","      res = \u003cspan class=\"pl-c1\"\u003e0x5F\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e10\u003c/span\u003e:","      res = \u003cspan class=\"pl-c1\"\u003e0x3F\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","    \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e9\u003c/span\u003e:","    \u003cspan class=\"pl-k\"\u003edefault\u003c/span\u003e:","      res = \u003cspan class=\"pl-c1\"\u003e0x1F\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","  }","","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e4\u003c/span\u003e] == res)","    \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e;","  \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e4\u003c/span\u003e] = res;","","  {","    InterruptLock lock;","    \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003esend_command_\u003c/span\u003e(DALLAS_COMMAND_WRITE_SCRATCH_PAD)) {","      \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003ebus_\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003ewrite8\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e2\u003c/span\u003e]);  \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e high alarm temp\u003c/span\u003e","      \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003ebus_\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003ewrite8\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e3\u003c/span\u003e]);  \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e low alarm temp\u003c/span\u003e","      \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003ebus_\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003ewrite8\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e4\u003c/span\u003e]);  \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e resolution\u003c/span\u003e","    }","","    \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e write value to EEPROM\u003c/span\u003e","    \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003esend_command_\u003c/span\u003e(DALLAS_COMMAND_COPY_SCRATCH_PAD);","  }","}","","\u003cspan class=\"pl-k\"\u003ebool\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::check_scratch_pad_\u003c/span\u003e() {","  \u003cspan class=\"pl-k\"\u003ebool\u003c/span\u003e chksum_validity = (\u003cspan class=\"pl-c1\"\u003ecrc8\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003e8\u003c/span\u003e) == \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e8\u003c/span\u003e]);","","#\u003cspan class=\"pl-k\"\u003eifdef\u003c/span\u003e ESPHOME_LOG_LEVEL_VERY_VERBOSE","  \u003cspan class=\"pl-c1\"\u003eESP_LOGVV\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003eScratch pad: %02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X (%02X)\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e0\u003c/span\u003e],","            \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e1\u003c/span\u003e], \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e2\u003c/span\u003e], \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e3\u003c/span\u003e], \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e4\u003c/span\u003e],","            \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e5\u003c/span\u003e], \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e6\u003c/span\u003e], \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e7\u003c/span\u003e], \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e8\u003c/span\u003e],","            \u003cspan class=\"pl-c1\"\u003ecrc8\u003c/span\u003e(\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003e8\u003c/span\u003e));","#\u003cspan class=\"pl-k\"\u003eendif\u003c/span\u003e","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (!chksum_validity) {","    \u003cspan class=\"pl-c1\"\u003eESP_LOGW\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u0026#39;%s\u0026#39; - Scratch pad checksum invalid!\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003eget_name\u003c/span\u003e().\u003cspan class=\"pl-c1\"\u003ec_str\u003c/span\u003e());","    \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-c1\"\u003estatus_set_warning\u003c/span\u003e(\u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003escratch pad checksum invalid\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e);","  }","  \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e chksum_validity;","}","","\u003cspan class=\"pl-k\"\u003efloat\u003c/span\u003e \u003cspan class=\"pl-en\"\u003eDallasTemperatureSensor::get_temp_c_\u003c/span\u003e() {","  \u003cspan class=\"pl-c1\"\u003eint16_t\u003c/span\u003e temp = (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e1\u003c/span\u003e] \u0026lt;\u0026lt; \u003cspan class=\"pl-c1\"\u003e8\u003c/span\u003e) | \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e0\u003c/span\u003e];","  \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e ((\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eaddress_\u003c/span\u003e \u0026amp; \u003cspan class=\"pl-c1\"\u003e0xff\u003c/span\u003e) == DALLAS_MODEL_DS18S20) {","    \u003cspan class=\"pl-k\"\u003eif\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e7\u003c/span\u003e] != \u003cspan class=\"pl-c1\"\u003e0x10\u003c/span\u003e)","      \u003cspan class=\"pl-c1\"\u003eESP_LOGE\u003c/span\u003e(TAG, \u003cspan class=\"pl-s\"\u003e\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003eunexpected COUNT_PER_C value: %u\u003cspan class=\"pl-pds\"\u003e\u0026quot;\u003c/span\u003e\u003c/span\u003e, \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e7\u003c/span\u003e]);","    temp = ((temp \u0026amp; \u003cspan class=\"pl-c1\"\u003e0xfff7\u003c/span\u003e) \u0026lt;\u0026lt; \u003cspan class=\"pl-c1\"\u003e3\u003c/span\u003e) + (\u003cspan class=\"pl-c1\"\u003e0x10\u003c/span\u003e - \u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003escratch_pad_\u003c/span\u003e[\u003cspan class=\"pl-c1\"\u003e6\u003c/span\u003e]) - \u003cspan class=\"pl-c1\"\u003e4\u003c/span\u003e;","  } \u003cspan class=\"pl-k\"\u003eelse\u003c/span\u003e {","    \u003cspan class=\"pl-k\"\u003eswitch\u003c/span\u003e (\u003cspan class=\"pl-c1\"\u003ethis\u003c/span\u003e-\u0026gt;\u003cspan class=\"pl-smi\"\u003eresolution_\u003c/span\u003e) {","      \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e9\u003c/span\u003e:","        temp \u0026amp;= \u003cspan class=\"pl-c1\"\u003e0xfff8\u003c/span\u003e;","        \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e10\u003c/span\u003e:","        temp \u0026amp;= \u003cspan class=\"pl-c1\"\u003e0xfffc\u003c/span\u003e;","        \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e11\u003c/span\u003e:","        temp \u0026amp;= \u003cspan class=\"pl-c1\"\u003e0xfffe\u003c/span\u003e;","        \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","      \u003cspan class=\"pl-k\"\u003ecase\u003c/span\u003e \u003cspan class=\"pl-c1\"\u003e12\u003c/span\u003e:","      \u003cspan class=\"pl-k\"\u003edefault\u003c/span\u003e:","        \u003cspan class=\"pl-k\"\u003ebreak\u003c/span\u003e;","    }","  }","","  \u003cspan class=\"pl-k\"\u003ereturn\u003c/span\u003e temp / \u003cspan class=\"pl-c1\"\u003e16\u003c/span\u003e.\u003cspan class=\"pl-c1\"\u003e0f\u003c/span\u003e;","}","","}  \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e namespace dallas_temp\u003c/span\u003e","}  \u003cspan class=\"pl-c\"\u003e\u003cspan class=\"pl-c\"\u003e//\u003c/span\u003e namespace esphome\u003c/span\u003e"],"csv":null,"csvError":null,"dependabotInfo":{"showConfigurationBanner":false,"configFilePath":null,"networkDependabotPath":"/esphome/esphome/network/updates","dismissConfigurationNoticePath":"/settings/dismiss-notice/dependabot_configuration_notice","configurationNoticeDismissed":false},"displayName":"dallas_temp.cpp","displayUrl":"https://github.com/esphome/esphome/blob/dev/esphome/components/dallas_temp/dallas_temp.cpp?raw=true","headerInfo":{"blobSize":"4.59 KB","deleteTooltip":"Fork this repository and delete the file","editTooltip":"Fork this repository and edit the file","ghDesktopPath":"https://desktop.github.com","isGitLfs":false,"onBranch":true,"shortPath":"fe7c9a9","siteNavLoginPath":"/login?return_to=https%3A%2F%2Fgithub.com%2Fesphome%2Fesphome%2Fblob%2Fdev%2Fesphome%2Fcomponents%2Fdallas_temp%2Fdallas_temp.cpp","isCSV":false,"isRichtext":false,"toc":null,"lineInfo":{"truncatedLoc":"172","truncatedSloc":"149"},"mode":"file"},"image":false,"isCodeownersFile":null,"isPlain":false,"isValidLegacyIssueTemplate":false,"issueTemplate":null,"discussionTemplate":null,"language":"C++","languageID":43,"large":false,"planSupportInfo":{"repoIsFork":null,"repoOwnedByCurrentUser":null,"requestFullPath":"/esphome/esphome/blob/dev/esphome/components/dallas_temp/dallas_temp.cpp","showFreeOrgGatedFeatureMessage":null,"showPlanSupportBanner":null,"upgradeDataAttributes":null,"upgradePath":null},"publishBannersInfo":{"dismissActionNoticePath":"/settings/dismiss-notice/publish_action_from_dockerfile","releasePath":"/esphome/esphome/releases/new?marketplace=true","showPublishActionBanner":false},"rawBlobUrl":"https://github.com/esphome/esphome/raw/dev/esphome/components/dallas_temp/dallas_temp.cpp","renderImageOrRaw":false,"richText":null,"renderedFileInfo":null,"shortPath":null,"symbolsEnabled":true,"tabSize":2,"topBannersInfo":{"overridingGlobalFundingFile":false,"globalPreferredFundingPath":null,"showInvalidCitationWarning":false,"citationHelpUrl":"https://docs.github.com/github/creating-cloning-and-archiving-repositories/creating-a-repository-on-github/about-citation-files","actionsOnboardingTip":null},"truncated":false,"viewable":true,"workflowRedirectUrl":null,"symbols":{"timed_out":true,"not_analyzed":false,"symbols":[{"name":"millis_to_wait_for_conversion_","kind":"method","ident_start":485,"ident_end":515,"extent_start":451,"extent_end":684,"fully_qualified_name":"DallasTemperatureSensor::millis_to_wait_for_conversion_","ident_utf16":{"start":{"line_number":14,"utf16_col":34},"end":{"line_number":14,"utf16_col":64}},"extent_utf16":{"start":{"line_number":14,"utf16_col":0},"end":{"line_number":25,"utf16_col":1}}},{"name":"dump_config","kind":"method","ident_start":716,"ident_end":727,"extent_start":686,"extent_end":1006,"fully_qualified_name":"DallasTemperatureSensor::dump_config","ident_utf16":{"start":{"line_number":27,"utf16_col":30},"end":{"line_number":27,"utf16_col":41}},"extent_utf16":{"start":{"line_number":27,"utf16_col":0},"end":{"line_number":36,"utf16_col":1}}},{"name":"update","kind":"method","ident_start":1038,"ident_end":1044,"extent_start":1008,"extent_end":1559,"fully_qualified_name":"DallasTemperatureSensor::update","ident_utf16":{"start":{"line_number":38,"utf16_col":30},"end":{"line_number":38,"utf16_col":36}},"extent_utf16":{"start":{"line_number":38,"utf16_col":0},"end":{"line_number":56,"utf16_col":1}}},{"name":"read_scratch_pad_int_","kind":"method","ident_start":1601,"ident_end":1622,"extent_start":1561,"extent_end":1703,"fully_qualified_name":"DallasTemperatureSensor::read_scratch_pad_int_","ident_utf16":{"start":{"line_number":58,"utf16_col":40},"end":{"line_number":58,"utf16_col":61}},"extent_utf16":{"start":{"line_number":58,"utf16_col":0},"end":{"line_number":62,"utf16_col":1}}},{"name":"read_scratch_pad_","kind":"method","ident_start":1735,"ident_end":1752,"extent_start":1705,"extent_end":2110,"fully_qualified_name":"DallasTemperatureSensor::read_scratch_pad_","ident_utf16":{"start":{"line_number":64,"utf16_col":30},"end":{"line_number":64,"utf16_col":47}},"extent_utf16":{"start":{"line_number":64,"utf16_col":0},"end":{"line_number":77,"utf16_col":1}}},{"name":"setup","kind":"method","ident_start":2142,"ident_end":2147,"extent_start":2112,"extent_end":3249,"fully_qualified_name":"DallasTemperatureSensor::setup","ident_utf16":{"start":{"line_number":79,"utf16_col":30},"end":{"line_number":79,"utf16_col":35}},"extent_utf16":{"start":{"line_number":79,"utf16_col":0},"end":{"line_number":126,"utf16_col":1}}},{"name":"check_scratch_pad_","kind":"method","ident_start":3281,"ident_end":3299,"extent_start":3251,"extent_end":3993,"fully_qualified_name":"DallasTemperatureSensor::check_scratch_pad_","ident_utf16":{"start":{"line_number":128,"utf16_col":30},"end":{"line_number":128,"utf16_col":48}},"extent_utf16":{"start":{"line_number":128,"utf16_col":0},"end":{"line_number":142,"utf16_col":1}}},{"name":"get_temp_c_","kind":"method","ident_start":4026,"ident_end":4037,"extent_start":3995,"extent_end":4646,"fully_qualified_name":"DallasTemperatureSensor::get_temp_c_","ident_utf16":{"start":{"line_number":144,"utf16_col":31},"end":{"line_number":144,"utf16_col":42}},"extent_utf16":{"start":{"line_number":144,"utf16_col":0},"end":{"line_number":168,"utf16_col":1}}}]}},"copilotInfo":null,"copilotAccessAllowed":false,"csrf_tokens":{"/esphome/esphome/branches":{"post":"jz4za1aDnXF6QSuC2TClkMvB5UCxPS4a48nvnmBWG4Zq7epMj8YEmSrLMb9BHYjSOD9gOFGPaHIKclcF2upsbw"},"/repos/preferences":{"post":"IvKRrxVXWDBwtZYmBJA0sX1oQeffMrCJdAHKFqbI-V8HBODiuBon6YzLJDjOtG7GzxI_x0AVaKo27nw5bXl0MQ"}}},"title":"esphome/esphome/components/dallas_temp/dallas_temp.cpp at dev · esphome/esphome","appPayload":{"helpUrl":"https://docs.github.com","findFileWorkerPath":"/assets-cdn/worker/find-file-worker-1583894afd38.js","findInFileWorkerPath":"/assets-cdn/worker/find-in-file-worker-3a63a487027b.js","githubDevUrl":"https://github.dev/","enabled_features":{"code_nav_ui_events":false,"react_blob_overlay":true,"copilot_conversational_ux_embedding_update":false,"copilot_smell_icebreaker_ux":true,"copilot_workspace":false}}}</script>
  <div data-target="react-app.reactRoot"><style data-styled="true" data-styled-version="5.3.6">.jUriTl{font-weight:600;font-size:32px;margin:0;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;font-size:14px;}/*!sc*/
.imcwCi{font-weight:600;font-size:32px;margin:0;font-size:16px;margin-left:8px;}/*!sc*/
.cgQnMS{font-weight:600;font-size:32px;margin:0;}/*!sc*/
.diwsLq{font-weight:600;font-size:32px;margin:0;font-weight:600;display:inline-block;max-width:100%;font-size:16px;}/*!sc*/
.jAEDJk{font-weight:600;font-size:32px;margin:0;font-weight:600;display:inline-block;max-width:100%;font-size:14px;}/*!sc*/
data-styled.g1[id="Heading__StyledHeading-sc-1c1dgg0-0"]{content:"jUriTl,imcwCi,cgQnMS,diwsLq,jAEDJk,"}/*!sc*/
.fSWWem{padding:0;}/*!sc*/
.kPPmzM{max-width:100%;margin-left:auto;margin-right:auto;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;}/*!sc*/
.cIAPDV{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex:1 1 100%;-ms-flex:1 1 100%;flex:1 1 100%;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;max-width:100%;}/*!sc*/
.gvCnwW{width:100%;}/*!sc*/
@media screen and (min-width:544px){.gvCnwW{width:100%;}}/*!sc*/
@media screen and (min-width:768px){.gvCnwW{width:auto;}}/*!sc*/
.heUiss{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-order:1;-ms-flex-order:1;order:1;width:100%;margin-left:0;margin-right:0;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;margin-bottom:0;min-width:0;}/*!sc*/
@media screen and (min-width:544px){.heUiss{-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}}/*!sc*/
@media screen and (min-width:768px){.heUiss{width:auto;margin-top:0 !important;margin-bottom:0 !important;position:-webkit-sticky;position:sticky;top:0px;max-height:var(--sticky-pane-height);-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;margin-right:0;}}/*!sc*/
@media screen and (min-width:769px){.heUiss{height:100vh;max-height:100vh !important;}}/*!sc*/
@media print,screen and (max-width:1349px) and (min-width:768px){.heUiss{display:none;}}/*!sc*/
.eUyHuk{margin-left:0;margin-right:0;display:none;margin-top:0;}/*!sc*/
@media screen and (min-width:768px){.eUyHuk{margin-left:0 !important;margin-right:0 !important;}}/*!sc*/
.gNdDUH{--pane-min-width:256px;--pane-max-width-diff:511px;--pane-max-width:calc(100vw - var(--pane-max-width-diff));width:100%;padding:0;}/*!sc*/
@media screen and (min-width:544px){}/*!sc*/
@media screen and (min-width:768px){.gNdDUH{width:clamp(var(--pane-min-width),var(--pane-width),var(--pane-max-width));overflow:auto;}}/*!sc*/
@media screen and (min-width:1280px){.gNdDUH{--pane-max-width-diff:959px;}}/*!sc*/
.jywUSN{max-height:100%;height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}/*!sc*/
@media screen and (max-width:768px){.jywUSN{display:none;}}/*!sc*/
@media screen and (min-width:768px){.jywUSN{max-height:100vh;height:100vh;}}/*!sc*/
.hBSSUC{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding-left:16px;padding-right:16px;padding-bottom:8px;padding-top:16px;}/*!sc*/
.iPurHz{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;margin-bottom:16px;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
.kkrdEu{-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;}/*!sc*/
.trpoQ{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;pointer-events:none;}/*!sc*/
.hVHHYa{margin-left:24px;margin-right:24px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;}/*!sc*/
.idZfsJ{-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;}/*!sc*/
.bKgizp{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;}/*!sc*/
.dIAShY{margin-right:4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.caeYDk{font-size:14px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}/*!sc*/
.jahcnb{margin-left:8px;white-space:nowrap;}/*!sc*/
.jahcnb:hover button:not(:hover){border-left-color:var(--button-default-borderColor-hover,var(--color-btn-hover-border));}/*!sc*/
.ccToMy{margin-left:16px;margin-right:16px;margin-bottom:12px;}/*!sc*/
@media screen and (max-width:768px){.ccToMy{display:none;}}/*!sc*/
.cNvKlH{margin-right:-6px;}/*!sc*/
.cLfAnm{-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;max-height:100% !important;overflow-y:auto;-webkit-scrollbar-gutter:stable;-moz-scrollbar-gutter:stable;-ms-scrollbar-gutter:stable;scrollbar-gutter:stable;}/*!sc*/
@media screen and (max-width:768px){.cLfAnm{display:none;}}/*!sc*/
.erWCJP{padding-left:16px;padding-right:16px;padding-bottom:8px;}/*!sc*/
.fUswPC{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;padding:8px;}/*!sc*/
.hAeDYA{height:100%;position:relative;display:none;margin-left:0;}/*!sc*/
.gZHqlw{position:absolute;inset:0 -2px;cursor:col-resize;background-color:transparent;-webkit-transition-delay:0.1s;transition-delay:0.1s;}/*!sc*/
.gZHqlw:hover{background-color:var(--bgColor-neutral-muted,var(--color-neutral-muted,rgba(110,118,129,0.4)));}/*!sc*/
.emFMJu{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-order:2;-ms-flex-order:2;order:2;-webkit-flex-basis:0;-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;min-width:1px;margin-right:auto;}/*!sc*/
@media print{.emFMJu{display:-webkit-box !important;display:-webkit-flex !important;display:-ms-flexbox !important;display:flex !important;}}/*!sc*/
.hlUAHL{width:100%;max-width:100%;margin-left:auto;margin-right:auto;-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;padding:0;}/*!sc*/
.iStsmI{margin-left:auto;margin-right:auto;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;padding-bottom:40px;max-width:100%;margin-top:0;}/*!sc*/
.eIgvIk{display:inherit;}/*!sc*/
.eVFfWF{width:100%;}/*!sc*/
.fywjmm{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;gap:8px;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;width:100%;}/*!sc*/
.dyczTK{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:start;-webkit-box-align:start;-ms-flex-align:start;align-items:start;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;gap:8px;}/*!sc*/
.kszRgZ{-webkit-align-self:center;-ms-flex-item-align:center;align-self:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;padding-right:8px;min-width:0;}/*!sc*/
.eTvGbF{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;font-size:16px;min-width:0;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;max-width:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
.kzRgrI{max-width:100%;}/*!sc*/
.cmAPIB{max-width:100%;list-style:none;display:inline-block;}/*!sc*/
.jwXCBK{display:inline-block;max-width:100%;}/*!sc*/
.gtBUEp{min-height:32px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:start;-webkit-box-align:start;-ms-flex-align:start;align-items:start;}/*!sc*/
.hVZtwF{margin-left:16px;margin-right:16px;}/*!sc*/
.cMYnca{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}/*!sc*/
.brJRqk{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;gap:8px;min-width:273px;padding:8px;}/*!sc*/
@media screen and (min-width:544px){.brJRqk{-webkit-flex-wrap:nowrap;-ms-flex-wrap:nowrap;flex-wrap:nowrap;}}/*!sc*/
.iJmJly{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;}/*!sc*/
.kjydbF{width:100%;height:-webkit-fit-content;height:-moz-fit-content;height:fit-content;min-width:0;margin-right:16px;}/*!sc*/
.gIJuDf{height:40px;padding-left:4px;padding-bottom:16px;}/*!sc*/
.fleZSW{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
.dVVHlo{font-size:12px;-webkit-flex:auto;-ms-flex:auto;flex:auto;padding-right:16px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));min-width:0;}/*!sc*/
.VHzRk{top:0px;z-index:4;background:var(--bgColor-default,var(--color-canvas-default));position:-webkit-sticky;position:sticky;}/*!sc*/
.ePiodO{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;width:100%;position:absolute;}/*!sc*/
.kQJlnf{display:none;min-width:0;padding-top:8px;padding-bottom:8px;}/*!sc*/
.gJICKO{margin-right:8px;margin-left:16px;text-overflow:ellipsis;overflow:hidden;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;width:100%;}/*!sc*/
.iZJewz{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;font-size:14px;min-width:0;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;max-width:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
.jtQniD{padding-left:8px;padding-top:8px;padding-bottom:8px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex:1;-ms-flex:1;flex:1;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;background-color:var(--bgColor-muted,var(--color-canvas-subtle,#161b22));border:1px solid var(--borderColor-default,var(--color-border-default));border-radius:6px 6px 0px 0px;}/*!sc*/
.bfkNRF{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;gap:8px;min-width:0;}/*!sc*/
.fXBLEV{display:block;position:relative;-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;margin-top:-1px;margin-bottom:-1px;--separator-color:transparent;}/*!sc*/
.fXBLEV:not(:last-child){margin-right:1px;}/*!sc*/
.fXBLEV:not(:last-child):after{background-color:var(--separator-color);content:"";position:absolute;right:-2px;top:8px;bottom:8px;width:1px;}/*!sc*/
.fXBLEV:focus-within:has(:focus-visible){--separator-color:transparent;}/*!sc*/
.fXBLEV:first-child{margin-left:-1px;}/*!sc*/
.fXBLEV:last-child{margin-right:-1px;}/*!sc*/
.illvPQ{display:block;position:relative;-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;margin-top:-1px;margin-bottom:-1px;--separator-color:var(--borderColor-default,var(--color-border-default,#30363d));}/*!sc*/
.illvPQ:not(:last-child){margin-right:1px;}/*!sc*/
.illvPQ:not(:last-child):after{background-color:var(--separator-color);content:"";position:absolute;right:-2px;top:8px;bottom:8px;width:1px;}/*!sc*/
.illvPQ:focus-within:has(:focus-visible){--separator-color:transparent;}/*!sc*/
.illvPQ:first-child{margin-left:-1px;}/*!sc*/
.illvPQ:last-child{margin-right:-1px;}/*!sc*/
.iBylDf{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;gap:8px;margin-right:8px;}/*!sc*/
.kSGBPx{gap:8px;}/*!sc*/
.jMJFjm{border:1px solid;border-top:none;border-color:var(--borderColor-default,var(--color-border-default,#30363d));border-radius:0px 0px 6px 6px;min-width:273px;}/*!sc*/
.jWnGGx{background-color:var(--bgColor-default,var(--color-canvas-default));border:0px;border-width:0;border-radius:0px 0px 6px 6px;padding:0;min-width:0;margin-top:46px;}/*!sc*/
.TCenl{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex:1;-ms-flex:1;flex:1;padding-top:8px;padding-bottom:8px;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;min-width:0;position:relative;}/*!sc*/
.cluMzC{position:relative;}/*!sc*/
.eRkHwF{-webkit-flex:1;-ms-flex:1;flex:1;position:relative;min-width:0;}/*!sc*/
.kfwkrr{tab-size:2;isolation:isolate;position:relative;overflow:auto;max-width:unset;}/*!sc*/
.hXUKEK{margin:1px 8px;position:absolute;z-index:1;}/*!sc*/
.cXzIIR{position:absolute;}/*!sc*/
.ktQnIo{padding-bottom:33px;}/*!sc*/
.eytzQM{background-color:var(--bgColor-default,var(--color-canvas-default,#0d1117));border:1px solid;border-color:var(--borderColor-default,var(--color-border-default,#30363d));border-radius:6px;contain:paint;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;height:100%;min-height:0;max-height:100vh;overflow-y:auto;right:0;top:0px;z-index:4;background:var(--bgColor-default,var(--color-canvas-default));position:-webkit-sticky;position:sticky;}/*!sc*/
.bJNAmt{padding-top:8px;padding-bottom:8px;padding-left:16px;padding-right:16px;}/*!sc*/
.ipXucK{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;}/*!sc*/
.wMEyi{font-size:14px;-webkit-order:1;-ms-flex-order:1;order:1;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-weight:600;}/*!sc*/
.fHqdLt{font-size:12px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));padding-top:8px;}/*!sc*/
.ckwgci{margin-right:6px;}/*!sc*/
.jGYebd{margin-left:-16px;margin-bottom:-8px;}/*!sc*/
.kgNotW{margin-bottom:-8px;overflow-y:auto;max-height:calc(100vh - 237px);padding-left:16px;padding-bottom:8px;padding-top:4px;}/*!sc*/
.cFPoqW{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}/*!sc*/
.brdoto{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;position:relative;margin-right:8px;}/*!sc*/
.cDCIeg{background-color:var(--color-prettylights-syntax-entity,#d2a8ff);opacity:0.1;position:absolute;border-radius:5px;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;height:100%;}/*!sc*/
.dIEiEC{color:var(--color-prettylights-syntax-entity,#d2a8ff);border-radius:5px;font-weight:600;font-size:smaller;padding-left:4px;padding-right:4px;padding-top:1px;padding-bottom:1px;}/*!sc*/
.aZrVR{position:fixed;top:0;right:0;height:100%;width:15px;-webkit-transition:-webkit-transform 0.3s;-webkit-transition:transform 0.3s;transition:transform 0.3s;z-index:1;}/*!sc*/
.aZrVR:hover{-webkit-transform:scaleX(1.5);-ms-transform:scaleX(1.5);transform:scaleX(1.5);}/*!sc*/
data-styled.g2[id="Box-sc-g0xbh4-0"]{content:"fSWWem,kPPmzM,cIAPDV,gvCnwW,heUiss,eUyHuk,gNdDUH,jywUSN,hBSSUC,iPurHz,kkrdEu,trpoQ,hVHHYa,idZfsJ,bKgizp,dIAShY,caeYDk,jahcnb,ccToMy,cNvKlH,cLfAnm,erWCJP,fUswPC,hAeDYA,gZHqlw,emFMJu,hlUAHL,iStsmI,eIgvIk,eVFfWF,fywjmm,dyczTK,kszRgZ,eTvGbF,kzRgrI,cmAPIB,jwXCBK,gtBUEp,hVZtwF,cMYnca,brJRqk,iJmJly,kjydbF,gIJuDf,fleZSW,dVVHlo,VHzRk,ePiodO,kQJlnf,gJICKO,iZJewz,jtQniD,bfkNRF,fXBLEV,illvPQ,iBylDf,kSGBPx,jMJFjm,jWnGGx,TCenl,cluMzC,eRkHwF,kfwkrr,hXUKEK,cXzIIR,ktQnIo,eytzQM,bJNAmt,ipXucK,wMEyi,fHqdLt,ckwgci,jGYebd,kgNotW,cFPoqW,brdoto,cDCIeg,dIEiEC,aZrVR,"}/*!sc*/
.iKABXH{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.iKABXH:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.iKABXH:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.iKABXH:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.iKABXH[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.iKABXH[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.iKABXH:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.iKABXH:active{-webkit-transition:none;transition:none;}/*!sc*/
.iKABXH[data-inactive]{cursor:auto;}/*!sc*/
.iKABXH:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.iKABXH:disabled [data-component=ButtonCounter],.iKABXH:disabled [data-component="leadingVisual"],.iKABXH:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.iKABXH:focus{outline:solid 1px transparent;}}/*!sc*/
.iKABXH [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.iKABXH[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.iKABXH[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.iKABXH[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.iKABXH[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.iKABXH[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.iKABXH[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.iKABXH[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.iKABXH[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.iKABXH[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.iKABXH[data-block="block"]{width:100%;}/*!sc*/
.iKABXH[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.iKABXH[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.iKABXH [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.iKABXH [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.iKABXH [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.iKABXH [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.iKABXH [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.iKABXH [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.iKABXH:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.iKABXH:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.iKABXH[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.iKABXH[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.iKABXH[data-no-visuals]{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));}/*!sc*/
.iKABXH:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.iKABXH:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.iKABXH:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
.iKABXH{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));padding-left:8px;padding-right:8px;display:none;}/*!sc*/
@media screen and (max-width:768px){.iKABXH{display:block;}}/*!sc*/
.hfWObv{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.hfWObv:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.hfWObv:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.hfWObv:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.hfWObv[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.hfWObv[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.hfWObv:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.hfWObv:active{-webkit-transition:none;transition:none;}/*!sc*/
.hfWObv[data-inactive]{cursor:auto;}/*!sc*/
.hfWObv:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.hfWObv:disabled [data-component=ButtonCounter],.hfWObv:disabled [data-component="leadingVisual"],.hfWObv:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.hfWObv:focus{outline:solid 1px transparent;}}/*!sc*/
.hfWObv [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.hfWObv[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.hfWObv[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.hfWObv[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.hfWObv[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.hfWObv[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.hfWObv[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.hfWObv[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.hfWObv[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.hfWObv[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.hfWObv[data-block="block"]{width:100%;}/*!sc*/
.hfWObv[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.hfWObv[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.hfWObv [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hfWObv [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.hfWObv [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.hfWObv [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hfWObv [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.hfWObv [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.hfWObv:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.hfWObv:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.hfWObv[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.hfWObv[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hfWObv[data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));height:32px;position:relative;}/*!sc*/
@media screen and (max-width:768px){.hfWObv[data-no-visuals]{display:none;}}/*!sc*/
.hfWObv:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.hfWObv:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.hfWObv:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
.gBsjGI{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.gBsjGI:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.gBsjGI:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.gBsjGI:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.gBsjGI[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.gBsjGI[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.gBsjGI:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.gBsjGI:active{-webkit-transition:none;transition:none;}/*!sc*/
.gBsjGI[data-inactive]{cursor:auto;}/*!sc*/
.gBsjGI:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.gBsjGI:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.gBsjGI:focus{outline:solid 1px transparent;}}/*!sc*/
.gBsjGI [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.gBsjGI[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.gBsjGI[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.gBsjGI[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.gBsjGI[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.gBsjGI[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.gBsjGI[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.gBsjGI[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.gBsjGI[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.gBsjGI[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.gBsjGI[data-block="block"]{width:100%;}/*!sc*/
.gBsjGI[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.gBsjGI[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.gBsjGI [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.gBsjGI [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.gBsjGI [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.gBsjGI [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.gBsjGI [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.gBsjGI [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.gBsjGI:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.gBsjGI:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.gBsjGI[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.gBsjGI [data-component="leadingVisual"],.gBsjGI [data-component="trailingVisual"],.gBsjGI [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.gBsjGI[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.gBsjGI{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;min-width:0;}/*!sc*/
.gBsjGI svg{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.gBsjGI > span{width:inherit;}/*!sc*/
.XJZbf{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.XJZbf:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.XJZbf:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.XJZbf:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.XJZbf[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.XJZbf[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.XJZbf:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.XJZbf:active{-webkit-transition:none;transition:none;}/*!sc*/
.XJZbf[data-inactive]{cursor:auto;}/*!sc*/
.XJZbf:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.XJZbf:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.XJZbf:focus{outline:solid 1px transparent;}}/*!sc*/
.XJZbf [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.XJZbf[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.XJZbf[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.XJZbf[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.XJZbf[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.XJZbf[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.XJZbf[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.XJZbf[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.XJZbf[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.XJZbf[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.XJZbf[data-block="block"]{width:100%;}/*!sc*/
.XJZbf[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.XJZbf[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.XJZbf [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.XJZbf [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.XJZbf [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.XJZbf [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.XJZbf [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.XJZbf [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.XJZbf:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.XJZbf:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.XJZbf[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.XJZbf [data-component="leadingVisual"],.XJZbf [data-component="trailingVisual"],.XJZbf [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.XJZbf[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.XJZbf[data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-subtle,#6e7681));border-top-right-radius:0;border-bottom-right-radius:0;border-right:0;}/*!sc*/
.cBjhIZ{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.cBjhIZ:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.cBjhIZ:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.cBjhIZ:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.cBjhIZ[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.cBjhIZ[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.cBjhIZ:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.cBjhIZ:active{-webkit-transition:none;transition:none;}/*!sc*/
.cBjhIZ[data-inactive]{cursor:auto;}/*!sc*/
.cBjhIZ:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.cBjhIZ:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.cBjhIZ:focus{outline:solid 1px transparent;}}/*!sc*/
.cBjhIZ [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.cBjhIZ[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.cBjhIZ[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.cBjhIZ[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.cBjhIZ[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.cBjhIZ[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.cBjhIZ[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.cBjhIZ[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.cBjhIZ[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.cBjhIZ[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.cBjhIZ[data-block="block"]{width:100%;}/*!sc*/
.cBjhIZ[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.cBjhIZ[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.cBjhIZ [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.cBjhIZ [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.cBjhIZ [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.cBjhIZ [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.cBjhIZ [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.cBjhIZ [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.cBjhIZ:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.cBjhIZ:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.cBjhIZ[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.cBjhIZ [data-component="leadingVisual"],.cBjhIZ [data-component="trailingVisual"],.cBjhIZ [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.cBjhIZ[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.cBjhIZ[data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-subtle,#6e7681));font-size:14px;font-weight:400;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;border-top-left-radius:0;border-bottom-left-radius:0;}/*!sc*/
.hWITRv{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.hWITRv:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.hWITRv:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.hWITRv:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.hWITRv[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.hWITRv[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.hWITRv:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.hWITRv:active{-webkit-transition:none;transition:none;}/*!sc*/
.hWITRv[data-inactive]{cursor:auto;}/*!sc*/
.hWITRv:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.hWITRv:disabled [data-component=ButtonCounter],.hWITRv:disabled [data-component="leadingVisual"],.hWITRv:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.hWITRv:focus{outline:solid 1px transparent;}}/*!sc*/
.hWITRv [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.hWITRv[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.hWITRv[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.hWITRv[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.hWITRv[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.hWITRv[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.hWITRv[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.hWITRv[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.hWITRv[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.hWITRv[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.hWITRv[data-block="block"]{width:100%;}/*!sc*/
.hWITRv[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.hWITRv[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.hWITRv [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hWITRv [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.hWITRv [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.hWITRv [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hWITRv [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.hWITRv [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.hWITRv:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.hWITRv:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.hWITRv[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.hWITRv[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hWITRv[data-no-visuals]{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));}/*!sc*/
.hWITRv:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.hWITRv:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.hWITRv:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
.fXsbsD{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.fXsbsD:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.fXsbsD:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.fXsbsD:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.fXsbsD[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.fXsbsD[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.fXsbsD:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.fXsbsD:active{-webkit-transition:none;transition:none;}/*!sc*/
.fXsbsD[data-inactive]{cursor:auto;}/*!sc*/
.fXsbsD:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.fXsbsD:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.fXsbsD:focus{outline:solid 1px transparent;}}/*!sc*/
.fXsbsD [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.fXsbsD[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.fXsbsD[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.fXsbsD[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.fXsbsD[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.fXsbsD[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.fXsbsD[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.fXsbsD[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.fXsbsD[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.fXsbsD[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.fXsbsD[data-block="block"]{width:100%;}/*!sc*/
.fXsbsD[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.fXsbsD[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.fXsbsD [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.fXsbsD [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.fXsbsD [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.fXsbsD [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.fXsbsD [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.fXsbsD [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.fXsbsD:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.fXsbsD:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.fXsbsD[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.fXsbsD [data-component="leadingVisual"],.fXsbsD [data-component="trailingVisual"],.fXsbsD [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.fXsbsD[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.fXsbsD[data-no-visuals]{border-top-left-radius:0;border-bottom-left-radius:0;display:none;}/*!sc*/
.hiXxwe{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.hiXxwe:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.hiXxwe:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.hiXxwe:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.hiXxwe[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.hiXxwe[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.hiXxwe:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.hiXxwe:active{-webkit-transition:none;transition:none;}/*!sc*/
.hiXxwe[data-inactive]{cursor:auto;}/*!sc*/
.hiXxwe:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.hiXxwe:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.hiXxwe:focus{outline:solid 1px transparent;}}/*!sc*/
.hiXxwe [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.hiXxwe[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.hiXxwe[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.hiXxwe[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.hiXxwe[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.hiXxwe[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.hiXxwe[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.hiXxwe[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.hiXxwe[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.hiXxwe[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.hiXxwe[data-block="block"]{width:100%;}/*!sc*/
.hiXxwe[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.hiXxwe[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.hiXxwe [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.hiXxwe [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.hiXxwe [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.hiXxwe [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.hiXxwe [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.hiXxwe [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.hiXxwe:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.hiXxwe:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.hiXxwe[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.hiXxwe [data-component="leadingVisual"],.hiXxwe [data-component="trailingVisual"],.hiXxwe [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.hiXxwe[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.hiXxwe[data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.ecGgfP{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.ecGgfP:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.ecGgfP:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.ecGgfP:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.ecGgfP[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.ecGgfP[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.ecGgfP:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.ecGgfP:active{-webkit-transition:none;transition:none;}/*!sc*/
.ecGgfP[data-inactive]{cursor:auto;}/*!sc*/
.ecGgfP:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.ecGgfP:disabled [data-component=ButtonCounter],.ecGgfP:disabled [data-component="leadingVisual"],.ecGgfP:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.ecGgfP:focus{outline:solid 1px transparent;}}/*!sc*/
.ecGgfP [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.ecGgfP[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.ecGgfP[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;color:var(--fgColor-default,var(--color-fg-default,#e6edf3));margin-left:8px;}/*!sc*/
.ecGgfP[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.ecGgfP[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.ecGgfP[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.ecGgfP[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.ecGgfP[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.ecGgfP[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.ecGgfP[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.ecGgfP[data-block="block"]{width:100%;}/*!sc*/
.ecGgfP[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.ecGgfP[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.ecGgfP [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.ecGgfP [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.ecGgfP [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.ecGgfP [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.ecGgfP [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.ecGgfP [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.ecGgfP:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.ecGgfP:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.ecGgfP[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.ecGgfP[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.ecGgfP[data-no-visuals]{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));}/*!sc*/
.ecGgfP:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.ecGgfP:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.ecGgfP:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
.dupbIv{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));padding-left:8px;padding-right:8px;}/*!sc*/
.dupbIv:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.dupbIv:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.dupbIv:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.dupbIv[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.dupbIv[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.dupbIv:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.dupbIv:active{-webkit-transition:none;transition:none;}/*!sc*/
.dupbIv[data-inactive]{cursor:auto;}/*!sc*/
.dupbIv:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.dupbIv:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.dupbIv:focus{outline:solid 1px transparent;}}/*!sc*/
.dupbIv [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.dupbIv[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.dupbIv[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.dupbIv[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.dupbIv[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.dupbIv[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.dupbIv[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.dupbIv[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.dupbIv[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.dupbIv[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.dupbIv[data-block="block"]{width:100%;}/*!sc*/
.dupbIv[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.dupbIv[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.dupbIv [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.dupbIv [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.dupbIv [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.dupbIv [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.dupbIv [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.dupbIv [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.dupbIv:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.dupbIv:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.dupbIv[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.dupbIv [data-component="leadingVisual"],.dupbIv [data-component="trailingVisual"],.dupbIv [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.dupbIv[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.dupbIv linkButtonSx:hover:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.dupbIv linkButtonSx:focus:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.dupbIv linkButtonSx:active:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.dMUxwi{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.dMUxwi:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.dMUxwi:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.dMUxwi:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.dMUxwi[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.dMUxwi[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.dMUxwi:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.dMUxwi:active{-webkit-transition:none;transition:none;}/*!sc*/
.dMUxwi[data-inactive]{cursor:auto;}/*!sc*/
.dMUxwi:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.dMUxwi:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.dMUxwi:focus{outline:solid 1px transparent;}}/*!sc*/
.dMUxwi [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.dMUxwi[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.dMUxwi[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.dMUxwi[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.dMUxwi[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.dMUxwi[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.dMUxwi[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.dMUxwi[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.dMUxwi[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.dMUxwi[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.dMUxwi[data-block="block"]{width:100%;}/*!sc*/
.dMUxwi[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.dMUxwi[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.dMUxwi [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.dMUxwi [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.dMUxwi [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.dMUxwi [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.dMUxwi [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.dMUxwi [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.dMUxwi:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.dMUxwi:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.dMUxwi[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.dMUxwi [data-component="leadingVisual"],.dMUxwi [data-component="trailingVisual"],.dMUxwi [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.dMUxwi[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.fCIOmi{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.fCIOmi:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.fCIOmi:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.fCIOmi:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.fCIOmi[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.fCIOmi[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.fCIOmi:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.fCIOmi:active{-webkit-transition:none;transition:none;}/*!sc*/
.fCIOmi[data-inactive]{cursor:auto;}/*!sc*/
.fCIOmi:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.fCIOmi:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.fCIOmi:focus{outline:solid 1px transparent;}}/*!sc*/
.fCIOmi [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.fCIOmi[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.fCIOmi[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.fCIOmi[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.fCIOmi[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.fCIOmi[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.fCIOmi[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.fCIOmi[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.fCIOmi[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.fCIOmi[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.fCIOmi[data-block="block"]{width:100%;}/*!sc*/
.fCIOmi[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.fCIOmi[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.fCIOmi [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.fCIOmi [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.fCIOmi [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.fCIOmi [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.fCIOmi [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.fCIOmi [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.fCIOmi:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.fCIOmi:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.fCIOmi[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.fCIOmi [data-component="leadingVisual"],.fCIOmi [data-component="trailingVisual"],.fCIOmi [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.fCIOmi[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.fCIOmi[data-size="small"][data-no-visuals]{border-top-left-radius:0;border-bottom-left-radius:0;}/*!sc*/
.ksnFc{border-radius:6px;border:1px solid;border-color:var(--button-default-borderColor-rest,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:var(--button-default-bgColor-rest,var(--color-btn-bg,#21262d));box-shadow:var(--button-default-shadow-resting,var(--color-btn-shadow,0 0 transparent)),var(--button-default-shadow-inset,var(--color-btn-inset-shadow,0 0 transparent));}/*!sc*/
.ksnFc:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.ksnFc:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.ksnFc:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.ksnFc[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.ksnFc[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.ksnFc:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.ksnFc:active{-webkit-transition:none;transition:none;}/*!sc*/
.ksnFc[data-inactive]{cursor:auto;}/*!sc*/
.ksnFc:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));border-color:var(--button-default-borderColor-disabled,var(--button-default-borderColor-rest,var(--color-btn-border,rgba(240,246,252,0.1))));background-color:var(--button-default-bgColor-disabled,var(--control-bgColor-disabled,var(--color-input-disabled-bg,rgba(110,118,129,0))));}/*!sc*/
.ksnFc:disabled [data-component=ButtonCounter]{color:inherit;}/*!sc*/
@media (forced-colors:active){.ksnFc:focus{outline:solid 1px transparent;}}/*!sc*/
.ksnFc [data-component=ButtonCounter]{font-size:12px;background-color:var(--buttonCounter-default-bgColor-rest,var(--color-btn-counter-bg,#30363d));}/*!sc*/
.ksnFc[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.ksnFc[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.ksnFc[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.ksnFc[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.ksnFc[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.ksnFc[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.ksnFc[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.ksnFc[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.ksnFc[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.ksnFc[data-block="block"]{width:100%;}/*!sc*/
.ksnFc[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.ksnFc[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.ksnFc [data-component="leadingVisual"]{grid-area:leadingVisual;}/*!sc*/
.ksnFc [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.ksnFc [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.ksnFc [data-component="trailingAction"]{margin-right:-4px;}/*!sc*/
.ksnFc [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.ksnFc [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.ksnFc:hover:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-hover,var(--color-btn-hover-bg,#30363d));border-color:var(--button-default-borderColor-hover,var(--button-default-borderColor-hover,var(--color-btn-hover-border,#8b949e)));}/*!sc*/
.ksnFc:active:not([disabled]):not([data-inactive]){background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.ksnFc[aria-expanded=true]{background-color:var(--button-default-bgColor-active,var(--color-btn-active-bg,hsla(212,12%,18%,1)));border-color:var(--button-default-borderColor-active,var(--button-default-borderColor-active,var(--color-btn-active-border,#6e7681)));}/*!sc*/
.ksnFc [data-component="leadingVisual"],.ksnFc [data-component="trailingVisual"],.ksnFc [data-component="trailingAction"]{color:var(--button-color,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.ksnFc[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.ksnFc[data-size="small"][data-no-visuals]{border-top-right-radius:0;border-bottom-right-radius:0;border-right-width:0;}/*!sc*/
.ksnFc[data-size="small"][data-no-visuals]:hover:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.ksnFc[data-size="small"][data-no-visuals]:focus:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.ksnFc[data-size="small"][data-no-visuals]:active:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.jgnIDP{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.jgnIDP:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.jgnIDP:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.jgnIDP:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.jgnIDP[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.jgnIDP[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.jgnIDP:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.jgnIDP:active{-webkit-transition:none;transition:none;}/*!sc*/
.jgnIDP[data-inactive]{cursor:auto;}/*!sc*/
.jgnIDP:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.jgnIDP:disabled [data-component=ButtonCounter],.jgnIDP:disabled [data-component="leadingVisual"],.jgnIDP:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.jgnIDP:focus{outline:solid 1px transparent;}}/*!sc*/
.jgnIDP [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.jgnIDP[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.jgnIDP[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.jgnIDP[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.jgnIDP[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.jgnIDP[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.jgnIDP[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.jgnIDP[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.jgnIDP[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.jgnIDP[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.jgnIDP[data-block="block"]{width:100%;}/*!sc*/
.jgnIDP[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.jgnIDP[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.jgnIDP [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.jgnIDP [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.jgnIDP [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.jgnIDP [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.jgnIDP [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.jgnIDP [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.jgnIDP:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.jgnIDP:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.jgnIDP[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.jgnIDP[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.jgnIDP[data-no-visuals]{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));}/*!sc*/
.jgnIDP:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.jgnIDP:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.jgnIDP:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
.jgnIDP[data-size="small"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));position:relative;}/*!sc*/
.htXhGX{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.htXhGX:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.htXhGX:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.htXhGX:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.htXhGX[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.htXhGX[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.htXhGX:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.htXhGX:active{-webkit-transition:none;transition:none;}/*!sc*/
.htXhGX[data-inactive]{cursor:auto;}/*!sc*/
.htXhGX:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.htXhGX:disabled [data-component=ButtonCounter],.htXhGX:disabled [data-component="leadingVisual"],.htXhGX:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.htXhGX:focus{outline:solid 1px transparent;}}/*!sc*/
.htXhGX [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.htXhGX[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.htXhGX[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.htXhGX[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.htXhGX[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.htXhGX[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.htXhGX[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.htXhGX[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.htXhGX[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.htXhGX[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.htXhGX[data-block="block"]{width:100%;}/*!sc*/
.htXhGX[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.htXhGX[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.htXhGX [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.htXhGX [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.htXhGX [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.htXhGX [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.htXhGX [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.htXhGX [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.htXhGX:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.htXhGX:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.htXhGX[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.htXhGX[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.htXhGX[data-no-visuals]{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));}/*!sc*/
.htXhGX:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.htXhGX:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.htXhGX:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
.htXhGX[data-size="small"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.eyqOHf{border-radius:6px;border:1px solid;border-color:transparent;font-family:inherit;font-weight:500;font-size:14px;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-text-decoration:none;text-decoration:none;text-align:center;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:32px;padding:0 12px;gap:8px;min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content;-webkit-transition:80ms cubic-bezier(0.65,0,0.35,1);transition:80ms cubic-bezier(0.65,0,0.35,1);-webkit-transition-property:color,fill,background-color,border-color;transition-property:color,fill,background-color,border-color;color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));background-color:transparent;box-shadow:none;}/*!sc*/
.eyqOHf:focus:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.eyqOHf:focus:not(:disabled):not(:focus-visible){outline:solid 1px transparent;}/*!sc*/
.eyqOHf:focus-visible:not(:disabled){box-shadow:none;outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-2px;}/*!sc*/
.eyqOHf[href]{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;}/*!sc*/
.eyqOHf[href]:hover{-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.eyqOHf:hover{-webkit-transition-duration:80ms;transition-duration:80ms;}/*!sc*/
.eyqOHf:active{-webkit-transition:none;transition:none;}/*!sc*/
.eyqOHf[data-inactive]{cursor:auto;}/*!sc*/
.eyqOHf:disabled{cursor:not-allowed;box-shadow:none;color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.eyqOHf:disabled [data-component=ButtonCounter],.eyqOHf:disabled [data-component="leadingVisual"],.eyqOHf:disabled [data-component="trailingAction"]{color:inherit;}/*!sc*/
@media (forced-colors:active){.eyqOHf:focus{outline:solid 1px transparent;}}/*!sc*/
.eyqOHf [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.eyqOHf[data-component=IconButton]{display:inline-grid;padding:unset;place-content:center;width:32px;min-width:unset;}/*!sc*/
.eyqOHf[data-size="small"]{padding:0 8px;height:28px;gap:4px;font-size:12px;}/*!sc*/
.eyqOHf[data-size="small"] [data-component="text"]{line-height:calc(20 / 12);}/*!sc*/
.eyqOHf[data-size="small"] [data-component=ButtonCounter]{font-size:12px;}/*!sc*/
.eyqOHf[data-size="small"] [data-component="buttonContent"] > :not(:last-child){margin-right:4px;}/*!sc*/
.eyqOHf[data-size="small"][data-component=IconButton]{width:28px;padding:unset;}/*!sc*/
.eyqOHf[data-size="large"]{padding:0 16px;height:40px;gap:8px;}/*!sc*/
.eyqOHf[data-size="large"] [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.eyqOHf[data-size="large"][data-component=IconButton]{width:40px;padding:unset;}/*!sc*/
.eyqOHf[data-block="block"]{width:100%;}/*!sc*/
.eyqOHf[data-inactive]:not([disabled]){background-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));border-color:var(--button-inactive-bgColor,var(--button-inactive-bgColor-rest,var(--color-btn-inactive-bg,#21262d)));color:var(--button-inactive-fgColor,var(--button-inactive-fgColor-rest,var(--color-btn-inactive-text,#8b949e)));}/*!sc*/
.eyqOHf[data-inactive]:not([disabled]):focus-visible{box-shadow:none;}/*!sc*/
.eyqOHf [data-component="leadingVisual"]{grid-area:leadingVisual;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.eyqOHf [data-component="text"]{grid-area:text;line-height:calc(20/14);white-space:nowrap;}/*!sc*/
.eyqOHf [data-component="trailingVisual"]{grid-area:trailingVisual;}/*!sc*/
.eyqOHf [data-component="trailingAction"]{margin-right:-4px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.eyqOHf [data-component="buttonContent"]{-webkit-flex:1 0 auto;-ms-flex:1 0 auto;flex:1 0 auto;display:grid;grid-template-areas:"leadingVisual text trailingVisual";grid-template-columns:min-content minmax(0,auto) min-content;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;}/*!sc*/
.eyqOHf [data-component="buttonContent"] > :not(:last-child){margin-right:8px;}/*!sc*/
.eyqOHf:hover:not([disabled]){background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.eyqOHf:active:not([disabled]){background-color:var(--control-transparent-bgColor-active,var(--color-action-list-item-default-active-bg,rgba(177,186,196,0.2)));}/*!sc*/
.eyqOHf[aria-expanded=true]{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.eyqOHf[data-component="IconButton"][data-no-visuals]{color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.eyqOHf[data-no-visuals]{color:var(--fgColor-default,var(--color-fg-default,#e6edf3));-webkit-order:3;-ms-flex-order:3;order:3;margin-right:-8px;}/*!sc*/
.eyqOHf:has([data-component="ButtonCounter"]){color:var(--button-default-fgColor-rest,var(--color-btn-text,#c9d1d9));}/*!sc*/
.eyqOHf:disabled[data-no-visuals]{color:var(--fgColor-disabled,var(--color-primer-fg-disabled,#484f58));}/*!sc*/
.eyqOHf:disabled[data-no-visuals] [data-component=ButtonCounter]{color:inherit;}/*!sc*/
data-styled.g4[id="types__StyledButton-sc-ws60qy-0"]{content:"iKABXH,hfWObv,gBsjGI,XJZbf,cBjhIZ,hWITRv,fXsbsD,hiXxwe,ecGgfP,dupbIv,dMUxwi,fCIOmi,ksnFc,jgnIDP,htXhGX,eyqOHf,"}/*!sc*/
.rTZSs{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;-webkit-clip:rect(0,0,0,0);clip:rect(0,0,0,0);white-space:nowrap;border-width:0;}/*!sc*/
data-styled.g5[id="_VisuallyHidden__VisuallyHidden-sc-11jhm7a-0"]{content:"rTZSs,"}/*!sc*/
.bOMzPg{min-width:0;}/*!sc*/
.ePvrxx{padding-left:4px;padding-right:4px;font-weight:400;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));font-size:16px;}/*!sc*/
.fQxKLn{padding-left:4px;padding-right:4px;font-weight:400;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));font-size:14px;}/*!sc*/
data-styled.g7[id="Text-sc-17v1xeu-0"]{content:"bOMzPg,ePvrxx,gPDEWA,fQxKLn,"}/*!sc*/
.dpowyu{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));-webkit-text-decoration:none;text-decoration:none;font-weight:600;}/*!sc*/
[data-a11y-link-underlines='true'] .Link__StyledLink-sc-14289xe-0[data-inline='true']{-webkit-text-decoration:underline;text-decoration:underline;}/*!sc*/
.dpowyu:hover{-webkit-text-decoration:underline;text-decoration:underline;}/*!sc*/
.dpowyu:is(button){display:inline-block;padding:0;font-size:inherit;white-space:nowrap;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:0;-webkit-appearance:none;-moz-appearance:none;appearance:none;}/*!sc*/
.csCkZA{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));-webkit-text-decoration:none;text-decoration:none;font-weight:400;}/*!sc*/
[data-a11y-link-underlines='true'] .Link__StyledLink-sc-14289xe-0[data-inline='true']{-webkit-text-decoration:underline;text-decoration:underline;}/*!sc*/
.csCkZA:hover{-webkit-text-decoration:underline;text-decoration:underline;}/*!sc*/
.csCkZA:is(button){display:inline-block;padding:0;font-size:inherit;white-space:nowrap;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:0;-webkit-appearance:none;-moz-appearance:none;appearance:none;}/*!sc*/
.elltiT{color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
[data-a11y-link-underlines='true'] .Link__StyledLink-sc-14289xe-0[data-inline='true']{-webkit-text-decoration:underline;text-decoration:underline;}/*!sc*/
.elltiT:hover{-webkit-text-decoration:underline;text-decoration:underline;}/*!sc*/
.elltiT:is(button){display:inline-block;padding:0;font-size:inherit;white-space:nowrap;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:0;-webkit-appearance:none;-moz-appearance:none;appearance:none;}/*!sc*/
data-styled.g8[id="Link__StyledLink-sc-14289xe-0"]{content:"dpowyu,csCkZA,elltiT,"}/*!sc*/
.hPEVNM{-webkit-animation:rotate-keyframes 1s linear infinite;animation:rotate-keyframes 1s linear infinite;}/*!sc*/
@-webkit-keyframes rotate-keyframes{100%{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}/*!sc*/
@keyframes rotate-keyframes{100%{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg);}}/*!sc*/
data-styled.g9[id="Spinner__StyledSpinner-sc-1knt686-0"]{content:"hPEVNM,"}/*!sc*/
.kbCZWh{font-size:14px;line-height:20px;color:var(--fgColor-default,var(--color-fg-default,#e6edf3));vertical-align:middle;background-color:var(--bgColor-default,var(--color-canvas-default,#0d1117));border:1px solid var(--control-borderColor-rest,var(--borderColor-default,var(--color-border-default,#30363d)));border-radius:6px;outline:none;box-shadow:var(--shadow-inset,var(--color-primer-shadow-inset,0 0 transparent));display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;min-height:32px;overflow:hidden;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;min-width:160px;}/*!sc*/
.kbCZWh input,.kbCZWh textarea{cursor:text;}/*!sc*/
.kbCZWh select{cursor:pointer;}/*!sc*/
.kbCZWh input::-webkit-input-placeholder,.kbCZWh textarea::-webkit-input-placeholder,.kbCZWh select::-webkit-input-placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.kbCZWh input::-moz-placeholder,.kbCZWh textarea::-moz-placeholder,.kbCZWh select::-moz-placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.kbCZWh input:-ms-input-placeholder,.kbCZWh textarea:-ms-input-placeholder,.kbCZWh select:-ms-input-placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.kbCZWh input::placeholder,.kbCZWh textarea::placeholder,.kbCZWh select::placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.kbCZWh:focus-within{border-color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline:2px solid var(--fgColor-accent,var(--color-accent-fg,#2f81f7));outline-offset:-1px;}/*!sc*/
.kbCZWh > textarea{padding:12px;}/*!sc*/
@media (min-width:768px){.kbCZWh{font-size:14px;}}/*!sc*/
.dPpnEo{font-size:14px;line-height:20px;color:var(--fgColor-default,var(--color-fg-default,#e6edf3));vertical-align:middle;background-color:var(--bgColor-default,var(--color-canvas-default,#0d1117));border:1px solid var(--control-borderColor-rest,var(--borderColor-default,var(--color-border-default,#30363d)));border-radius:6px;outline:none;box-shadow:var(--shadow-inset,var(--color-primer-shadow-inset,0 0 transparent));display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;min-height:32px;overflow:hidden;width:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-self:stretch;-ms-flex-item-align:stretch;align-self:stretch;margin-top:8px;border-radius:6px;}/*!sc*/
.dPpnEo input,.dPpnEo textarea{cursor:text;}/*!sc*/
.dPpnEo select{cursor:pointer;}/*!sc*/
.dPpnEo input::-webkit-input-placeholder,.dPpnEo textarea::-webkit-input-placeholder,.dPpnEo select::-webkit-input-placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.dPpnEo input::-moz-placeholder,.dPpnEo textarea::-moz-placeholder,.dPpnEo select::-moz-placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.dPpnEo input:-ms-input-placeholder,.dPpnEo textarea:-ms-input-placeholder,.dPpnEo select:-ms-input-placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.dPpnEo input::placeholder,.dPpnEo textarea::placeholder,.dPpnEo select::placeholder{color:var(---control-fgColor-placeholder,var(--fgColor-muted,var(--color-fg-muted,#848d97)));}/*!sc*/
.dPpnEo > textarea{padding:12px;}/*!sc*/
@media (min-width:768px){.dPpnEo{font-size:14px;}}/*!sc*/
data-styled.g10[id="TextInputWrapper__TextInputBaseWrapper-sc-1mqhpbi-0"]{content:"kbCZWh,dPpnEo,"}/*!sc*/
.jxgrJS{background-repeat:no-repeat;background-position:right 8px center;padding-left:12px;padding-right:12px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;min-width:160px;}/*!sc*/
.jxgrJS > :not(:last-child){margin-right:8px;}/*!sc*/
.jxgrJS .TextInput-icon,.jxgrJS .TextInput-action{-webkit-align-self:center;-ms-flex-item-align:center;align-self:center;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;}/*!sc*/
.jxgrJS > input,.jxgrJS > select{padding-left:0;padding-right:0;}/*!sc*/
.dWJhEx{background-repeat:no-repeat;background-position:right 8px center;padding-left:12px;padding-right:0;margin-top:8px;border-radius:6px;}/*!sc*/
.dWJhEx > :not(:last-child){margin-right:8px;}/*!sc*/
.dWJhEx .TextInput-icon,.dWJhEx .TextInput-action{-webkit-align-self:center;-ms-flex-item-align:center;align-self:center;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;}/*!sc*/
.dWJhEx > input,.dWJhEx > select{padding-left:0;padding-right:0;}/*!sc*/
data-styled.g11[id="TextInputWrapper-sc-1mqhpbi-1"]{content:"jxgrJS,dWJhEx,"}/*!sc*/
.izAlVj{position:relative;display:inline-block;}/*!sc*/
.izAlVj::after{position:absolute;z-index:1000000;display:none;padding:0.5em 0.75em;font:normal normal 11px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji";-webkit-font-smoothing:subpixel-antialiased;color:var(--fgColor-onEmphasis,var(--color-fg-on-emphasis,#ffffff));text-align:center;-webkit-text-decoration:none;text-decoration:none;text-shadow:none;text-transform:none;-webkit-letter-spacing:normal;-moz-letter-spacing:normal;-ms-letter-spacing:normal;letter-spacing:normal;word-wrap:break-word;white-space:pre;pointer-events:none;content:attr(aria-label);background:var(--bgColor-emphasis,var(--color-neutral-emphasis-plus,#6e7681));border-radius:6px;opacity:0;}/*!sc*/
@-webkit-keyframes tooltip-appear{from{opacity:0;}to{opacity:1;}}/*!sc*/
@keyframes tooltip-appear{from{opacity:0;}to{opacity:1;}}/*!sc*/
.izAlVj:hover::after,.izAlVj:active::after,.izAlVj:focus::after,.izAlVj:focus-within::after{display:inline-block;-webkit-text-decoration:none;text-decoration:none;-webkit-animation-name:tooltip-appear;animation-name:tooltip-appear;-webkit-animation-duration:0.1s;animation-duration:0.1s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in;-webkit-animation-delay:0s;animation-delay:0s;}/*!sc*/
.izAlVj.tooltipped-no-delay:hover::after,.izAlVj.tooltipped-no-delay:active::after,.izAlVj.tooltipped-no-delay:focus::after,.izAlVj.tooltipped-no-delay:focus-within::after{-webkit-animation-delay:0s;animation-delay:0s;}/*!sc*/
.izAlVj.tooltipped-multiline:hover::after,.izAlVj.tooltipped-multiline:active::after,.izAlVj.tooltipped-multiline:focus::after,.izAlVj.tooltipped-multiline:focus-within::after{display:table-cell;}/*!sc*/
.izAlVj.tooltipped-s::after,.izAlVj.tooltipped-se::after,.izAlVj.tooltipped-sw::after{top:100%;right:50%;margin-top:6px;}/*!sc*/
.izAlVj.tooltipped-se::after{right:auto;left:50%;margin-left:-16px;}/*!sc*/
.izAlVj.tooltipped-sw::after{margin-right:-16px;}/*!sc*/
.izAlVj.tooltipped-n::after,.izAlVj.tooltipped-ne::after,.izAlVj.tooltipped-nw::after{right:50%;bottom:100%;margin-bottom:6px;}/*!sc*/
.izAlVj.tooltipped-ne::after{right:auto;left:50%;margin-left:-16px;}/*!sc*/
.izAlVj.tooltipped-nw::after{margin-right:-16px;}/*!sc*/
.izAlVj.tooltipped-s::after,.izAlVj.tooltipped-n::after{-webkit-transform:translateX(50%);-ms-transform:translateX(50%);transform:translateX(50%);}/*!sc*/
.izAlVj.tooltipped-w::after{right:100%;bottom:50%;margin-right:6px;-webkit-transform:translateY(50%);-ms-transform:translateY(50%);transform:translateY(50%);}/*!sc*/
.izAlVj.tooltipped-e::after{bottom:50%;left:100%;margin-left:6px;-webkit-transform:translateY(50%);-ms-transform:translateY(50%);transform:translateY(50%);}/*!sc*/
.izAlVj.tooltipped-multiline::after{width:-webkit-max-content;width:-moz-max-content;width:max-content;max-width:250px;word-wrap:break-word;white-space:pre-line;border-collapse:separate;}/*!sc*/
.izAlVj.tooltipped-multiline.tooltipped-s::after,.izAlVj.tooltipped-multiline.tooltipped-n::after{right:auto;left:50%;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%);}/*!sc*/
.izAlVj.tooltipped-multiline.tooltipped-w::after,.izAlVj.tooltipped-multiline.tooltipped-e::after{right:100%;}/*!sc*/
.izAlVj.tooltipped-align-right-2::after{right:0;margin-right:0;}/*!sc*/
.izAlVj.tooltipped-align-left-2::after{left:0;margin-left:0;}/*!sc*/
data-styled.g13[id="Tooltip__TooltipBase-sc-17tf59c-0"]{content:"izAlVj,"}/*!sc*/
.cDLBls{border:0;font-size:inherit;font-family:inherit;background-color:transparent;-webkit-appearance:none;color:inherit;width:100%;}/*!sc*/
.cDLBls:focus{outline:0;}/*!sc*/
data-styled.g14[id="UnstyledTextInput-sc-14ypya-0"]{content:"cDLBls,"}/*!sc*/
body[data-page-layout-dragging="true"]{cursor:col-resize;}/*!sc*/
body[data-page-layout-dragging="true"] *{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}/*!sc*/
data-styled.g15[id="sc-global-gbKrvU1"]{content:"sc-global-gbKrvU1,"}/*!sc*/
.bfhvai{list-style:none;padding:0;margin:0;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item{outline:none;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item:focus-visible > div,.bfhvai .PRIVATE_TreeView-item.focus-visible > div{box-shadow:inset 0 0 0 2px var(--fgColor-accent,var(--color-accent-fg,#2f81f7));}/*!sc*/
@media (forced-colors:active){.bfhvai .PRIVATE_TreeView-item:focus-visible > div,.bfhvai .PRIVATE_TreeView-item.focus-visible > div{outline:2px solid HighlightText;outline-offset:-2;}}/*!sc*/
.bfhvai .PRIVATE_TreeView-item[data-has-leading-action]{--has-leading-action:1;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-container{--level:1;--toggle-width:1rem;--min-item-height:2rem;position:relative;display:grid;--leading-action-width:calc(var(--has-leading-action,0) * 1.5rem);--spacer-width:calc(calc(var(--level) - 1) * (var(--toggle-width) / 2));grid-template-columns:var(--spacer-width) var(--leading-action-width) var(--toggle-width) 1fr;grid-template-areas:'spacer leadingAction toggle content';width:100%;font-size:14px;color:var(--fgColor-default,var(--color-fg-default,#e6edf3));border-radius:6px;cursor:pointer;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-container:hover{background-color:var(--control-transparent-bgColor-hover,var(--color-action-list-item-default-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
@media (forced-colors:active){.bfhvai .PRIVATE_TreeView-item-container:hover{outline:2px solid transparent;outline-offset:-2px;}}/*!sc*/
@media (pointer:coarse){.bfhvai .PRIVATE_TreeView-item-container{--toggle-width:1.5rem;--min-item-height:2.75rem;}}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-container:has(.PRIVATE_TreeView-item-skeleton):hover{background-color:transparent;cursor:default;}/*!sc*/
@media (forced-colors:active){.bfhvai .PRIVATE_TreeView-item-container:has(.PRIVATE_TreeView-item-skeleton):hover{outline:none;}}/*!sc*/
.bfhvai[data-omit-spacer='true'] .PRIVATE_TreeView-item-container{grid-template-columns:0 0 0 1fr;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item[aria-current='true'] > .PRIVATE_TreeView-item-container{background-color:var(--control-transparent-bgColor-selected,var(--color-action-list-item-default-selected-bg,rgba(177,186,196,0.08)));}/*!sc*/
.bfhvai .PRIVATE_TreeView-item[aria-current='true'] > .PRIVATE_TreeView-item-container::after{content:'';position:absolute;top:calc(50% - 0.75rem);left:-8px;width:0.25rem;height:1.5rem;background-color:var(--fgColor-accent,var(--color-accent-fg,#2f81f7));border-radius:6px;}/*!sc*/
@media (forced-colors:active){.bfhvai .PRIVATE_TreeView-item[aria-current='true'] > .PRIVATE_TreeView-item-container::after{background-color:HighlightText;}}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-toggle{grid-area:toggle;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;padding-top:calc(var(--min-item-height) / 2 - 12px / 2);height:100%;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-toggle--hover:hover{background-color:var(--control-transparent-bgColor-hover,var(--color-tree-view-item-chevron-hover-bg,rgba(177,186,196,0.12)));}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-toggle--end{border-top-left-radius:6px;border-bottom-left-radius:6px;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-content{grid-area:content;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height:100%;padding:0 8px;gap:8px;line-height:var(--custom-line-height,var(--text-body-lineHeight-medium,1.4285));padding-top:calc((var(--min-item-height) - var(--custom-line-height,1.3rem)) / 2);padding-bottom:calc((var(--min-item-height) - var(--custom-line-height,1.3rem)) / 2);}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-content-text{-webkit-flex:1 1 auto;-ms-flex:1 1 auto;flex:1 1 auto;width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-visual{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));height:var(--custom-line-height,1.3rem);}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-leading-action{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));grid-area:leadingAction;}/*!sc*/
.bfhvai .PRIVATE_TreeView-item-level-line{width:100%;height:100%;border-right:1px solid;border-color:var(--borderColor-muted,var(--color-border-subtle,rgba(240,246,252,0.1)));}/*!sc*/
@media (hover:hover){.bfhvai .PRIVATE_TreeView-item-level-line{border-color:transparent;}.bfhvai:hover .PRIVATE_TreeView-item-level-line,.bfhvai:focus-within .PRIVATE_TreeView-item-level-line{border-color:var(--borderColor-muted,var(--color-border-subtle,rgba(240,246,252,0.1)));}}/*!sc*/
.bfhvai .PRIVATE_TreeView-directory-icon{display:grid;color:var(--treeViewItem-leadingVisual-bgColor-rest,var(--color-tree-view-item-directory-fill,#848d97));}/*!sc*/
.bfhvai .PRIVATE_VisuallyHidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;-webkit-clip:rect(0,0,0,0);clip:rect(0,0,0,0);white-space:nowrap;border-width:0;}/*!sc*/
data-styled.g28[id="TreeView__UlBox-sc-4ex6b6-0"]{content:"bfhvai,"}/*!sc*/
.fUpWeN{display:inline-block;overflow:hidden;text-overflow:ellipsis;vertical-align:top;white-space:nowrap;max-width:125px;max-width:100%;}/*!sc*/
.iQHhGT{display:inherit;overflow:hidden;text-overflow:ellipsis;vertical-align:initial;white-space:nowrap;max-width:125px;max-width:180px;display:block;}/*!sc*/
data-styled.g30[id="Truncate__StyledTruncate-sc-23o1d2-0"]{content:"fUpWeN,iQHhGT,"}/*!sc*/
.cjbBGq{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;vertical-align:middle;isolation:isolate;}/*!sc*/
.cjbBGq.cjbBGq > *{margin-inline-end:-1px;position:relative;border-radius:0;}/*!sc*/
.cjbBGq.cjbBGq > *:first-child{border-top-left-radius:6px;border-bottom-left-radius:6px;}/*!sc*/
.cjbBGq.cjbBGq > *:last-child{border-top-right-radius:6px;border-bottom-right-radius:6px;}/*!sc*/
.cjbBGq.cjbBGq > *:focus,.cjbBGq.cjbBGq > *:active,.cjbBGq.cjbBGq > *:hover{z-index:1;}/*!sc*/
data-styled.g37[id="ButtonGroup-sc-1gxhls1-0"]{content:"cjbBGq,"}/*!sc*/
.kNvrzW{--segmented-control-button-inner-padding:12px;--segmented-control-button-bg-inset:4px;--segmented-control-outer-radius:6px;background-color:transparent;border-color:transparent;border-radius:var(--segmented-control-outer-radius);border-width:0;color:currentColor;cursor:pointer;font-family:inherit;font-size:inherit;font-weight:600;padding:0;height:100%;width:100%;}/*!sc*/
.kNvrzW .segmentedControl-content{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-color:var(--controlKnob-bgColor-rest,var(--color-segmented-control-button-bg,#0d1117));border-color:var(--controlKnob-borderColor-rest,var(--color-segmented-control-button-selected-border,#6e7681));border-style:solid;border-width:1px;border-radius:var(--segmented-control-outer-radius);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height:100%;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;padding-left:var(--segmented-control-button-inner-padding);padding-right:var(--segmented-control-button-inner-padding);}/*!sc*/
.kNvrzW svg{fill:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.kNvrzW:focus:focus-visible:not(:last-child):after{width:0;}/*!sc*/
.kNvrzW .segmentedControl-text:after{content:"Code";display:block;font-weight:600;height:0;overflow:hidden;pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;visibility:hidden;}/*!sc*/
@media (pointer:coarse){.kNvrzW:before{content:"";position:absolute;left:0;right:0;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);top:50%;min-height:44px;}}/*!sc*/
.iDBPxb{--segmented-control-button-inner-padding:12px;--segmented-control-button-bg-inset:4px;--segmented-control-outer-radius:6px;background-color:transparent;border-color:transparent;border-radius:var(--segmented-control-outer-radius);border-width:0;color:currentColor;cursor:pointer;font-family:inherit;font-size:inherit;font-weight:400;padding:var(--segmented-control-button-bg-inset);height:100%;width:100%;}/*!sc*/
.iDBPxb .segmentedControl-content{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-color:transparent;border-color:transparent;border-style:solid;border-width:1px;border-radius:calc(var(--segmented-control-outer-radius) - var(--segmented-control-button-bg-inset) / 2);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height:100%;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;padding-left:calc(var(--segmented-control-button-inner-padding) - var(--segmented-control-button-bg-inset));padding-right:calc(var(--segmented-control-button-inner-padding) - var(--segmented-control-button-bg-inset));}/*!sc*/
.iDBPxb svg{fill:var(--fgColor-muted,var(--color-fg-muted,#848d97));}/*!sc*/
.iDBPxb:hover .segmentedControl-content{background-color:var(--controlTrack-bgColor-hover,var(--color-segmented-control-button-hover-bg,#30363d));}/*!sc*/
.iDBPxb:active .segmentedControl-content{background-color:var(--controlTrack-bgColor-active,var(--color-segmented-control-button-active-bg,#21262d));}/*!sc*/
.iDBPxb:focus:focus-visible:not(:last-child):after{width:0;}/*!sc*/
.iDBPxb .segmentedControl-text:after{content:"Blame";display:block;font-weight:600;height:0;overflow:hidden;pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;visibility:hidden;}/*!sc*/
@media (pointer:coarse){.iDBPxb:before{content:"";position:absolute;left:0;right:0;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);top:50%;min-height:44px;}}/*!sc*/
data-styled.g58[id="SegmentedControlButton__SegmentedControlButtonStyled-sc-8lkgxl-0"]{content:"kNvrzW,iDBPxb,"}/*!sc*/
.dlXtLG{background-color:var(--controlTrack-bgColor-rest,var(--color-segmented-control-bg,rgba(110,118,129,0.1)));border-radius:6px;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;font-size:14px;height:28px;margin:0;padding:0;}/*!sc*/
data-styled.g60[id="SegmentedControl__SegmentedControlList-sc-1rzig82-0"]{content:"dlXtLG,"}/*!sc*/
</style><meta data-hydrostats="publish"/> <!-- --> <!-- --> <!-- --> <button hidden="" data-testid="header-permalink-button" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><div><div style="--sticky-pane-height:100vh" class="Box-sc-g0xbh4-0 fSWWem"><div class="Box-sc-g0xbh4-0 kPPmzM"><div class="Box-sc-g0xbh4-0 cIAPDV"><div tabindex="0" class="Box-sc-g0xbh4-0 gvCnwW"><div class="Box-sc-g0xbh4-0 heUiss"><div class="Box-sc-g0xbh4-0 eUyHuk"></div><div style="--pane-width:320px" class="Box-sc-g0xbh4-0 gNdDUH"><div class="Box-sc-g0xbh4-0 react-tree-pane-contents-3-panel"><div id="repos-file-tree" class="Box-sc-g0xbh4-0 jywUSN"><div class="Box-sc-g0xbh4-0 hBSSUC"><div class="Box-sc-g0xbh4-0 iPurHz"><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 jUriTl"><button style="--button-color:fg.muted" type="button" aria-label="Expand file tree" data-testid="expand-file-tree-button-mobile" class="types__StyledButton-sc-ws60qy-0 iKABXH"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="leadingVisual" class="Box-sc-g0xbh4-0 trpoQ"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-arrow-left" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M7.78 12.53a.75.75 0 0 1-1.06 0L2.47 8.28a.75.75 0 0 1 0-1.06l4.25-4.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L4.81 7h7.44a.75.75 0 0 1 0 1.5H4.81l2.97 2.97a.75.75 0 0 1 0 1.06Z"></path></svg></span><span data-component="text">Files</span></span></button><span role="tooltip" aria-label="Collapse file tree" id="expand-button-file-tree-button" class="Tooltip__TooltipBase-sc-17tf59c-0 izAlVj tooltipped-se"><button data-component="IconButton" type="button" data-testid="collapse-file-tree-button" aria-labelledby="expand-button-file-tree-button" aria-expanded="true" aria-controls="repos-file-tree" class="types__StyledButton-sc-ws60qy-0 hfWObv" data-no-visuals="true"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-sidebar-expand" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="m4.177 7.823 2.396-2.396A.25.25 0 0 1 7 5.604v4.792a.25.25 0 0 1-.427.177L4.177 8.177a.25.25 0 0 1 0-.354Z"></path><path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25H9.5v-13Zm12.5 13a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25H11v13Z"></path></svg></button></span><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button></h2><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 imcwCi">Files</h2></div><div class="Box-sc-g0xbh4-0 hVHHYa"><div class="Box-sc-g0xbh4-0 idZfsJ"><button type="button" id="branch-picker-repos-header-ref-selector" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-label="dev branch" data-testid="anchor-button" class="types__StyledButton-sc-ws60qy-0 gBsjGI react-repos-tree-pane-ref-selector width-full ref-selector-class"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="text"><div class="Box-sc-g0xbh4-0 bKgizp"><div class="Box-sc-g0xbh4-0 dIAShY"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-git-branch" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M9.5 3.25a2.25 2.25 0 1 1 3 2.122V6A2.5 2.5 0 0 1 10 8.5H6a1 1 0 0 0-1 1v1.128a2.251 2.251 0 1 1-1.5 0V5.372a2.25 2.25 0 1 1 1.5 0v1.836A2.493 2.493 0 0 1 6 7h4a1 1 0 0 0 1-1v-.628A2.25 2.25 0 0 1 9.5 3.25Zm-6 0a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Zm8.25-.75a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5ZM4.25 12a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Z"></path></svg></div><div class="Box-sc-g0xbh4-0 caeYDk ref-selector-button-text-container"><span class="Text-sc-17v1xeu-0 bOMzPg"> <!-- -->dev</span></div></div></span><span data-component="trailingVisual" class="Box-sc-g0xbh4-0 trpoQ"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-triangle-down" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path></svg></span></span></button><button hidden="" data-hotkey-scope="read-only-cursor-text-area"></button></div><div class="Box-sc-g0xbh4-0 jahcnb"><span role="tooltip" aria-label="Add file" id=":Rq6mplaeb:" class="Tooltip__TooltipBase-sc-17tf59c-0 izAlVj tooltipped-s"><a sx="[object Object]" data-component="IconButton" type="button" aria-label="Add file" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 XJZbf" href="/esphome/esphome/new/dev/esphome/components/dallas_temp"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-plus" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M7.75 2a.75.75 0 0 1 .75.75V7h4.25a.75.75 0 0 1 0 1.5H8.5v4.25a.75.75 0 0 1-1.5 0V8.5H2.75a.75.75 0 0 1 0-1.5H7V2.75A.75.75 0 0 1 7.75 2Z"></path></svg></a></span><button data-component="IconButton" type="button" aria-label="Search this repository" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 cBjhIZ"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-search" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path></svg></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button></div></div></div><div class="Box-sc-g0xbh4-0 ccToMy"><span class="TextInputWrapper__TextInputBaseWrapper-sc-1mqhpbi-0 TextInputWrapper-sc-1mqhpbi-1 kbCZWh jxgrJS TextInput-wrapper" aria-busy="false"><span class="TextInput-icon"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-search" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path></svg></span><input type="text" aria-label="Go to file" role="combobox" aria-controls="file-results-list" aria-expanded="false" aria-haspopup="dialog" autoCorrect="off" spellcheck="false" placeholder="Go to file" data-component="input" class="UnstyledTextInput-sc-14ypya-0 cDLBls" value=""/><span class="TextInput-icon"><div class="Box-sc-g0xbh4-0 cNvKlH"><kbd>t</kbd></div></span></span></div><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><div class="Box-sc-g0xbh4-0 cLfAnm"><div class="react-tree-show-tree-items"><div data-testid="repos-file-tree-container" class="Box-sc-g0xbh4-0 erWCJP"><div class="Box-sc-g0xbh4-0 fUswPC"><svg height="32px" width="32px" viewBox="0 0 16 16" fill="none" aria-label="Loading file tree" class="Spinner__StyledSpinner-sc-1knt686-0 hPEVNM"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke"></circle><path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path></svg></div></div></div></div></div></div></div><div class="Box-sc-g0xbh4-0 hAeDYA"><div role="slider" aria-label="Draggable pane splitter" aria-valuemin="0" aria-valuemax="0" aria-valuenow="0" aria-valuetext="Pane width 0 pixels" tabindex="0" class="Box-sc-g0xbh4-0 gZHqlw"></div></div></div></div><div class="Box-sc-g0xbh4-0 emFMJu"><div class="Box-sc-g0xbh4-0"></div><div class="Box-sc-g0xbh4-0 hlUAHL"><div data-selector="repos-split-pane-content" tabindex="0" class="Box-sc-g0xbh4-0 iStsmI"><div class="Box-sc-g0xbh4-0 eIgvIk"><div class="Box-sc-g0xbh4-0 eVFfWF container"><div class="px-3 pt-3 pb-0" id="StickyHeader"><div class="Box-sc-g0xbh4-0 fywjmm"><div class="Box-sc-g0xbh4-0 dyczTK"><div class="Box-sc-g0xbh4-0 kszRgZ"><div class="Box-sc-g0xbh4-0 eTvGbF"><nav data-testid="breadcrumbs" aria-labelledby="repos-header-breadcrumb--wide-heading" id="repos-header-breadcrumb--wide" class="Box-sc-g0xbh4-0 kzRgrI"><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 cgQnMS sr-only" data-testid="screen-reader-heading" id="repos-header-breadcrumb--wide-heading">Breadcrumbs</h2><ol class="Box-sc-g0xbh4-0 cmAPIB"><li class="Box-sc-g0xbh4-0 jwXCBK"><a sx="[object Object]" data-testid="breadcrumbs-repo-link" class="Link__StyledLink-sc-14289xe-0 dpowyu" href="/esphome/esphome/tree/dev">esphome</a></li><li class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 ePvrxx">/</span><a sx="[object Object]" class="Link__StyledLink-sc-14289xe-0 csCkZA" href="/esphome/esphome/tree/dev/esphome">esphome</a></li><li class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 ePvrxx">/</span><a sx="[object Object]" class="Link__StyledLink-sc-14289xe-0 csCkZA" href="/esphome/esphome/tree/dev/esphome/components">components</a></li><li class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 ePvrxx">/</span><a sx="[object Object]" class="Link__StyledLink-sc-14289xe-0 csCkZA" href="/esphome/esphome/tree/dev/esphome/components/dallas_temp">dallas_temp</a></li></ol></nav><div data-testid="breadcrumbs-filename" class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 ePvrxx">/</span><h1 tabindex="-1" id="file-name-id-wide" class="Heading__StyledHeading-sc-1c1dgg0-0 diwsLq">dallas_temp.cpp</h1></div><div aria-describedby=":Rdd9laeb:"><button data-component="IconButton" type="button" aria-label="Copy path" tabindex="0" class="types__StyledButton-sc-ws60qy-0 hWITRv" data-size="small" data-no-visuals="true"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-copy" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path></svg></button></div></div></div><div class="react-code-view-header-element--wide"><div class="Box-sc-g0xbh4-0 gtBUEp"><div class="d-flex gap-2"> <button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button type="button" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 fXsbsD"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="text">Blame</span></span></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button data-component="IconButton" type="button" aria-label="More file actions" class="types__StyledButton-sc-ws60qy-0 hiXxwe js-blob-dropdown-click" title="More file actions" data-testid="more-file-actions-button-nav-menu-wide" id=":R156d9laeb:" aria-haspopup="true" aria-expanded="false" tabindex="0" data-no-visuals="true"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-kebab-horizontal" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path></svg></button> </div></div></div><div class="react-code-view-header-element--narrow"><div class="Box-sc-g0xbh4-0 gtBUEp"><div class="d-flex gap-2"> <button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button type="button" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 fXsbsD"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="text">Blame</span></span></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button data-component="IconButton" type="button" aria-label="More file actions" class="types__StyledButton-sc-ws60qy-0 hiXxwe js-blob-dropdown-click" title="More file actions" data-testid="more-file-actions-button-nav-menu-narrow" id=":R157d9laeb:" aria-haspopup="true" aria-expanded="false" tabindex="0" data-no-visuals="true"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-kebab-horizontal" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path></svg></button> </div></div></div></div></div></div></div></div><div class="Box-sc-g0xbh4-0 hVZtwF react-code-view-bottom-padding"> <div class="Box-sc-g0xbh4-0 cMYnca"></div> <!-- --> <!-- --> </div><div class="Box-sc-g0xbh4-0 hVZtwF"> <!-- --> <!-- --> <button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><div class="d-flex flex-column border rounded-2 mb-3 pl-1"><div class="Box-sc-g0xbh4-0 brJRqk"><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 cgQnMS sr-only" data-testid="screen-reader-heading">Latest commit</h2><div style="width:120px" class="Skeleton Skeleton--text" data-testid="loading"> </div><div class="d-flex flex-shrink-0 gap-2"><div data-testid="latest-commit-details" class="d-none d-sm-flex flex-items-center"></div><div class="d-flex gap-2"><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 cgQnMS sr-only" data-testid="screen-reader-heading">History</h2><a aria-label="Commit history" class="types__StyledButton-sc-ws60qy-0 hWITRv d-none d-lg-flex LinkButton-module__code-view-link-button--xvCGA flex-items-center fgColor-default" href="/esphome/esphome/commits/dev/esphome/components/dallas_temp/dallas_temp.cpp" data-size="small"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="leadingVisual" class="Box-sc-g0xbh4-0 trpoQ"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-history" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path></svg></span><span data-component="text"><span class="Text-sc-17v1xeu-0 gPDEWA fgColor-default">History</span></span></span></a><div class="d-sm-none"></div><div class="d-flex d-lg-none"><span role="tooltip" aria-label="History" id="history-icon-button-tooltip" class="Tooltip__TooltipBase-sc-17tf59c-0 izAlVj tooltipped-n"><a aria-label="Commit history" aria-describedby="history-icon-button-tooltip" class="types__StyledButton-sc-ws60qy-0 hWITRv LinkButton-module__code-view-link-button--xvCGA flex-items-center fgColor-default" href="/esphome/esphome/commits/dev/esphome/components/dallas_temp/dallas_temp.cpp" data-size="small"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="leadingVisual" class="Box-sc-g0xbh4-0 trpoQ"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-history" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path></svg></span></span></a></span></div></div></div></div></div><div class="Box-sc-g0xbh4-0 iJmJly"><div class="Box-sc-g0xbh4-0 kjydbF container"><div class="Box-sc-g0xbh4-0 gIJuDf react-code-size-details-banner"><div class="Box-sc-g0xbh4-0 fleZSW react-code-size-details-banner"><div class="Box-sc-g0xbh4-0 dVVHlo text-mono"><div title="4.59 KB" data-testid="blob-size" class="Truncate__StyledTruncate-sc-23o1d2-0 fUpWeN"><span class="Text-sc-17v1xeu-0 gPDEWA">172 lines (149 loc) · 4.59 KB</span></div></div></div></div><div class="Box-sc-g0xbh4-0 VHzRk react-blob-view-header-sticky" id="repos-sticky-header"><div class="Box-sc-g0xbh4-0 ePiodO"><div class="Box-sc-g0xbh4-0 react-blob-sticky-header"><div class="Box-sc-g0xbh4-0 kQJlnf"><div class="Box-sc-g0xbh4-0 gJICKO"><div class="Box-sc-g0xbh4-0 iZJewz"><nav data-testid="breadcrumbs" aria-labelledby="sticky-breadcrumb-heading" id="sticky-breadcrumb" class="Box-sc-g0xbh4-0 kzRgrI"><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 cgQnMS sr-only" data-testid="screen-reader-heading" id="sticky-breadcrumb-heading">Breadcrumbs</h2><ol class="Box-sc-g0xbh4-0 cmAPIB"><li class="Box-sc-g0xbh4-0 jwXCBK"><a sx="[object Object]" data-testid="breadcrumbs-repo-link" class="Link__StyledLink-sc-14289xe-0 dpowyu" href="/esphome/esphome/tree/dev">esphome</a></li><li class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 fQxKLn">/</span><a sx="[object Object]" class="Link__StyledLink-sc-14289xe-0 csCkZA" href="/esphome/esphome/tree/dev/esphome">esphome</a></li><li class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 fQxKLn">/</span><a sx="[object Object]" class="Link__StyledLink-sc-14289xe-0 csCkZA" href="/esphome/esphome/tree/dev/esphome/components">components</a></li><li class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 fQxKLn">/</span><a sx="[object Object]" class="Link__StyledLink-sc-14289xe-0 csCkZA" href="/esphome/esphome/tree/dev/esphome/components/dallas_temp">dallas_temp</a></li></ol></nav><div data-testid="breadcrumbs-filename" class="Box-sc-g0xbh4-0 jwXCBK"><span aria-hidden="true" class="Text-sc-17v1xeu-0 fQxKLn">/</span><h1 tabindex="-1" id="sticky-file-name-id" class="Heading__StyledHeading-sc-1c1dgg0-0 jAEDJk">dallas_temp.cpp</h1></div></div><button style="--button-color:fg.default" type="button" data-size="small" class="types__StyledButton-sc-ws60qy-0 ecGgfP"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="leadingVisual" class="Box-sc-g0xbh4-0 trpoQ"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-arrow-up" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M3.47 7.78a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0l4.25 4.25a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018L9 4.81v7.44a.75.75 0 0 1-1.5 0V4.81L4.53 7.78a.75.75 0 0 1-1.06 0Z"></path></svg></span><span data-component="text">Top</span></span></button></div></div></div><div class="Box-sc-g0xbh4-0 jtQniD"><h2 class="Heading__StyledHeading-sc-1c1dgg0-0 cgQnMS sr-only" data-testid="screen-reader-heading">File metadata and controls</h2><div class="Box-sc-g0xbh4-0 bfkNRF"><ul aria-label="File view" class="SegmentedControl__SegmentedControlList-sc-1rzig82-0 dlXtLG"><li class="Box-sc-g0xbh4-0 fXBLEV"><button aria-current="true" type="button" class="SegmentedControlButton__SegmentedControlButtonStyled-sc-8lkgxl-0 kNvrzW"><span class="segmentedControl-content"><div class="Box-sc-g0xbh4-0 segmentedControl-text">Code</div></span></button></li><li class="Box-sc-g0xbh4-0 illvPQ"><button aria-current="false" type="button" class="SegmentedControlButton__SegmentedControlButtonStyled-sc-8lkgxl-0 iDBPxb"><span class="segmentedControl-content"><div class="Box-sc-g0xbh4-0 segmentedControl-text">Blame</div></span></button></li></ul><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><div class="Box-sc-g0xbh4-0 fleZSW react-code-size-details-in-header"><div class="Box-sc-g0xbh4-0 dVVHlo text-mono"><div title="4.59 KB" data-testid="blob-size" class="Truncate__StyledTruncate-sc-23o1d2-0 fUpWeN"><span class="Text-sc-17v1xeu-0 gPDEWA">172 lines (149 loc) · 4.59 KB</span></div></div></div></div><div class="Box-sc-g0xbh4-0 iBylDf"><div class="Box-sc-g0xbh4-0 kSGBPx react-blob-header-edit-and-raw-actions"><div class="ButtonGroup-sc-1gxhls1-0 cjbBGq"><a href="https://github.com/esphome/esphome/raw/dev/esphome/components/dallas_temp/dallas_temp.cpp" data-testid="raw-button" data-size="small" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 dupbIv"><span data-component="buttonContent" class="Box-sc-g0xbh4-0 kkrdEu"><span data-component="text">Raw</span></span></a><button data-component="IconButton" type="button" aria-label="Copy raw content" data-testid="copy-raw-button" data-size="small" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 dMUxwi"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-copy" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path></svg></button><span role="tooltip" aria-label="Download raw file" id=":Rdcsptal9laeb:" class="Tooltip__TooltipBase-sc-17tf59c-0 izAlVj tooltipped-n"><button data-component="IconButton" type="button" aria-label="Download raw content" data-testid="download-raw-button" data-size="small" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 fCIOmi"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-download" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M2.75 14A1.75 1.75 0 0 1 1 12.25v-2.5a.75.75 0 0 1 1.5 0v2.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-2.5a.75.75 0 0 1 1.5 0v2.5A1.75 1.75 0 0 1 13.25 14Z"></path><path d="M7.25 7.689V2a.75.75 0 0 1 1.5 0v5.689l1.97-1.969a.749.749 0 1 1 1.06 1.06l-3.25 3.25a.749.749 0 0 1-1.06 0L4.22 6.78a.749.749 0 1 1 1.06-1.06l1.97 1.969Z"></path></svg></button></span></div><button hidden="" data-testid="raw-button-shortcut" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden="" data-testid="copy-raw-button-shortcut" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden="" data-testid="download-raw-button-shortcut" data-hotkey-scope="read-only-cursor-text-area"></button><a class="Link__StyledLink-sc-14289xe-0 elltiT js-github-dev-shortcut d-none" href="https://github.dev/"></a><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><a class="Link__StyledLink-sc-14289xe-0 elltiT js-github-dev-new-tab-shortcut d-none" href="https://github.dev/" target="_blank"></a><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><div class="ButtonGroup-sc-1gxhls1-0 cjbBGq"><span role="tooltip" aria-label="Fork this repository and edit the file" id=":R6ksptal9laeb:" class="Tooltip__TooltipBase-sc-17tf59c-0 izAlVj tooltipped-nw"><a sx="[object Object]" data-component="IconButton" type="button" aria-label="Edit file" data-testid="edit-button" data-size="small" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 ksnFc" href="/esphome/esphome/edit/dev/esphome/components/dallas_temp/dallas_temp.cpp"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-pencil" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"></path></svg></a></span><button data-component="IconButton" type="button" aria-label="More edit options" data-testid="more-edit-button" id=":Raksptal9laeb:" aria-haspopup="true" aria-expanded="false" tabindex="0" data-size="small" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 dMUxwi"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-triangle-down" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path></svg></button></div><button hidden="" data-testid="" data-hotkey="e,Shift+E" data-hotkey-scope="read-only-cursor-text-area"></button></div><span role="tooltip" aria-label="Close symbols panel" id=":R5sptal9laeb:" class="Tooltip__TooltipBase-sc-17tf59c-0 izAlVj tooltipped-nw"><button data-component="IconButton" type="button" aria-label="Symbols" aria-pressed="true" aria-expanded="true" aria-controls="symbols-pane" class="types__StyledButton-sc-ws60qy-0 jgnIDP" data-testid="symbols-button" id="symbols-button" data-size="small" data-no-visuals="true"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-code-square" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25Zm7.47 3.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L10.69 8 9.22 6.53a.75.75 0 0 1 0-1.06ZM6.78 6.53 5.31 8l1.47 1.47a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path></svg></button></span><div class="Box-sc-g0xbh4-0 react-blob-header-edit-and-raw-actions-combined"><button data-component="IconButton" type="button" aria-label="Edit and raw actions" class="types__StyledButton-sc-ws60qy-0 htXhGX js-blob-dropdown-click" title="More file actions" data-testid="more-file-actions-button" id=":Rnsptal9laeb:" aria-haspopup="true" aria-expanded="false" tabindex="0" data-size="small" data-no-visuals="true"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-kebab-horizontal" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path></svg></button></div></div></div></div><div></div></div><div class="Box-sc-g0xbh4-0 jMJFjm"><section aria-labelledby="file-name-id-wide file-name-id-mobile" class="Box-sc-g0xbh4-0 jWnGGx"><div class="Box-sc-g0xbh4-0 TCenl"><div id="highlighted-line-menu-positioner" class="position-relative"><div id="copilot-button-positioner" class="Box-sc-g0xbh4-0 cluMzC"><div class="Box-sc-g0xbh4-0 eRkHwF"><div class="Box-sc-g0xbh4-0 kfwkrr react-code-file-contents" role="presentation" aria-hidden="true" data-tab-size="2" data-paste-markdown-skip="true" data-hpc="true"><div class="react-line-numbers-no-virtualization" style="pointer-events:auto;position:relative;z-index:2"><div class="react-no-virtualization-wrapper-lines"><div data-line-number="1" class="react-line-number react-code-text" style="padding-right:16px">1</div><div data-line-number="2" class="react-line-number react-code-text" style="padding-right:16px">2</div><div data-line-number="3" class="react-line-number react-code-text" style="padding-right:16px">3</div><div data-line-number="4" class="react-line-number react-code-text" style="padding-right:16px">4</div><div data-line-number="5" class="react-line-number react-code-text" style="padding-right:16px">5</div><div data-line-number="6" class="react-line-number react-code-text" style="padding-right:16px">6</div><div data-line-number="7" class="react-line-number react-code-text" style="padding-right:16px">7</div><div data-line-number="8" class="react-line-number react-code-text" style="padding-right:16px">8</div><div data-line-number="9" class="react-line-number react-code-text" style="padding-right:16px">9</div><div data-line-number="10" class="react-line-number react-code-text" style="padding-right:16px">10</div><div data-line-number="11" class="react-line-number react-code-text" style="padding-right:16px">11</div><div data-line-number="12" class="react-line-number react-code-text" style="padding-right:16px">12</div><div data-line-number="13" class="react-line-number react-code-text" style="padding-right:16px">13</div><div data-line-number="14" class="react-line-number react-code-text" style="padding-right:16px">14</div><div data-line-number="15" class="react-line-number react-code-text" style="padding-right:16px">15<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="16" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">16</div><div data-line-number="17" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">17</div><div data-line-number="18" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">18</div><div data-line-number="19" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">19</div><div data-line-number="20" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">20</div><div data-line-number="21" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">21</div><div data-line-number="22" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">22</div><div data-line-number="23" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">23</div><div data-line-number="24" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">24</div><div data-line-number="25" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">25</div><div data-line-number="26" class="react-line-number react-code-text" style="padding-right:16px">26</div><div data-line-number="27" class="react-line-number react-code-text" style="padding-right:16px">27</div><div data-line-number="28" class="react-line-number react-code-text" style="padding-right:16px">28<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="29" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">29</div><div data-line-number="30" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">30</div><div data-line-number="31" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">31</div><div data-line-number="32" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">32</div><div data-line-number="33" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">33</div><div data-line-number="34" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">34</div><div data-line-number="35" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">35</div><div data-line-number="36" class="child-of-line-27  react-line-number react-code-text" style="padding-right:16px">36</div><div data-line-number="37" class="react-line-number react-code-text" style="padding-right:16px">37</div><div data-line-number="38" class="react-line-number react-code-text" style="padding-right:16px">38</div><div data-line-number="39" class="react-line-number react-code-text" style="padding-right:16px">39<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="40" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">40</div><div data-line-number="41" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">41</div><div data-line-number="42" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">42</div><div data-line-number="43" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">43</div><div data-line-number="44" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">44</div><div data-line-number="45" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">45</div><div data-line-number="46" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">46</div><div data-line-number="47" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">47</div><div data-line-number="48" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">48</div><div data-line-number="49" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">49</div><div data-line-number="50" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">50</div><div data-line-number="51" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">51</div><div data-line-number="52" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">52</div><div data-line-number="53" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">53</div><div data-line-number="54" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">54</div><div data-line-number="55" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">55</div><div data-line-number="56" class="child-of-line-38  react-line-number react-code-text" style="padding-right:16px">56</div><div data-line-number="57" class="react-line-number react-code-text" style="padding-right:16px">57</div><div data-line-number="58" class="react-line-number react-code-text" style="padding-right:16px">58</div><div data-line-number="59" class="react-line-number react-code-text" style="padding-right:16px">59<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="60" class="child-of-line-58  react-line-number react-code-text" style="padding-right:16px">60</div></div><div class="react-no-virtualization-wrapper-lines"><div data-line-number="61" class="child-of-line-58  react-line-number react-code-text" style="padding-right:16px">61</div><div data-line-number="62" class="child-of-line-58  react-line-number react-code-text" style="padding-right:16px">62</div><div data-line-number="63" class="react-line-number react-code-text" style="padding-right:16px">63</div><div data-line-number="64" class="react-line-number react-code-text" style="padding-right:16px">64</div><div data-line-number="65" class="react-line-number react-code-text" style="padding-right:16px">65<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="66" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">66</div><div data-line-number="67" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">67</div><div data-line-number="68" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">68</div><div data-line-number="69" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">69</div><div data-line-number="70" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">70</div><div data-line-number="71" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">71</div><div data-line-number="72" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">72</div><div data-line-number="73" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">73</div><div data-line-number="74" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">74</div><div data-line-number="75" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">75</div><div data-line-number="76" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">76</div><div data-line-number="77" class="child-of-line-64  react-line-number react-code-text" style="padding-right:16px">77</div><div data-line-number="78" class="react-line-number react-code-text" style="padding-right:16px">78</div><div data-line-number="79" class="react-line-number react-code-text" style="padding-right:16px">79</div><div data-line-number="80" class="react-line-number react-code-text" style="padding-right:16px">80<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="81" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">81</div><div data-line-number="82" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">82</div><div data-line-number="83" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">83</div><div data-line-number="84" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">84</div><div data-line-number="85" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">85</div><div data-line-number="86" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">86</div><div data-line-number="87" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">87</div><div data-line-number="88" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">88</div><div data-line-number="89" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">89</div><div data-line-number="90" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">90</div><div data-line-number="91" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">91</div><div data-line-number="92" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">92</div><div data-line-number="93" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">93</div><div data-line-number="94" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">94</div><div data-line-number="95" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">95</div><div data-line-number="96" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">96</div><div data-line-number="97" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">97</div><div data-line-number="98" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">98</div><div data-line-number="99" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">99</div><div data-line-number="100" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">100</div><div data-line-number="101" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">101</div><div data-line-number="102" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">102</div><div data-line-number="103" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">103</div><div data-line-number="104" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">104</div><div data-line-number="105" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">105</div><div data-line-number="106" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">106</div><div data-line-number="107" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">107</div><div data-line-number="108" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">108</div><div data-line-number="109" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">109</div><div data-line-number="110" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">110</div><div data-line-number="111" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">111</div><div data-line-number="112" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">112</div><div data-line-number="113" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">113</div><div data-line-number="114" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">114</div><div data-line-number="115" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">115</div><div data-line-number="116" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">116</div><div data-line-number="117" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">117</div><div data-line-number="118" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">118</div><div data-line-number="119" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">119</div><div data-line-number="120" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">120</div></div><div class="react-no-virtualization-wrapper-lines"><div data-line-number="121" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">121</div><div data-line-number="122" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">122</div><div data-line-number="123" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">123</div><div data-line-number="124" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">124</div><div data-line-number="125" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">125</div><div data-line-number="126" class="child-of-line-79  react-line-number react-code-text" style="padding-right:16px">126</div><div data-line-number="127" class="react-line-number react-code-text" style="padding-right:16px">127</div><div data-line-number="128" class="react-line-number react-code-text" style="padding-right:16px">128</div><div data-line-number="129" class="react-line-number react-code-text" style="padding-right:16px">129<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="130" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">130</div><div data-line-number="131" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">131</div><div data-line-number="132" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">132</div><div data-line-number="133" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">133</div><div data-line-number="134" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">134</div><div data-line-number="135" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">135</div><div data-line-number="136" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">136</div><div data-line-number="137" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">137</div><div data-line-number="138" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">138</div><div data-line-number="139" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">139</div><div data-line-number="140" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">140</div><div data-line-number="141" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">141</div><div data-line-number="142" class="child-of-line-128  react-line-number react-code-text" style="padding-right:16px">142</div><div data-line-number="143" class="react-line-number react-code-text" style="padding-right:16px">143</div><div data-line-number="144" class="react-line-number react-code-text" style="padding-right:16px">144</div><div data-line-number="145" class="react-line-number react-code-text" style="padding-right:16px">145<span class="Box-sc-g0xbh4-0 hXUKEK"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 cXzIIR"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="146" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">146</div><div data-line-number="147" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">147</div><div data-line-number="148" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">148</div><div data-line-number="149" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">149</div><div data-line-number="150" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">150</div><div data-line-number="151" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">151</div><div data-line-number="152" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">152</div><div data-line-number="153" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">153</div><div data-line-number="154" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">154</div><div data-line-number="155" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">155</div><div data-line-number="156" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">156</div><div data-line-number="157" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">157</div><div data-line-number="158" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">158</div><div data-line-number="159" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">159</div><div data-line-number="160" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">160</div><div data-line-number="161" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">161</div><div data-line-number="162" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">162</div><div data-line-number="163" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">163</div><div data-line-number="164" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">164</div><div data-line-number="165" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">165</div><div data-line-number="166" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">166</div><div data-line-number="167" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">167</div><div data-line-number="168" class="child-of-line-144  react-line-number react-code-text" style="padding-right:16px">168</div><div data-line-number="169" class="react-line-number react-code-text" style="padding-right:16px">169</div><div data-line-number="170" class="react-line-number react-code-text" style="padding-right:16px">170</div><div data-line-number="171" class="react-line-number react-code-text" style="padding-right:16px">171</div><div data-line-number="172" class="react-line-number react-code-text" style="padding-right:16px">172</div></div></div><div class="react-code-lines react-code-lines-no-virtualization"><div><div id="LC1" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&quot;</span>dallas_temp.h<span class="pl-pds">&quot;</span></span></div>
<div id="LC2" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&quot;</span>esphome/core/log.h<span class="pl-pds">&quot;</span></span></div>
<div id="LC3" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC4" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">namespace</span> <span class="pl-en">esphome</span> {</div>
<div id="LC5" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">namespace</span> <span class="pl-en">dallas_temp</span> {</div>
<div id="LC6" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC7" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">char</span> *<span class="pl-k">const</span> TAG = <span class="pl-s"><span class="pl-pds">&quot;</span>dallas.temp.sensor<span class="pl-pds">&quot;</span></span>;</div>
<div id="LC8" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC9" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-c1">uint8_t</span> DALLAS_MODEL_DS18S20 = <span class="pl-c1">0x10</span>;</div>
<div id="LC10" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-c1">uint8_t</span> DALLAS_COMMAND_START_CONVERSION = <span class="pl-c1">0x44</span>;</div>
<div id="LC11" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-c1">uint8_t</span> DALLAS_COMMAND_READ_SCRATCH_PAD = <span class="pl-c1">0xBE</span>;</div>
<div id="LC12" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-c1">uint8_t</span> DALLAS_COMMAND_WRITE_SCRATCH_PAD = <span class="pl-c1">0x4E</span>;</div>
<div id="LC13" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-c1">uint8_t</span> DALLAS_COMMAND_COPY_SCRATCH_PAD = <span class="pl-c1">0x48</span>;</div>
<div id="LC14" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC15" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-c1">uint16_t</span> <span class="pl-en">DallasTemperatureSensor::millis_to_wait_for_conversion_</span>() <span class="pl-k">const</span> {</div>
<div id="LC16" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">  <span class="pl-k">switch</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">resolution_</span>) {</div>
<div id="LC17" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class="pl-k">case</span> <span class="pl-c1">9</span>:</div>
<div id="LC18" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">      <span class="pl-k">return</span> <span class="pl-c1">94</span>;</div>
<div id="LC19" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class="pl-k">case</span> <span class="pl-c1">10</span>:</div>
<div id="LC20" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">      <span class="pl-k">return</span> <span class="pl-c1">188</span>;</div>
<div id="LC21" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class="pl-k">case</span> <span class="pl-c1">11</span>:</div>
<div id="LC22" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">      <span class="pl-k">return</span> <span class="pl-c1">375</span>;</div>
<div id="LC23" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class="pl-k">default</span>:</div>
<div id="LC24" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">      <span class="pl-k">return</span> <span class="pl-c1">750</span>;</div>
<div id="LC25" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">  }</div>
<div id="LC26" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC27" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC28" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">void</span> <span class="pl-en">DallasTemperatureSensor::dump_config</span>() {</div>
<div id="LC29" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">  <span class="pl-c1">ESP_LOGCONFIG</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>Dallas Temperature Sensor:<span class="pl-pds">&quot;</span></span>);</div>
<div id="LC30" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">  <span class="pl-k">if</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">address_</span> == <span class="pl-c1">0</span>) {</div>
<div id="LC31" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">    <span class="pl-c1">ESP_LOGW</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>  Unable to select an address<span class="pl-pds">&quot;</span></span>);</div>
<div id="LC32" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">    <span class="pl-k">return</span>;</div>
<div id="LC33" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">  }</div>
<div id="LC34" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">  <span class="pl-c1">LOG_ONE_WIRE_DEVICE</span>(<span class="pl-c1">this</span>);</div>
<div id="LC35" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">  <span class="pl-c1">ESP_LOGCONFIG</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>  Resolution: %u bits<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">this</span>-&gt;<span class="pl-smi">resolution_</span>);</div>
<div id="LC36" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-27 ">  <span class="pl-c1">LOG_UPDATE_INTERVAL</span>(<span class="pl-c1">this</span>);</div>
<div id="LC37" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC38" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC39" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">void</span> <span class="pl-en">DallasTemperatureSensor::update</span>() {</div>
<div id="LC40" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">  <span class="pl-k">if</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">address_</span> == <span class="pl-c1">0</span>)</div>
<div id="LC41" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">    <span class="pl-k">return</span>;</div>
<div id="LC42" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">
</div>
<div id="LC43" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">  <span class="pl-c1">this</span>-&gt;<span class="pl-c1">status_clear_warning</span>();</div>
<div id="LC44" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">
</div>
<div id="LC45" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">  <span class="pl-c1">this</span>-&gt;<span class="pl-c1">send_command_</span>(DALLAS_COMMAND_START_CONVERSION);</div>
<div id="LC46" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">
</div>
<div id="LC47" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">  <span class="pl-c1">this</span>-&gt;<span class="pl-c1">set_timeout</span>(<span class="pl-c1">this</span>-&gt;<span class="pl-c1">get_address_name</span>(), <span class="pl-c1">this</span>-&gt;<span class="pl-c1">millis_to_wait_for_conversion_</span>(), [<span class="pl-c1">this</span>] {</div>
<div id="LC48" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">    <span class="pl-k">if</span> (!<span class="pl-c1">this</span>-&gt;<span class="pl-c1">read_scratch_pad_</span>() || !<span class="pl-c1">this</span>-&gt;<span class="pl-c1">check_scratch_pad_</span>()) {</div>
<div id="LC49" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">      <span class="pl-c1">this</span>-&gt;<span class="pl-c1">publish_state</span>(NAN);</div>
<div id="LC50" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">      <span class="pl-k">return</span>;</div>
<div id="LC51" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">    }</div>
<div id="LC52" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">
</div>
<div id="LC53" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">    <span class="pl-k">float</span> tempc = <span class="pl-c1">this</span>-&gt;<span class="pl-c1">get_temp_c_</span>();</div>
<div id="LC54" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">    <span class="pl-c1">ESP_LOGD</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>&#39;%s&#39;: Got Temperature=%.1f°C<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">this</span>-&gt;<span class="pl-c1">get_name</span>().<span class="pl-c1">c_str</span>(), tempc);</div>
<div id="LC55" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">    <span class="pl-c1">this</span>-&gt;<span class="pl-c1">publish_state</span>(tempc);</div>
<div id="LC56" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-38 ">  });</div>
<div id="LC57" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC58" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC59" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">void</span> IRAM_ATTR <span class="pl-en">DallasTemperatureSensor::read_scratch_pad_int_</span>() {</div>
<div id="LC60" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-58 ">  <span class="pl-k">for</span> (<span class="pl-c1">uint8_t</span> &amp;i : <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>) {</div>
<div id="LC61" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-58 ">    i = <span class="pl-c1">this</span>-&gt;<span class="pl-smi">bus_</span>-&gt;<span class="pl-c1">read8</span>();</div>
<div id="LC62" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-58 ">  }</div>
<div id="LC63" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC64" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC65" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">bool</span> <span class="pl-en">DallasTemperatureSensor::read_scratch_pad_</span>() {</div>
<div id="LC66" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">  <span class="pl-k">bool</span> success;</div>
<div id="LC67" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">  {</div>
<div id="LC68" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">    InterruptLock lock;</div>
<div id="LC69" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">    success = <span class="pl-c1">this</span>-&gt;<span class="pl-c1">send_command_</span>(DALLAS_COMMAND_READ_SCRATCH_PAD);</div>
<div id="LC70" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">    <span class="pl-k">if</span> (success)</div>
<div id="LC71" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">      <span class="pl-c1">this</span>-&gt;<span class="pl-c1">read_scratch_pad_int_</span>();</div>
<div id="LC72" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">  }</div>
<div id="LC73" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">  <span class="pl-k">if</span> (!success) {</div>
<div id="LC74" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">    <span class="pl-c1">ESP_LOGW</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>&#39;%s&#39; - reading scratch pad failed bus reset<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">this</span>-&gt;<span class="pl-c1">get_name</span>().<span class="pl-c1">c_str</span>());</div>
<div id="LC75" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">    <span class="pl-c1">this</span>-&gt;<span class="pl-c1">status_set_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>bus reset failed<span class="pl-pds">&quot;</span></span>);</div>
<div id="LC76" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">  }</div>
<div id="LC77" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-64 ">  <span class="pl-k">return</span> success;</div>
<div id="LC78" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC79" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC80" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">void</span> <span class="pl-en">DallasTemperatureSensor::setup</span>() {</div>
<div id="LC81" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-c1">ESP_LOGCONFIG</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>setting up Dallas temperature sensor...<span class="pl-pds">&quot;</span></span>);</div>
<div id="LC82" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-k">if</span> (!<span class="pl-c1">this</span>-&gt;<span class="pl-c1">check_address_</span>())</div>
<div id="LC83" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">return</span>;</div>
<div id="LC84" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-k">if</span> (!<span class="pl-c1">this</span>-&gt;<span class="pl-c1">read_scratch_pad_</span>())</div>
<div id="LC85" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">return</span>;</div>
<div id="LC86" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-k">if</span> (!<span class="pl-c1">this</span>-&gt;<span class="pl-c1">check_scratch_pad_</span>())</div>
<div id="LC87" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">return</span>;</div>
<div id="LC88" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">
</div>
<div id="LC89" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-k">if</span> ((<span class="pl-c1">this</span>-&gt;<span class="pl-smi">address_</span> &amp; <span class="pl-c1">0xff</span>) == DALLAS_MODEL_DS18S20) {</div>
<div id="LC90" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-c"><span class="pl-c">//</span> DS18S20 doesn&#39;t support resolution.</span></div>
<div id="LC91" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-c1">ESP_LOGW</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>DS18S20 doesn&#39;t support setting resolution.<span class="pl-pds">&quot;</span></span>);</div>
<div id="LC92" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">return</span>;</div>
<div id="LC93" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  }</div>
<div id="LC94" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">
</div>
<div id="LC95" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-c1">uint8_t</span> res;</div>
<div id="LC96" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-k">switch</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">resolution_</span>) {</div>
<div id="LC97" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">case</span> <span class="pl-c1">12</span>:</div>
<div id="LC98" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      res = <span class="pl-c1">0x7F</span>;</div>
<div id="LC99" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-k">break</span>;</div>
<div id="LC100" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">case</span> <span class="pl-c1">11</span>:</div>
<div id="LC101" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      res = <span class="pl-c1">0x5F</span>;</div>
<div id="LC102" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-k">break</span>;</div>
<div id="LC103" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">case</span> <span class="pl-c1">10</span>:</div>
<div id="LC104" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      res = <span class="pl-c1">0x3F</span>;</div>
<div id="LC105" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-k">break</span>;</div>
<div id="LC106" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">case</span> <span class="pl-c1">9</span>:</div>
<div id="LC107" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">default</span>:</div>
<div id="LC108" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      res = <span class="pl-c1">0x1F</span>;</div>
<div id="LC109" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-k">break</span>;</div>
<div id="LC110" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  }</div>
<div id="LC111" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">
</div>
<div id="LC112" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-k">if</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">4</span>] == res)</div>
<div id="LC113" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">return</span>;</div>
<div id="LC114" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">4</span>] = res;</div>
<div id="LC115" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">
</div>
<div id="LC116" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  {</div>
<div id="LC117" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    InterruptLock lock;</div>
<div id="LC118" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-k">if</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-c1">send_command_</span>(DALLAS_COMMAND_WRITE_SCRATCH_PAD)) {</div>
<div id="LC119" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-c1">this</span>-&gt;<span class="pl-smi">bus_</span>-&gt;<span class="pl-c1">write8</span>(<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">2</span>]);  <span class="pl-c"><span class="pl-c">//</span> high alarm temp</span></div>
<div id="LC120" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-c1">this</span>-&gt;<span class="pl-smi">bus_</span>-&gt;<span class="pl-c1">write8</span>(<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">3</span>]);  <span class="pl-c"><span class="pl-c">//</span> low alarm temp</span></div>
<div id="LC121" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">      <span class="pl-c1">this</span>-&gt;<span class="pl-smi">bus_</span>-&gt;<span class="pl-c1">write8</span>(<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">4</span>]);  <span class="pl-c"><span class="pl-c">//</span> resolution</span></div>
<div id="LC122" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    }</div>
<div id="LC123" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">
</div>
<div id="LC124" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-c"><span class="pl-c">//</span> write value to EEPROM</span></div>
<div id="LC125" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">    <span class="pl-c1">this</span>-&gt;<span class="pl-c1">send_command_</span>(DALLAS_COMMAND_COPY_SCRATCH_PAD);</div>
<div id="LC126" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-79 ">  }</div>
<div id="LC127" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC128" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC129" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">bool</span> <span class="pl-en">DallasTemperatureSensor::check_scratch_pad_</span>() {</div>
<div id="LC130" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">  <span class="pl-k">bool</span> chksum_validity = (<span class="pl-c1">crc8</span>(<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>, <span class="pl-c1">8</span>) == <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">8</span>]);</div>
<div id="LC131" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">
</div>
<div id="LC132" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">#<span class="pl-k">ifdef</span> ESPHOME_LOG_LEVEL_VERY_VERBOSE</div>
<div id="LC133" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">  <span class="pl-c1">ESP_LOGVV</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>Scratch pad: %02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X.%02X (%02X)<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">0</span>],</div>
<div id="LC134" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">            <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">1</span>], <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">2</span>], <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">3</span>], <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">4</span>],</div>
<div id="LC135" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">            <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">5</span>], <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">6</span>], <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">7</span>], <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">8</span>],</div>
<div id="LC136" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">            <span class="pl-c1">crc8</span>(<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>, <span class="pl-c1">8</span>));</div>
<div id="LC137" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">#<span class="pl-k">endif</span></div>
<div id="LC138" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">  <span class="pl-k">if</span> (!chksum_validity) {</div>
<div id="LC139" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">    <span class="pl-c1">ESP_LOGW</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>&#39;%s&#39; - Scratch pad checksum invalid!<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">this</span>-&gt;<span class="pl-c1">get_name</span>().<span class="pl-c1">c_str</span>());</div>
<div id="LC140" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">    <span class="pl-c1">this</span>-&gt;<span class="pl-c1">status_set_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>scratch pad checksum invalid<span class="pl-pds">&quot;</span></span>);</div>
<div id="LC141" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">  }</div>
<div id="LC142" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-128 ">  <span class="pl-k">return</span> chksum_validity;</div>
<div id="LC143" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC144" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC145" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class="pl-k">float</span> <span class="pl-en">DallasTemperatureSensor::get_temp_c_</span>() {</div>
<div id="LC146" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">  <span class="pl-c1">int16_t</span> temp = (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">1</span>] &lt;&lt; <span class="pl-c1">8</span>) | <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">0</span>];</div>
<div id="LC147" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">  <span class="pl-k">if</span> ((<span class="pl-c1">this</span>-&gt;<span class="pl-smi">address_</span> &amp; <span class="pl-c1">0xff</span>) == DALLAS_MODEL_DS18S20) {</div>
<div id="LC148" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">    <span class="pl-k">if</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">7</span>] != <span class="pl-c1">0x10</span>)</div>
<div id="LC149" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">      <span class="pl-c1">ESP_LOGE</span>(TAG, <span class="pl-s"><span class="pl-pds">&quot;</span>unexpected COUNT_PER_C value: %u<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">7</span>]);</div>
<div id="LC150" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">    temp = ((temp &amp; <span class="pl-c1">0xfff7</span>) &lt;&lt; <span class="pl-c1">3</span>) + (<span class="pl-c1">0x10</span> - <span class="pl-c1">this</span>-&gt;<span class="pl-smi">scratch_pad_</span>[<span class="pl-c1">6</span>]) - <span class="pl-c1">4</span>;</div>
<div id="LC151" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">  } <span class="pl-k">else</span> {</div>
<div id="LC152" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">    <span class="pl-k">switch</span> (<span class="pl-c1">this</span>-&gt;<span class="pl-smi">resolution_</span>) {</div>
<div id="LC153" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">      <span class="pl-k">case</span> <span class="pl-c1">9</span>:</div>
<div id="LC154" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        temp &amp;= <span class="pl-c1">0xfff8</span>;</div>
<div id="LC155" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        <span class="pl-k">break</span>;</div>
<div id="LC156" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">      <span class="pl-k">case</span> <span class="pl-c1">10</span>:</div>
<div id="LC157" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        temp &amp;= <span class="pl-c1">0xfffc</span>;</div>
<div id="LC158" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        <span class="pl-k">break</span>;</div>
<div id="LC159" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">      <span class="pl-k">case</span> <span class="pl-c1">11</span>:</div>
<div id="LC160" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        temp &amp;= <span class="pl-c1">0xfffe</span>;</div>
<div id="LC161" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        <span class="pl-k">break</span>;</div>
<div id="LC162" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">      <span class="pl-k">case</span> <span class="pl-c1">12</span>:</div>
<div id="LC163" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">      <span class="pl-k">default</span>:</div>
<div id="LC164" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">        <span class="pl-k">break</span>;</div>
<div id="LC165" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">    }</div>
<div id="LC166" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">  }</div>
<div id="LC167" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">
</div>
<div id="LC168" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-144 ">  <span class="pl-k">return</span> temp / <span class="pl-c1">16</span>.<span class="pl-c1">0f</span>;</div>
<div id="LC169" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC170" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC171" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}  <span class="pl-c"><span class="pl-c">//</span> namespace dallas_temp</span></div>
<div id="LC172" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}  <span class="pl-c"><span class="pl-c">//</span> namespace esphome</span></div></div></div></div></div><div id="copilot-button-container"></div></div><div id="highlighted-line-menu-container"></div></div></div><button hidden="" data-testid="hotkey-button" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button></section></div></div><div class="Box-sc-g0xbh4-0 ktQnIo"></div><div class="Box-sc-g0xbh4-0 eytzQM panel-content-narrow-styles inner-panel-content-not-narrow"><div id="symbols-pane" class="Box-sc-g0xbh4-0"><div aria-labelledby="symbols-pane-header" class="Box-sc-g0xbh4-0 bJNAmt"><div class="Box-sc-g0xbh4-0 ipXucK"><h2 id="symbols-pane-header" tabindex="-1" class="Box-sc-g0xbh4-0 wMEyi">Symbols</h2><button data-component="IconButton" type="button" aria-label="Close symbols" data-hotkey="Escape" data-no-visuals="true" class="types__StyledButton-sc-ws60qy-0 eyqOHf"><svg aria-hidden="true" focusable="false" role="img" class="octicon octicon-x" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path></svg></button></div><div class="Box-sc-g0xbh4-0 fHqdLt">Find definitions and references for functions and other symbols in this file by clicking a symbol below or in the code.</div><span class="TextInputWrapper__TextInputBaseWrapper-sc-1mqhpbi-0 TextInputWrapper-sc-1mqhpbi-1 dPpnEo dWJhEx TextInput-wrapper" aria-busy="false"><span class="TextInput-icon"><svg aria-hidden="true" focusable="false" role="img" class="Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" style="display:inline-block;user-select:none;vertical-align:text-bottom;overflow:visible"><path d="M.75 3h14.5a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1 0-1.5ZM3 7.75A.75.75 0 0 1 3.75 7h8.5a.75.75 0 0 1 0 1.5h-8.5A.75.75 0 0 1 3 7.75Zm3 4a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 0 1.5h-2.5a.75.75 0 0 1-.75-.75Z"></path></svg></span><input type="text" placeholder="Filter symbols" name="Filter symbols" aria-label="Filter symbols" aria-controls="filter-results" aria-expanded="true" aria-autocomplete="list" role="combobox" data-component="input" class="UnstyledTextInput-sc-14ypya-0 cDLBls" value=""/><span class="TextInput-icon"><div class="Box-sc-g0xbh4-0 ckwgci"><kbd>r</kbd></div></span></span><div class="Box-sc-g0xbh4-0 jGYebd"><div id="filter-results" class="Box-sc-g0xbh4-0 kgNotW"><span role="status" aria-live="polite" aria-atomic="true" class="_VisuallyHidden__VisuallyHidden-sc-11jhm7a-0 rTZSs"></span><ul role="tree" aria-label="Code Navigation" data-omit-spacer="true" class="TreeView__UlBox-sc-4ex6b6-0 bfhvai"><li class="PRIVATE_TreeView-item" tabindex="0" id="0millis_to_wait_for_conversion_" role="treeitem" aria-labelledby=":R38qtal9laeb:" aria-describedby=":R38qtal9laebH1: :R38qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R38qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="millis_to_wait_for_conversion_" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">millis_to_wait_for_conversion_</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="1dump_config" role="treeitem" aria-labelledby=":R58qtal9laeb:" aria-describedby=":R58qtal9laebH1: :R58qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R58qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="dump_config" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">dump_config</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="2update" role="treeitem" aria-labelledby=":R78qtal9laeb:" aria-describedby=":R78qtal9laebH1: :R78qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R78qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="update" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">update</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="3read_scratch_pad_int_" role="treeitem" aria-labelledby=":R98qtal9laeb:" aria-describedby=":R98qtal9laebH1: :R98qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R98qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="read_scratch_pad_int_" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">read_scratch_pad_int_</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="4read_scratch_pad_" role="treeitem" aria-labelledby=":Rb8qtal9laeb:" aria-describedby=":Rb8qtal9laebH1: :Rb8qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":Rb8qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="read_scratch_pad_" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">read_scratch_pad_</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="5setup" role="treeitem" aria-labelledby=":Rd8qtal9laeb:" aria-describedby=":Rd8qtal9laebH1: :Rd8qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":Rd8qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="setup" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">setup</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="6check_scratch_pad_" role="treeitem" aria-labelledby=":Rf8qtal9laeb:" aria-describedby=":Rf8qtal9laebH1: :Rf8qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":Rf8qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="check_scratch_pad_" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">check_scratch_pad_</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item" tabindex="0" id="7get_temp_c_" role="treeitem" aria-labelledby=":Rh8qtal9laeb:" aria-describedby=":Rh8qtal9laebH1: :Rh8qtal9laebH2:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":Rh8qtal9laeb:" class="PRIVATE_TreeView-item-content"><span class="PRIVATE_TreeView-item-content-text"><div class="Box-sc-g0xbh4-0 cFPoqW"><div class="Box-sc-g0xbh4-0 brdoto"><div class="Box-sc-g0xbh4-0 cDCIeg"></div><div class="Box-sc-g0xbh4-0 dIEiEC">func</div></div>  <div title="get_temp_c_" class="Truncate__StyledTruncate-sc-23o1d2-0 iQHhGT"><span class="Text-sc-17v1xeu-0 gPDEWA">get_temp_c_</span></div></div></span></div></div></li></ul></div></div></div></div></div></div> <!-- --> <!-- --> </div></div></div><div class="Box-sc-g0xbh4-0"></div></div></div></div></div><div id="find-result-marks-container" class="Box-sc-g0xbh4-0 aZrVR"></div><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button></div> <!-- --> <!-- --> <!-- --> <script type="application/json" id="__PRIMER_DATA_:R0:__">{"resolvedServerColorMode":"night"}</script></div>
</react-app>
</turbo-frame>



  </div>

</turbo-frame>

    </main>
  </div>

  </div>

          <footer class="footer pt-8 pb-6 f6 color-fg-muted p-responsive" role="contentinfo" >
  <h2 class='sr-only'>Footer</h2>

  


  <div class="d-flex flex-justify-center flex-items-center flex-column-reverse flex-lg-row flex-wrap flex-lg-nowrap">
    <div class="d-flex flex-items-center flex-shrink-0 mx-2">
      <a aria-label="Homepage" title="GitHub" class="footer-octicon mr-2" href="https://github.com">
        <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path>
</svg>
</a>
      <span>
        &copy; 2024 GitHub,&nbsp;Inc.
      </span>
    </div>

    <nav aria-label="Footer">
      <h3 class="sr-only" id="sr-footer-heading">Footer navigation</h3>

      <ul class="list-style-none d-flex flex-justify-center flex-wrap mb-2 mb-lg-0" aria-labelledby="sr-footer-heading">

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}" href="https://docs.github.com/site-policy/github-terms/github-terms-of-service" data-view-component="true" class="Link--secondary Link">Terms</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}" href="https://docs.github.com/site-policy/privacy-policies/github-privacy-statement" data-view-component="true" class="Link--secondary Link">Privacy</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}" href="https://github.com/security" data-view-component="true" class="Link--secondary Link">Security</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;}" href="https://www.githubstatus.com/" data-view-component="true" class="Link--secondary Link">Status</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to docs&quot;,&quot;label&quot;:&quot;text:docs&quot;}" href="https://docs.github.com/" data-view-component="true" class="Link--secondary Link">Docs</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;}" href="https://support.github.com?tags=dotcom-footer" data-view-component="true" class="Link--secondary Link">Contact</a>
          </li>

          <li class="mr-3" >
  <cookie-consent-link>
    <button type="button" class="Link--secondary underline-on-hover border-0 p-0 color-bg-transparent" data-action="click:cookie-consent-link#showConsentManagement">
      Manage cookies
    </button>
  </cookie-consent-link>
</li>

<li class="mr-3">
  <cookie-consent-link>
    <button type="button" class="Link--secondary underline-on-hover border-0 p-0 color-bg-transparent" data-action="click:cookie-consent-link#showConsentManagement">
      Do not share my personal information
    </button>
  </cookie-consent-link>
</li>

      </ul>
    </nav>
  </div>
</footer>




    <ghcc-consent id="ghcc" class="position-fixed bottom-0 left-0" style="z-index: 999999" data-initial-cookie-consent-allowed="" data-cookie-consent-required="true"></ghcc-consent>


  <div id="ajax-error-message" class="ajax-error-message flash flash-error" hidden>
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
    </button>
    You can’t perform that action at this time.
  </div>

    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0 tooltipped-no-delay" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>
<template id="snippet-clipboard-copy-button-unpositioned">
  <div class="zeroclipboard-container">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn btn-invisible js-clipboard-copy m-2 p-0 tooltipped-no-delay d-flex flex-justify-center flex-items-center" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon">
    <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>


    <style>
      .user-mention[href$="/tiimsvk"] {
        color: var(--color-user-mention-fg);
        background-color: var(--bgColor-attention-muted, var(--color-attention-subtle));
        border-radius: 2px;
        margin-left: -2px;
        margin-right: -2px;
        padding: 0 2px;
      }
    </style>


    </div>

    <div id="js-global-screen-reader-notice" class="sr-only" aria-live="polite" aria-atomic="true" ></div>
    <div id="js-global-screen-reader-notice-assertive" class="sr-only" aria-live="assertive" aria-atomic="true"></div>
  </body>
</html>

